/* eslint-disable no-case-declarations */
/* eslint-disable no-unused-vars */
/* eslint-disable no-irregular-whitespace */

/**
 * This source code below is free, please DO NOT sell this in any form!
 * Source code ini gratis, jadi tolong JANGAN jual dalam bentuk apapun!
 *
 * If you copying one of our source code, please give us CREDITS. Because this is one of our hardwork.
 * Apabila kamu menjiplak salah satu source code ini, tolong berikan kami CREDIT. Karena ini adalah salah satu kerja keras kami.
 *
 * If you want to contributing to this source code, pull requests are always open.
 * Apabila kamu ingin berkontribusi ke source code ini, pull request selalu kami buka.
 *
 * Thanks for the contributions.
 * Terima kasih atas kontribusinya.
 */

/********** MODULES **********/
const { decryptMedia, Client } = require('@open-wa/wa-automate')
const fs = require('fs-extra')
const yts = require('yt-search')
const config = require('../config.json')
const Nekos = require('nekos.life')
const neko = new Nekos()
const os = require('os')
const nhdl = require('nhentaidownloader')
const appRoot = require('app-root-path')
const low = require('lowdb')
const nhentai = require('nhentai-js')
const { API } = require('nhentai-api')
const api = new API()
const sagiri = require('sagiri')
const NanaAPI = require('nana-api')
const nana = new NanaAPI()
const bdr = require('rumus-bdr')
const fetch = require('node-fetch')
const isPorn = require('is-porn')
const exec = require('await-exec')
const webp = require('webp-converter')
const sharp = require('sharp')
const saus = sagiri(config.nao, { results: 5 })
const axios = require('axios')
const get = require('got')
const tts = require('node-gtts')
const nekobocc = require('nekobocc')
const ffmpeg = require('fluent-ffmpeg')
const bent = require('bent')
const path = require('path')
const ms = require('parse-ms')
const toMs = require('ms')
const canvas = require('canvacord')
const mathjs = require('mathjs')
const emojiUnicode = require('emoji-unicode')
const moment = require('moment-timezone')
const translate = require('@vitalets/google-translate-api')
moment.tz.setDefault('Asia/Jakarta').locale('id')
const genshin = require('genshin-impact-api')
const google = require('google-it')
const cron = require('node-cron')
/********** END OF MODULES **********/

/********** UTILS **********/
const { msgFilter, color, processTime, isUrl, createSerial } = require('../tools')
const { nsfw, weeaboo, downloader, cariKasar, fun, misc, toxic } = require('../lib')
const { uploadImages } = require('../tools/fetcher')
const { ind, eng } = require('./text/lang/')
const { daily, level, register, card, afk, reminder, premium, limit} = require('../function')
const Exif = require('../tools/exif')
const { WSAENAMETOOLONG } = require('constants')
const { brightness } = require('canvacord/src/Canvacord')
const { link } = require('fs')
const exif = new Exif()
const cd = 4.32e+7
const limitCount = 25
const errorImg = 'https://i.ibb.co/jRCpLfn/user.png'
const tanggal = moment.tz('Asia/Jakarta').format('DD-MM-YYYY')
/********** END OF UTILS **********/

/********** DATABASES **********/
const _nsfw = JSON.parse(fs.readFileSync('./database/group/nsfw.json'))
const _antilink = JSON.parse(fs.readFileSync('./database/group/antilink.json'))
const _antinsfw = JSON.parse(fs.readFileSync('./database/group/antinsfw.json'))
const _leveling = JSON.parse(fs.readFileSync('./database/group/leveling.json'))
const _welcome = JSON.parse(fs.readFileSync('./database/group/welcome.json'))
const _autosticker = JSON.parse(fs.readFileSync('./database/group/autosticker.json'))
const _ban = JSON.parse(fs.readFileSync('./database/bot/banned.json'))
const _premium = JSON.parse(fs.readFileSync('./database/bot/premium.json'))
const _mute = JSON.parse(fs.readFileSync('./database/bot/mute.json'))
const _registered = JSON.parse(fs.readFileSync('./database/bot/registered.json'))
const _level = JSON.parse(fs.readFileSync('./database/user/level.json'))
let _limit = JSON.parse(fs.readFileSync('./database/user/limit.json'))
const _bg = JSON.parse(fs.readFileSync('./database/user/card/background.json'))
const _afk = JSON.parse(fs.readFileSync('./database/user/afk.json'))
const _reminder = JSON.parse(fs.readFileSync('./database/user/reminder.json'))
const _daily = JSON.parse(fs.readFileSync('./database/user/daily.json'))
const uang = JSON.parse(fs.readFileSync('./database/user/uang.json'))
const _setting = JSON.parse(fs.readFileSync('./database/bot/setting.json'))
let { memberLimit, groupLimit } = _setting
/********** END OF DATABASES **********/

/********** MESSAGE HANDLER **********/
// eslint-disable-next-line no-undef
module.exports = msgHandler = async (anto = new Client(), message) => {
    try {
        const { type, id, from, t, sender, isGroupMsg, chat, chatId, caption, isMedia, mimetype, quotedMsg, quotedMsgObj, mentionedJidList } = message
        let { body } = message
        const { name, formattedTitle } = chat
        let { pushname, verifiedName, formattedName } = sender
        pushname = pushname || verifiedName || formattedName
        const botNumber = await anto.getHostNumber() + '@c.us'
        const blockNumber = await anto.getBlockedIds()
        const ownerNumber = config.ownerBot
        const serial = sender.id
        const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const groupAdmins = isGroupMsg ? await anto.getGroupAdmins(groupId) : ''
        const time = moment(t * 1000).format('DD/MM/YY HH:mm:ss')

        const chats = (type === 'chat') ? body : ((type === 'image' || type === 'video')) ? caption : ''
        const prefix = config.prefix
        body = (type === 'chat' && body.startsWith(prefix)) ? body : (((type === 'image' || type === 'video') && caption) && caption.startsWith(prefix)) ? caption : ''
        const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1)
        const uaOverride = config.uaOverride
        const thumb = `https://telegra.ph/file/6507472509a1f16696833.jpg`
        const gaya = '```'
        const ppbot = `https://telegra.ph/file/6507472509a1f16696833.jpg`
        const q = args.join(' ')
        const ar = args.map((v) => v.toLowerCase())
        const url = args.length !== 0 ? args[0] : ''

        /********** VALIDATOR **********/
        const isCmd = body.startsWith(prefix)
        const isBlocked = blockNumber.includes(sender.id)
        const isOwner = sender.id === ownerNumber
        const isGroupAdmins = groupAdmins.includes(sender.id) || false
        const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
        const isBanned = _ban.includes(sender.id)
        const isPremium = premium.checkPremiumUser(sender.id, _premium)
        const isRegistered = register.checkRegisteredUser(sender.id, _registered)
        const isNsfw = isGroupMsg ? _nsfw.includes(groupId) : false
        const isWelcomeOn = isGroupMsg ? _welcome.includes(groupId) : false
        const isDetectorOn = isGroupMsg ? _antilink.includes(groupId) : false
        const isLevelingOn = isGroupMsg ? _leveling.includes(groupId) : false
  //      const groupId = isGroupMsg ? chat.groupMetadata.id : ''
        const isAutoStickerOn = isGroupMsg ? _autosticker.includes(groupId) : false
        const isAntiNsfw = isGroupMsg ? _antinsfw.includes(groupId) : false
        const isMute = _mute.includes(ownerNumber)
        const isAfkOn = afk.checkAfkUser(sender.id, _afk)
        const isQuotedImage = quotedMsg && quotedMsg.type === 'image'
        const isQuotedVideo = quotedMsg && quotedMsg.type === 'video'
        const isQuotedSticker = quotedMsg && quotedMsg.type === 'sticker'
        const isQuotedAudio = quotedMsg && quotedMsg.type === 'audio'
        const isQuotedVoice = quotedMsg && quotedMsg.type === 'ptt'
        const isAudio = type === 'audio'
        const isVoice = type === 'ptt'
        const isQuotedGif = quotedMsg && quotedMsg.mimetype === 'image/gif'

        const isImage = type === 'image'
     //   const isKasar = await cariKasar(chats)
        const isVideo = type === 'video'
        /********** END OF VALIDATOR **********/
    // _Second_
    const formater = (seconds) => {
      const pad = (s) => {
        return (s < 10 ? '0' : '') + s
      }
      const hrs = Math.floor(seconds / (60 * 60))
      const mins = Math.floor(seconds % (60 * 60) / 60)
      const secs = Math.floor(seconds % 60)
      return ' ' + pad(hrs) + ':' + pad(mins) + ':' + pad(secs)
    }
        // Automate
        premium.expiredCheck(_premium)
        cron.schedule('0 0 * * *', () => {
            const reset = []
            _limit = reset
            console.log('Resetting user limit...')
            fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
            console.log('Success!')
        }, {
            scheduled: true,
            timezone: 'Asia/Jakarta'
        })

        // ROLE (Change to what you want, or add) and you can change the role sort based on XP.
        const levelRole = level.getLevelingLevel(sender.id, _level)
        
        var role = 'HERO D'
        if (levelRole <= 5) {
              roles = 'HERO C'
            } else if (levelRole <= 10) {
              role = 'HERO B'
            } else if (levelRole <= 15) {
              role = 'HERO A'
            } else if (levelRole <= 20) {
              role = 'HERO AA'
            } else if (levelRole <= 25) {
              role = 'HERO AAA'
            } else if (levelRole <= 30) {
              role = 'HERO S'
            } else if (levelRole <= 35) {
              role = 'HERO SS'
            } else if (levelRole <= 40) {
              role = 'HERO SSS'
            } else if (levelRole <= 45) {
              role = 'HERO SSS(DUNIA)'
            } else if (levelRole <= 50) {
              role = 'HERO TINGKAT MISTERI'
            } else if (levelRole <= 55) {
              role = 'HERO TINGKAT MISTERI II'
            } else if (levelRole <= 60) {
              role = 'HERO TINGKAT MISTERI III'
            } else if (levelRole <= 65) {
              role = 'LORD HERO'
            } else if (levelRole <= 70) {
              role = 'LORD HERO II'
            } else if (levelRole <= 75) {
              role = 'LORD HERO III'
            } else if (levelRole <= 80) {
              role = 'LORD HERO IV'
            } else if (levelRole <= 85) {
              role = 'LORD HERO V'
            } else if (levelRole <= 90) {
              role = 'GREAT A LORD'
            } else if (levelRole <= 95) {
              role = 'CREAT A LORD(DEWA)'
            } else if (levelRole <= 100) {
              role = 'KAMI-SAMA'
            } else if (levelRole => 105) {
            role = 'LORD-PAIMON'
        }

        // Leveling [BETA] by Slavyan
        if (isGroupMsg && isRegistered && !level.isGained(sender.id) && !isBanned && isLevelingOn) {
            try {
                level.addCooldown(sender.id)
                const currentLevel = level.getLevelingLevel(sender.id, _level)
                const amountXp = Math.floor(Math.random() * (15 - 25 + 1) + 15)
                
                const requiredXp = 5 * Math.pow(currentLevel, 2) + 50 * currentLevel + 100
                level.addLevelingXp(sender.id, amountXp, _level)
                const checkBg = card.getBg(sender.id, _bg)
                if (currentLevel === undefined && checkId === undefined) level.addLevelingId(sender.id, _level)
                if (checkBg === undefined) card.addBg(sender.id, _bg)
                if (requiredXp <= level.getLevelingXp(sender.id, _level)) {
                    level.addLevelingLevel(sender.id, 1, _level)
                    const userLevel = level.getLevelingLevel(sender.id, _level)
                    const fetchXp = 5 * Math.pow(userLevel, 2) + 50 * userLevel + 100
                    await anto.reply(from, `${gaya}「 LEVEL UP 」\n\nSelamat 🎊🎉 ${pushname}\nXp Kamu Sekarang adalah ${level.getLevelingXp(sender.id, _level)} / ${fetchXp}\nDan Telah Naik level Dari ${currentLevel} -> ${level.getLevelingLevel(sender.id, _level)} 🆙 \nDan Berhasil Mendapatkan Gelar ${role}\n\nCongrats Yah ${pushname}!! 🎉🎉${gaya}`, id)
                }
            } catch (err) {
                console.error(err)
            }
        }
        // Anti-group link detector
        if (isGroupMsg && !isGroupAdmins && isBotGroupAdmins && isDetectorOn && !isOwner) {
            if (chats.match(new RegExp(/(https:\/\/chat.whatsapp.com)/gi))) {
                const valid = await anto.inviteInfo(chats)
                if (valid) {
                    console.log(color('[KICK]', 'red'), color('Received a group link and it is a valid link!', 'yellow'))
                    await anto.reply(from, ind.linkDetected(), id)
                    await anto.removeParticipant(groupId, sender.id)
                } else {
                    console.log(color('[WARN]', 'yellow'), color('Received a group link but is not a valid link!', 'yellow'))
                }
            }
        }

        // Anti-fake-group link detector
        if (isGroupMsg && !isGroupAdmins && isBotGroupAdmins && isDetectorOn && !isOwner) {
            if (chats.match(new RegExp(/(https:\/\/chat.(?!whatsapp.com))/gi))) {
                console.log(color('[KICK]', 'red'), color('Received a fake group link.', 'yellow'))
                await anto.reply(from, 'Fake group link detected!', id)
                await anto.removeParticipant(groupId, sender.id)
            }
        }
        //Function DUIT
        const addATM = (serial) => {
            const obj = {id: serial, uang : 0}
            uang.push(obj)
            fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
        }
        const addDuit = (serial, amount) => {
            let position = null
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === serial) {
                    position = i
                }
            })
            if (position !== null) {
                uang[position].uang += amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
        const addKoinUser = (serial, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === serial) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang += amount;
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
        
        const checkATMuser = (serial) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === serial) {
                    position = i
                }
            })
            if (position !== false) {
                return uang[position].uang
            }
        }
        
        const bayarLimit = (serial, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === serial) {
                    position = i
                }
            })
            if (position !== false) {
                limit[position].limit -= amount;
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(limit))
            }
        }
            
        const confirmATM = (serial, amount) => {
            let position = false
            Object.keys(uang).forEach((i) => {
                if (uang[i].id === serial) {
                    position = i
                }
            })
            if (position !== false) {
                uang[position].uang -= amount
                fs.writeFileSync('./database/user/uang.json', JSON.stringify(uang))
            }
        }
	
            if (isRegistered) {
            const checkATM = checkATMuser(serial)
            try {
                if (checkATM === undefined) addATM(serial)
                const uangsaku = Math.floor(Math.random() * 10) + 50
                addKoinUser(serial, uangsaku)
            } catch (err) {
                console.error(err)
            }
        }
        // Anti NSFW link
        if (isGroupMsg && !isGroupAdmins && isBotGroupAdmins && isAntiNsfw && !isOwner) {
            if (isUrl(chats)) {
                const classify = new URL(isUrl(chats))
                console.log(color('[FILTER]', 'yellow'), 'Checking link:', classify.hostname)
                isPorn(classify.hostname, async (err, status) => {
                    if (err) return console.error(err)
                    if (status) {
                        console.log(color('[NSFW]', 'red'), color('The link is classified as NSFW!', 'yellow'))
                        await anto.reply(from, ind.linkNsfw(), id)
                        await anto.removeParticipant(groupId, sender.id)
                    } else {
                        console.log(('[NEUTRAL]'), color('The link is safe!'))
                    }
                })
            }
        }
        
        // Auto-sticker
        if (isGroupMsg && isAutoStickerOn && isMedia && isImage && !isCmd) {
            const mediaData = await decryptMedia(message, uaOverride)
            const imageBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
            await anto.sendImageAsSticker(from, imageBase64, null, { pack: 'PaimonBot', author: '@Hardianto02_', keepScale: true})
            console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
        } else {
            if (isGroupMsg && isAutoStickerOn && isMedia && isVideo && !isCmd) {
                const mediaData = await decryptMedia(message, uaOverride)
                const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                await anto.sendMp4AsSticker(from, videoBase64, null, { author: 'bot', pack: 'paimon', keepScale: true })
                console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
            }
        }
        
        // AFK by Slavyan
        if (isGroupMsg) {
            for (let ment of mentionedJidList) {
                if (afk.checkAfkUser(ment, _afk)) {
                    const getId = afk.getAfkId(ment, _afk)
                    const getReason = afk.getAfkReason(getId, _afk)
                    const getTime = afk.getAfkTime(getId, _afk)
                    await anto.reply(from, ind.afkMentioned(getReason, getTime), id)
                }
            }
            if (afk.checkAfkUser(sender.id, _afk) && !isCmd) {
                _afk.splice(afk.getAfkPosition(sender.id, _afk), 1)
                fs.writeFileSync('./database/user/afk.json', JSON.stringify(_afk))
                await anto.sendText(from, ind.afkDone(pushname))
            }
        }
        // RESPONDER Bot
        if(chats.match("hay") || chats.match("hii") || chats.match("ohayou") || chats.match("Ohayou") || chats.match("Konic") || chats.match("konic")) {
          const hayo_ = `https://telegra.ph/file/86fc10ad4da473d69ddc2.jpg`
          anto.sendFileFromUrl(from, hayo_, 'nene.jpg', '*Hay Kak'+pushname+'*', id)
        }
        if(chats.match("bot") || chats.match("Bot") || chats.match("BOT") || chats.match("Paimon") || chats.match("PAIMON") || chats.match("paimin") || chats.match("Paimin")) {
          const bote = [
            'Ada Apa Kakak',
            'Yah Paimon Disini',
            'Gabut kak ketik !help aja',
            'Wah Ada Apa tuh panggil paimon',
            'Ok Masih Ku pantau',
            'Hehehe senpai Gabut nich',
            'Iyaaa kak Ad Apa Paimon Bantu kok',
            'Apa tuuhhh chh'
            ]
            const randem = bote[Math.floor(Math.random() * bote.length)]
            anto.reply(from, `*_${randem}_*`, id)
        }
        if(chats.match("pota") || chats.match("Pota")) {
            anto.sendMp4AsSticker(from, './temp/audio/tsukasa.mp4')
            anto.sendPtt(from, './temp/audio/pota.mp3', id)
        }
        if(chats.match("assalamu") || chats.match("Assalamu")){
          anto.reply(from, `Waalaikumsalam Kak ${pushname}`, id)
        }
        if(chats.match("@62895635764737")){
            anto.reply(from, `_Ada Apa Kak *${pushname}* Senpai Ngetag Paimon Sembarangan Ngajak Solat_`, id)
        }
        if(chats.match("@6287811078485")){
            anto.sendPtt(from, './temp/audio/oaoa.mp3', id)
            anto.reply(from, `*Haloo Kak ${pushname} Apa Gerangan Ngetag Owner Yang Overpower, Badash, Keren, Pintar, Pro Sangat ini* `, id)
        }
        if(chats.match("arigato") || chats.match("mksh") || chats.match("Arigato") || chats.match("Mksh") || chats.match("thank") || chats.match("Thank") || chats.match("thx") || chats.match("Tq") || chats.match("tq") || chats.match("Makasih") || chats.match("makasih")){
            anto.sendPtt(from, './temp/audio/oaoa.mp3', id)
            anto.reply(from, `*Sama-Sama Kak ${pushname} Bahagia Mu Bahagia Owner ku juga*`, id)
        }

     //  if(!isCmd && isKasar && isGroupMsg) { console.log(color('[BADWORD]'), color(moment(t * 1000).format('DD/MM/YY HH:mm:ss'), 'yellow'), 'from', color(pushname), 'in', color(name || formattedTitle)) }
        // Mute
        if (isCmd && isMute && !isOwner) return
        
        // Ignore banned and blocked users
        if (isCmd && (isBanned || isBlocked) && !isGroupMsg) return console.log(color('[BAN]', 'red'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        if (isCmd && (isBanned || isBlocked) && isGroupMsg) return console.log(color('[BAN]', 'red'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle))

        /*// Anti-spam
        if (isCmd && msgFilter.isFiltered(from) && isGroupMsg){
            anto.reply(from, 'jangan spam', id)
        }*/
        if (isCmd && msgFilter.isFiltered(from) && !isGroupMsg) return console.log(color('[SPAM]', 'red'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
        if (isCmd && msgFilter.isFiltered(from) && isGroupMsg) return console.log(color('[SPAM]', 'red'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle))

        // Log
        if (isCmd && !isGroupMsg) {
            console.log(color('[CMD]'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname))
            await anto.sendSeen(from)
        }
        if (isCmd && isGroupMsg) {
            console.log(color('[CMD]'), color(time, 'yellow'), color(`${command} [${args.length}]`), 'from', color(pushname), 'in', color(name || formattedTitle))
            await anto.sendSeen(from)
        }

        // Anti-spam
        if (isCmd && !isPremium && !isOwner) msgFilter.addFilter(from)
        
        switch (command) {
                case 'duit':
                    if (!isRegistered) return anto.reply(from, ind.notRegistered(), id)
                    const kantong = checkATMuser(serial)
                    anto.reply(from, `Halo ${pushname}, Kamu Memiliki Uang Sejumlah Rp. ${kantong}`, id)
                    break
                    case 'gajian':
                        if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                        if (args.length !== 2) return await anto.reply(from, ind.wrongFormat(), id)
                        if (mentionedJidList.length !== 0) {
                            for (let give of mentionedJidList) {
                                addDuit(give, Number(args[1]), uang)
                                await anto.reply(from, `Sukses menambah DUIT kepada: ${give}\nJumlah ditambahkan: ${args[1]}`, id)
                            }
                        } else {
                            addDuit(args[0] + '@c.us', Number(args[1]), uang)
                            await anto.reply(from, `Sukses menambah DUIT kepada: ${args[0]}\nJumlah ditambahkan: ${args[1]}`, id)
                        }
                    break
            case 'register':
            case 'daftar':  
                if (isRegistered) return await anto.reply(from, ind.registeredAlready(), id)
               // if (isGroupMsg) return await anto.reply(from, ind.pcOnly(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                const perry = await anto.getProfilePicFromServer(sender.id)
                if (perry === undefined) {
                    var papap = errorImg
                } else {
                    papap = perry
                }
                const namaUser = q.substring(0, q.indexOf('|') - 1)
                const umurUser = q.substring(q.lastIndexOf('|') + 2)
                const serialUser = createSerial(20)
                if (Number(umurUser) >= 40) return await anto.reply(from, ind.ageOld(), id)
                register.addRegisteredUser(sender.id, namaUser, umurUser, time, serialUser, _registered)
                await anto.sendFileFromUrl(from, papap, `${sender.id}.jpg`, ind.registered(namaUser, umurUser, sender.id, time, serialUser), id)
                console.log(color('[REGISTER]'), color(time, 'yellow'), 'Name:', color(namaUser, 'cyan'), 'Age:', color(umurUser, 'cyan'), 'Serial:', color(serialUser, 'cyan'))
            break
            
            // Level [BETA] by Slavyan
                case 'setbackground':
                case 'setbg':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isLevelingOn) return await anto.reply(from, ind.levelingNotOn(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                const levels = level.getLevelingLevel(sender.id, _level)
                const xps = level.getLevelingXp(sender.id, _level)
                if (levels === undefined && xps === undefined) return await anto.reply(from, ind.levelNull(), id)
                if (isMedia && isImage || isQuotedImage) {
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const link = await uploadImages(mediaData, `${sender.id}_bg`)
                  card.replaceBg(sender.id, link, _bg)
                  await anto.reply(from, 'Success set new background!', id)
                } else {
                  await anto.reply(from, ind.wrongFormat(), id)
                }
                break
            case 'level':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isLevelingOn) return await anto.reply(from, ind.levelingNotOn(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                const userLevel = level.getLevelingLevel(sender.id, _level)
                const bege = card.getBg(sender.id, _bg)
                const userXp = level.getLevelingXp(sender.id, _level)
                const ppLink = await anto.getProfilePicFromServer(sender.id)
                if (ppLink === undefined) {
                    var pepe = errorImg
                } else {
                    pepe = ppLink
                }
                const requiredXp = 5 * Math.pow(userLevel, 2) + 50 * userLevel + 100
                const rank = new canvas.Rank()
                    .setAvatar(pepe)
                    .setLevel(userLevel)
                    .setLevelColor('#ffa200', '#ffa200')
                    .setRank(Number(level.getUserRank(sender.id, _level)))
                    .setCurrentXP(userXp)
                    .setOverlay('#000000', 100, false)
                    .setRequiredXP(requiredXp)
                    .setProgressBar('#ffa200', 'COLOR')
                    .setBackground('IMAGE', bege)
                    .setUsername(pushname)
                    .setDiscriminator(sender.id.substring(6, 10))
                rank.build()
                    .then(async (buffer) => {
                        canvas.write(buffer, `${sender.id}_card.png`)
                        await anto.sendFile(from, `${sender.id}_card.png`, `${sender.id}_card.png`, '', id)
                        fs.unlinkSync(`${sender.id}_card.png`)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'nhentai':
            case 'doujin':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!q) return await anto.reply(from, ind.wrongFormat(), id)
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              anto.reply(from, ind.ok(), id)
              const doujin_ = await axios.get(`http://lolhuman.herokuapp.com/api/nhentai/${q}?apikey=${config.lol}`)
              try {
                const { title_romaji, title_native, read, file_pdf, info } = doujin_.data.result
                const kntl_ = doujin_.data.result.image
              const randem = kntl_[Math.floor(Math.random() * kntl_.length)]
              const fe_pdf = await axios.get(`http://lolhuman.herokuapp.com/api/nhentaipdf/${q}?apikey=${config.lol}`)
                const cepete = `_____DOUJIN_____
*[Title] : ${title_romaji}*
*[info] : ${info}*`
              await anto.sendFileFromUrl(from, randem, 'duji.jpg', `${cepete}`, id)
              await anto.sendFileFromUrl(from, fe_pdf.data.result, `${title_romaji}.pdf`, `${q}`, id)
              } catch {
                anto.sendFileFromUrl(from, errorImg, 'eorr.jpg', '```Doujin Tidak Ditemukan```', id)
              }
              break
            case 'nhentaizip':
        case 'ndown':
                const kode_nh = q
                var ID = `${kode_nh}`
                 nhdl(ID).then(async (buffer) => {
                   fs.writeFileSync(`./${ID}.zip`, buffer);
                  await anto.sendFile(from, `./${ID}.zip`, `${ID}.zip`, 'tod.zip', id)
                  await sleep(3000)
                  fs.unlinkSync(`./${ID}.zip`)
                   })
                   .catch(async (err) => {
                       console.error(err)
                       await anto.reply(from, 'error', id)

                   })
                   break
            case 'leaderboard':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isLevelingOn) return await anto.reply(from, ind.levelingNotOn(), id)
                if (!isGroupMsg) return await anto.reply(from. ind.groupOnly(), id)
                const resp = _level
                _level.sort((a, b) => (a.xp < b.xp) ? 1 : -1)
                let leaderboard = '____[ *LEADERBOARD* ]____\n\n'
                try {
                    for (let i = 0; i < 100; i++) {
                        var roles = 'HERO D'
                        if (resp[i].level <= 5) {
                            roles = 'HERO C'
                        } else if (resp[i].level <= 10) {
                            roles = 'HERO B'
                        } else if (resp[i].level <= 15) {
                            roles = 'HERO A'
                        } else if (resp[i].level <= 20) {
                            roles = 'HERO AA'
                        } else if (resp[i].level <= 25) {
                            roles = 'HERO AAA'
                        } else if (resp[i].level <= 30) {
                            roles = 'HERO S'
                        } else if (resp[i].level <= 35) {
                            roles = 'HERO SS'
                        } else if (resp[i].level <= 40) {
                            roles = 'HERO SSS'
                        } else if (resp[i].level <= 45) {
                            roles = 'HERO SSS(DUNIA)'
                        } else if (resp[i].level <= 50) {
                            roles = 'HERO TINGKAT MISTERI'
                        } else if (resp[i].level <= 55) {
                            roles = 'HERO TINGKAT MISTERI II'
                        } else if (resp[i].level <= 60) {
                            roles = 'HERO TINGKAT MISTERI III'
                        } else if (resp[i].level <= 65) {
                            roles = 'LORD HERO'
                        } else if (resp[i].level <= 70) {
                            roles = 'LORD HERO II'
                        } else if (resp[i].level <= 75) {
                            roles = 'LORD HERO III'
                        } else if (resp[i].level <= 80) {
                            roles = 'LORD HERO IV'
                        } else if (resp[i].level <= 85) {
                            roles = 'LORD HERO V'
                        } else if (resp[i].level <= 90) {
                            roles = 'GREAT A LORD'
                        } else if (resp[i].level <= 95) {
                            roles = 'CREAT A LORD(DEWA)'
                        } else if (resp[i].level <= 100) {
                            roles = 'KAMI-SAMA'
                //JAGA JAGA
                        } 
                        leaderboard += `${i + 1}. wa.me/${_level[i].id.replace('@c.us', '')}\n➸ *XP*: ${_level[i].xp} *Level*: ${_level[i].level}\n➸ *Role*: ${roles}\n\n`
                    }
                    await anto.reply(from, leaderboard, id)
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, ind.minimalDb(), id)
                }
            break

            // Downloader
            case 'joox':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                const joox_music = await axios.get(`https://tobz-api.herokuapp.com/api/joox?q=${q}&apikey=${config.tobz}`)
                try {
                    const { album, dipublikasi, judul, mp3, thumb } = joox_music.data.result
                    const pap = '```'
                    const capt = `${pap}________[< JOOX >]_______\n[JUDUL]: ${judul}\n[ALBUM]: ${album}\n[RILIS]: ${dipublikasi}\n________________\nTUNGGU NYET${pap}`
                    await anto.sendFileFromUrl(from, thumb, 'thumb.jpg', `${capt}`, id)
                    await anto.sendFileFromUrl(from, mp3, 'tid.mp3', '```follow ig Hardianto02_```', id)
                } catch (err) {
                    await anto.reply(from, 'DONE NGAB', id)
                }
                break
            case 'ig':
            case 'igdl':
                 if (!isRegistered) return await anto.reply(from, ind.wrongFormat(), id)
                  if (!isUrl(url) && !url.includes('instagram.com')) return await anto.reply(from, `Link IG pak bukan link bkp`, id)
                const ig_dl = await axios.get(`http://lolhuman.herokuapp.com/api/instagram?apikey=${config.lol}&url=${url}`)
                try {
                    const igeh1 = ig_dl.data.result
                    const cept = '```'
                     const vid_buf = await fetch(igeh1);
                    const buffer = await vid_buf.buffer();
                    await fs.writeFile('./temp/igdl.mp4', buffer)
                    await anto.sendFile(from, './temp/igdl.mp4', 'igeh.mp4', `______[< IG DOWNLOAD >]______\n\n[Follow]: Hardianto02_\n__________________`, id)
                    await sleep(3000)
                    fs.unlinkSync('./temp/igdl.mp4')
                } catch {
                  anto.reply(from, 'Video Telah DiKirim', id)
                }
                break
            case 'facebook':
            case 'fb':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(pushname), id)
                if (!isUrl(url) && !url.includes('facebook.com')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                downloader.fb(url)
                    .then(async ({ result }) => {
                            await anto.sendFileFromUrl(from, result.VideoUrl, 'videofb.mp4', '', id)
                            console.log(from, 'Success sending Facebook video!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'ytmp3':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('youtu.be')) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                const music_yt = await axios.get(`http://lolhuman.herokuapp.com/api/ytaudio?apikey=${config.lol}&url=${url}`)
                try {
                const { title, uploader, duration, view, like, thumbnail, description, link } = music_yt.data.result
                const cpt = `${gaya}LAGU DI TEMUKAN ✨
💠 Title✨: ${title}
💠 Upload✨: ${uploader}
💠 Duration✨: ${duration}
💠 Views✨: ${view}
💠 Like✨ : ${like}
💠 Desc✨ : ${description}
   //////////////////////
   LAGU SEDANG DI KIRIM
  /////////////////////${gaya}`
                await anto.sendFileFromUrl(from, thumbnail, 'ytmp.jpg', `${cpt}`, id)
                const pree = await fetch(link[0].link);
                const buffer = await pree.buffer();
                await fs.writeFile('./temp/audio.mp3', buffer)
                await anto.sendFile(from, './temp/audio.mp3', 'lagu.mp3', '', id)
                } catch {
                anto.sendFileFromUrl(from, errorImg, 'lol.jpg', 'Lagu Gagal Di dapat Kan', id)
                }
            break
            case 'ytmp4':
                if (!isPremium) return await anto.reply(from, ind.notPremium())
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('youtu.be')) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                const ytbo = await axios.get(`https://api.zeks.xyz/api/ytmp4?url=${url}&apikey=${config.apivinz}`)
                try {
                    const titid3 = '```'
                    const { url_video, title, size, thumbnail } = ytbo.data.result
                    const get_vedo = await fetch(url_video);
                    const buffer = await get_vedo.buffer();
                    await fs.writeFile('./temp/ytmp4.mp4', buffer)
                    await anto.sendFileFromUrl(from, thumbnail, 'tumb.jpg', `${titid3}______[< YTMP4 >]______\n[Judul]: ${title}\n[Size]: ${size}\n______\nITAII YOOO\nPaimon Bot${titid3}`)
                    await anto.sendFile(from, './temp/ytmp4.mp4', 'ytmp44.mp4', '```Follow Ig Hardianto02_```', id)
                    await sleep(3000)
                    fs.unlinkSync('./temp/ytmp4.mp4')
                } catch (err) {
                    anto.reply(from, `Done Yah Kak ${pushname} Senpai Jangan Lupa Donate Supaya Owner Ku makin Semangat Ngembangin`, id)
                }
                break
            break
            case 'igstory':
            case 'igs':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.igSto(q)
                        .then(async ({ result }) => {
                            for (let i = 0; i < 5; i++) {
                                const { url, type } = await result[i]
                                await anto.sendFileFromUrl(from, url, `${q}.jpg`, '', id)
                                if (type === 'video'){
                                  anto.sendFileFromUrl(from, url, 'titi.mp4', '', id)
                                }
                                console.log('Success sending!!')
                            }
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'soundcloud':
            case 'scloud':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isUrl(url) && !url.includes('soundcloud.com')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                anto.reply(from, ind.ok(), id)
                const link_sound = await axios.get(`http://lolhuman.herokuapp.com/api/soundcloud?apikey=${config.lol}&url=${url}`)
                const { result, title } = link_sound.data
                const tod2 = '```'
                const capten = `${tod2}__________[< SOUND CLOUD>]___________\n Lagu Berhasil Di dapat kan!!\n[JUDUL]: ${title}${tod2}`
             await anto.sendText(from, capten)
                await anto.sendFileFromUrl(from, result, `${title}.mp3`, '', id)
                break
            
                case 'magernulis':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (ar[0] === '1') {
                await anto.reply(from, ind.wait(), id)
                const namae_ = q.substring(0, q.indexOf('|') + 1)
                const kelas_ = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') + 1)
                const catatan = q.substring(q.lastIndexOf('|') + 2)
                
                await anto.sendFileFromUrl(from, `https://api.zeks.xyz/api/magernulis?nama=${namae_}&kelas=${kelas_}&text=${catatan}&tinta=1`, `${namae_}.jpg`, '', id)
                }
                else if (ar[0] === '2') {
                  const namae_ = q.substring(0, q.indexOf('|') - 1)
                const kelas_ = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                const catatan = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `https://api.zeks.xyz/api/magernulis?nama=${namae_}&kelas=${kelas_}&text=${catatan}&tinta=2`, `${namae_}.jpg`, '', id)
                }
              else  if (ar[0] === '3') {
                  const namae_ = q.substring(0, q.indexOf('|') - 1)
                  const kelas_ = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                  const catatan = q.substring(q.lastIndexOf('|') + 2)
                  await anto.sendFileFromUrl(from, `https://api.zeks.xyz/api/magernulis?nama=${namae_}&kelas=${kelas_}&text=${catatan}&tinta=3`, `${namae_}.jpg`, '', id)
                }
                break
                
             case 'carbon':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/carbon?code=${q}&apikey=62c4d2562d61eae9308898ea`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
            case 'tiktok':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('tiktok.com')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                    if(isGroupMsg){
               /* const tiktik = await axios.get(`http://lolhuman.herokuapp.com/api/tiktok?apikey=62c4d2562d61eae9308898ea&url=${url}`)
                const { title, description, uploader, link } = tiktik.data.result
                const trsh_ = await anto.download(link)
                const titiy = trsh_.replace('application/octet-stream', 'vid/mp4')
                await fs.writeFile('./temp/tod.mp4', titiy)*/
               // const  cpet = `________[< TIKTOK >]_______\n*_Judul:_ ${title}*\n*_Upload:_ ${uploader}*\n*_Captiom:_ ${description}`
                    await anto.sendFileFromUrl(from, `https://lolhuman.herokuapp.com/api/tiktokwm?apikey=${config.lol}&url=${url}`, 'titik.mp4', '```FOLLOW IG : HARDIANTO02_```', id)
                    } else {
                        anto.reply(from, `_dalam group ${pushname}_`, id)
                    }
                break
                
            break
            case 'twitter':
            case 'twt':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('twitter.com')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                downloader.tweet(url)
                    .then(async (data) => {
                        if (data.type === 'video') {
                            const content = data.variants.filter((x) => x.content_type !== 'application/x-mpegURL').sort((a, b) => b.bitrate - a.bitrate)
                            const result = await misc.shortener(content[0].url)
                            console.log('Shortlink:', result)
                            await anto.sendFileFromUrl(from, content[0].url, 'video.mp4', `Link HD: ${result}`, id)
                                .then(() => console.log('Success sending Twitter media!'))
                                .catch(async (err) => {
                                    console.error(err)
                                    await anto.reply(from, 'Error!', id)
                                })
                        } else if (data.type === 'photo') {
                            for (let i = 0; i < data.variants.length; i++) {
                                await anto.sendFileFromUrl(from, data.variants[i], data.variants[i].split('/media/')[1], '', id)
                                .then(() => console.log('Success sending Twitter media!'))
                                .catch(async (err) => {
                                    console.error(err)
                                    await anto.reply(from, 'Error!', id)
                                })
                            }
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'moddroid': // Chikaa Chantekkzz
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                downloader.modroid(q)
                    .then(async ({ status, result }) => {
                        if (status !== 200) {
                            await anto.reply(from, 'Not found.', id)
                        } else {
                            await anto.sendFileFromUrl(from, result[0].image, 'ksk.jpg', `*「 MOD FOUND 」*\n\n➸ *APK*: ${result[0].title}\n\n➸ *Size*: ${result[0].size}\n➸ *Publisher*: ${result[0].publisher}\n➸ *Version*: ${result[0].latest_version}\n➸ *Genre*: ${result[0].genre}\n\n*Download link*\n${result[0].download}`, id)
                            console.log('Success sending APK mod!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'happymod': // chikaa chantexxzz
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                downloader.happymod(q)
                    .then(async ({ status, result }) => {
                        if (status !== 200) {
                            await anto.reply(from, 'Not found.', id)
                        } else {
                            await anto.sendFileFromUrl(from, result[0].image, 'ksk.jpg', `*「 MOD FOUND 」*\n\n➸ *APK*: ${result[0].title}\n\n➸ *Size*: ${result[0].size}\n➸ *Root*: ${result[0].root}\n➸ *Version*: ${result[0].version}\n➸ *Price*: ${result[0].price}\n\n*Download link*\n${result[0].download}`, id)
                            console.log('Success sending APK mod!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'linedl': // chikaa chantexxzz
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) return await anto.reply(from, ind.pcOnly(), id)
                if (!isUrl(url) && !url.includes('store.line.me')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                downloader.line(url)
                    .then(async (res) => {
                        await anto.sendFileFromUrl(from, res.thumb, 'line.png', `*「 LINE STICKER DOWNLOADER 」*\n\n➸ *Title*: ${res.title}\n➸ *Sticker type*: ${res.type}\n\n_Media sedang dikirim, mohon tunggu sebentar..._`, id)
                        for (let i = 0; i < res.sticker.length; i++) {
                            await anto.sendStickerfromUrl(from, `${res.sticker[i]}`)
                            console.log('Success sending Line sticker!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break

            // Misc
            case 'google': // chika-chantekkzz
            case 'googlesearch':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                google({ 'query': q, 'no-display': true })
                    .then(async (results) => {
                        let txt = `-----[ *GOOGLE SEARCH* ]-----\n\n*by: rashidsiregar28*\n\n_*Search results for: ${q}*_`
                        for (let i = 0; i < results.length; i++) {
                            txt += `\n\n➸ *Title*: ${results[i].title}\n➸ *Desc*: ${results[i].snippet}\n➸ *Link*: ${results[i].link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, txt, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'say':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendText(from, q)
            break
            case 'afk': // by Slavyan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (isAfkOn) return await anto.reply(from, ind.afkOnAlready(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const reason = q ? q : 'COLI'
                afk.addAfkUser(sender.id, time, reason, _afk)
                await anto.reply(from, ind.afkOn(pushname, reason), id)
            break
            case 'lyric':
            case 'lirik':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const xilos = await axios.get(`https://lolhuman.herokuapp.com/api/lirik/${q}?apikey=${config.lol}`)
                await anto.reply (from, xilos.data.result, id)
                break
            break
            case 'shortlink':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url)) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const urlShort = await misc.shortener(url)
                await anto.reply(from, ind.wait(), id)
                await anto.reply(from, urlShort, id)
                console.log('Success!')
            break
            case 'wikipedia':
            case 'wiki':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.wiki(q)
                    .then(async ({ result, status }) => {
                        if (status !== 200) {
                            return await anto.reply(from, 'Not found.', id)
                        } else {
                            await anto.reply(from, result, id)
                            console.log('Success sending Wiki!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'wikien': // By: VideFrelan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.wikien(q)
                    .then(async ( { result }) => {
                        if (result.status !== '200') {
                            await anto.reply(from, 'Not Found!', id)
                        } else {
                            await anto.reply(from, `➸ *PageId*: ${result.pageid}\n➸ *Title*: ${result.title}\n➸ *Result*: ${result.desc}`, id)
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'corona': // by CHIKAA CHANTEKKXXZZ
            case 'coronavirus':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.corona(q)
                    .then(async (res) => {
                        await anto.sendText(from, '🌎️ Covid Info - ' + q.charAt(0).toUpperCase() + q.slice(1) + ' 🌍️\n\n✨️ Total Cases: ' + `${res.cases}` + '\n📆️ Today\'s Cases: ' + `${res.todayCases}` + '\n☣️ Total Deaths: ' + `${res.deaths}` + '\n☢️ Today\'s Deaths: ' + `${res.todayDeaths}` + '\n⛩️ Active Cases: ' + `${res.active}` + '.')
                        console.log('Success sending Result!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'ttp': // CHIKAA CHANTEKKXXZZ
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.ttp(q)
                    .then(async (res) => {
                        await anto.sendImageAsSticker(from, res.base64)
                        console.log('Success creating TTP!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            
            case 'genshininfo': // chika chantexxzz
            case 'genshin':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    console.log('Searching for character...')
                    const character = await genshin.characters(q)
                    await anto.sendFileFromUrl(from, character.image, `${character.title}.jpg`, `*「 GENSHIN IMPACT 」*\n\n*${character.title}*\n${character.description}\n➸ *Name*: ${character.name}\n➸ *Nation*: ${character.nation}\n➸ *Gender*: ${character.gender}\n➸ *Birthday*: ${character.birthday}\n➸ *Constellation*: ${character.constellation}\n➸ *Rarity*: ${character.rarity}\n➸ *Vision*: ${character.vision}\n➸ *Weapon*: ${character.weapon}\n\n${character.url}`)
                    console.log('Success sending Genshin Impact character!')
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error or character not found!', id)
                }
            break
            case 'instastory': // By: VideFrelan
            case 'igstory':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.its(q)
                    .then(async ({ result }) => {
                        for (let i = 0; i < result.story.itemlist.length; i++) {
                            const { urlDownload } = result.story.itemlist[i]
                            await anto.sendFileFromUrl(from, urlDownload, '', 'By: VideFrelan', id)
                            console.log('Success sending IG Story!')
                        }
                    })
            break
            case 'kbbi':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.kbbi(q)
                    .then(async ({ result }) => {
                        await anto.reply(from, result.hasil, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'linesticker':
            case 'linestiker':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                if (!isOwner) limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.linesticker()
                    .then(async ({ result }) => {
                        let lines = '-----[ *NEW STICKER* ]-----'
                        for (let i = 0; i < result.hasil.length; i++) {
                            lines +=  `\n\n➸ *Title*: ${result.hasil[i].title}\n➸ *URL*: ${result.hasil[i].uri}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, lines, id)
                        console.log('Success sending sticker Line!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'jadwalsholat':
            case 'jadwalsolat':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                misc.jadwalSholat(q)
                    .then((data) => {
                        data.map(async ({isya, subuh, dzuhur, ashar, maghrib, terbit}) => {
                            const x = subuh.split(':')
                            const y = terbit.split(':')
                            const xy = x[0] - y[0]
                            const yx = x[1] - y[1]
                            const perbandingan = `${xy < 0 ? Math.abs(xy) : xy} jam ${yx < 0 ? Math.abs(yx) : yx} menit`
                            const msg = `Jadwal sholat untuk ${q} dan sekitarnya ( *${tanggal}* )\n\nDzuhur: ${dzuhur}\nAshar: ${ashar}\nMaghrib: ${maghrib}\nIsya: ${isya}\nSubuh: ${subuh}\n\nDiperkirakan matahari akan terbit pada pukul ${terbit} dengan jeda dari subuh sekitar ${perbandingan}`
                            await anto.reply(from, msg, id)
                            console.log('Success sending jadwal sholat!')
                        })
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'gempa':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.reply(from, ind.wait(), id)
                misc.bmkg()
                    .then(async ({ kedalaman, koordinat, lokasi, magnitude, map, potensi, waktu }) => {
                        const teksInfo = `${lokasi}\n\nKoordinat: ${koordinat}\nKedalaman: ${kedalaman}\nMagnitudo: ${magnitude} SR\nPotensi: ${potensi}\n\n${waktu}`
                        await anto.sendFileFromUrl(from, map, 'gempa.jpg', teksInfo, id)
                        console.log('Success sending info!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'artinama':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const pepep_ = await anto.getProfilePicFromServer(sender.id)
                if (pepep_ === undefined){
                    var pipip = errorImg
                } else {
                    var pipip = pepep_
                }
                const nama_udin = await axios.get(`https://lolhuman.herokuapp.com/api/artinama/${q}?apikey=${config.lol}`)
                const kt_cpt = `${nama_udin.data.result}`
                await anto.sendFileFromUrl(from, pipip, 'pp.jpg', `_________[ *ARTI NAMA*]_______\n_NAMA: ${q}_\n${kt_cpt}`)
                break
                case 'igstalk':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.igStalk(q)
                    .then(async ({ result }) => {
                        if (result === undefined) {
                            await anto.reply(from, 'Not found.', id)
                        } else {
                        const { photo_profile, username, fullname, posts, followers, following, bio } = result
                            const text = `*「 IG STALK 」*\n\n➸ *Username*: ${username}\n➸ *Bio*: ${bio}\n➸ *Full name*: ${fullname}\n➸ *Followers*: ${followers}\n➸ *Followings*: ${following}\n➸ *Total posts*: ${posts}`
                            await anto.sendFileFromUrl(from, photo_profile, 'insta.jpg', text, id)
                            console.log('Success sending IG stalk!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'gsmarena':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.gsmarena(q)
                        .then(async ({ result }) => {
                            await anto.sendFileFromUrl(from, result.image, `${result.title}.jpg`, ind.gsm(result), id)
                            console.log('Success sending phone info!')
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'receipt':
            case 'resep':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.resep(q)
                        .then(async ({ result }) => {
                            await anto.sendFileFromUrl(from, result.image, `${result.title}.jpg`, ind.receipt(result), id)
                            console.log('Success sending food receipt!')
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'humor':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/onecak?apikey=${config.lol}`, 'titid.jpg', '', id)
                break
            case 'quotecreate':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await reply (from, `*Masukan ${prefix}quoteCreate Teks nya*`, id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/quotemaker?apikey=${config.lol}&text=${q}`, `${pushname}.jpg`, '*INI KAK*', id)
                break
            case 'findsticker':
            case 'findstiker':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.sticker(q)
                        .then(async ({ sticker }) => {
                            //if (result.response !== 200) return await anto.reply(from, 'Not found!', id)
                            for (let i = 0; i < sticker.length; i++) {
                                await anto.sendStickerfromUrl(from, sticker[i])
                            }
                            console.log('Success sending sticker!')
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, `Error!\n\n${err}`, id)
                }
            break
            case 'movie':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.movie(q)
                    .then(async ({ result }) => {
                        let movies = `Result for: *${result.judul}*`
                        for (let i = 0; i < result.data.length; i++) {
                            movies +=  `\n\n➸ *Quality:* : ${result.data[i].resolusi}\n➸ *URL*: ${result.data[i].urlDownload}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        movies += '\n\nBy: VideFrelan'
                        await anto.reply(from, movies, id)
                        console.log('Success sending movie result!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'cekongkir': // By: VideFrelan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const kurir = q.substring(0, q.indexOf('|') - 1)
                const askot = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                const tukot = q.substring(q.lastIndexOf('|') + 2)
                misc.ongkir(kurir, askot, tukot)
                    .then(async ({ result }) => {
                        let onkir = `-----[ *${result.title}* ]-----`
                        for (let i = 0; i < result.data.length; i++) {
                            onkir +=  `\n\n➸ *Layanan*: ${result.data[i].layanan}\n➸ *Estimasi*: ${result.data[i].etd}\n➸ *Tarif*: ${result.data[i].tarif}\n➸ *Info*: ${result.informasi}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        onkir += '\n\nBy: VideFrelan'
                        await anto.reply(from, onkir, id)
                        console.log('Success sending ongkir info!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'distance':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kotaAsal = q.substring(0, q.indexOf('|') - 1)
                const kotaTujuan = q.substring(q.lastIndexOf('|') + 2)
                misc.distance(kotaAsal, kotaTujuan)
                    .then(async ({ result }) => {
                        if (result.response !== 200) {
                            await anto.reply(from, 'Error!', id)
                        } else {
                            await anto.reply(from, result.data, id)
                            console.log('Success sending distance info!')
                        }
                    })
            break
 
            case 'ytsearch':
                if (!q) return await anto.reply(from, 'Masukkan keyword pencarian!', id);{
                const nama = body.slice(10)
                   await yts(nama, function ( err, r ) {
                    const videos = r.videos.slice( 0, 10 )
                    let hasil = `🔎 Hasil pencarian youtube *'${nama}'* 🔍`
                    hasil += `\n`;
                    Object.keys(videos).forEach(function (i) {
                        hasil += `\n _*Judul : ${videos[i].title}*_\n_*- Channel : ${videos[i].author.name}*_\n_*- Durasi : ${videos[i].timestamp}*_\n*_- ${prefix}ytmp3/${prefix}ytmp4 https://www.youtube.com/watch?v=${videos[i].videoId}_*\n`;
                    });
                    hasil += '\n_*PAIMON yt search*_';
                        anto.sendFileFromUrl(from, videos[0].thumbnail,'thumb.jpg', hasil)
                    })
                }         
                break
            case 'arch':
            case 'yts':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
      /*          try {
      /             misc.ytSearch(q)
                        .then(async ({ result }) => {
                            for (let i = 0; i < 5; i++) {
                                const hmnel = result[0].thumbnails
                                const { views, title, link, duration, channel } = await result[i]

                                await anto.sendFileFromUrl(from, hmnel, `${title}.jpg`, ind.ytResult(link, title, channel, duration, views), id)
                                console.log('Success sending YouTube results!')
                            }
                        })
                } catch (err) {
    */
            break
            case 'tts':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const speech = q.substring(q.indexOf('|') + 2)
                const ptt = tts(ar[0])
                try {
                    ptt.save(`${speech}.mp3`, speech, async () => {
                        await anto.sendPtt(from, `${speech}.mp3`, id)
                        fs.unlinkSync(`${speech}.mp3`)
                    })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'bass':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isAudio || isQuotedAudio || isVoice || isQuotedVoice) {
                    if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedAudio || isQuotedVoice ? quotedMsg : message
                    console.log(color('[WAPI]', 'green'), 'Downloading and decrypting media...')
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const temp = './temp'
                    const name = new Date() * 1
                    const fileInputPath = path.join(temp, `${name}.mp3`)
                    const fileOutputPath = path.join(temp, 'audio', `${name}.mp3`)
                    fs.writeFile(fileInputPath, mediaData, (err) => {
                        if (err) return console.error(err)
                        ffmpeg(fileInputPath)
                            .audioFilter(`equalizer=f=40:width_type=h:width=50:g=${args[0]}`)
                            .format('mp3')
                            .on('start', (commandLine) => console.log(color('[FFmpeg]', 'green'), commandLine))
                            .on('progress', (progress) => console.log(color('[FFmpeg]', 'green'), progress))
                            .on('end', async () => {
                                console.log(color('[FFmpeg]', 'green'), 'Processing finished!')
                                await anto.sendPtt(from, fileOutputPath, id)
                                console.log(color('[WAPI]', 'green'), 'Success sending audio!')
                                setTimeout(() => {
                                    fs.unlinkSync(fileInputPath)
                                    fs.unlinkSync(fileOutputPath)
                                }, 30000)
                            })
                            .save(fileOutputPath)
                    })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'tomp3': // by: Piyobot
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if ((isMedia && isVideo || isQuotedVideo)) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedVideo ? quotedMsg : message
                    const _mimetype = isQuotedVideo ? quotedMsg.mimetype : mimetype
                    console.log(color('[WAPI]', 'green'), 'Downloading and decrypting media...')
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const temp = './temp'
                    const name = new Date() * 1
                    const fileInputPath = path.join(temp, 'video', `${name}.${_mimetype.replace(/.+\//, '')}`)
                    const fileOutputPath = path.join(temp, 'audio', `${name}.mp3`)
                    fs.writeFile(fileInputPath, mediaData, (err) => {
                        if (err) return console.error(err)
                        ffmpeg(fileInputPath)
                            .format('mp3')
                            .on('start', (commandLine) => console.log(color('[FFmpeg]', 'green'), commandLine))
                            .on('progress', (progress) => console.log(color('[FFmpeg]', 'green'), progress))
                            .on('end', async () => {
                                console.log(color('[FFmpeg]', 'green'), 'Processing finished!')
                                await anto.sendFile(from, fileOutputPath, 'audio.mp3', '', id)
                                console.log(color('[WAPI]', 'green'), 'Success sending mp3!')
                                setTimeout(() => {
                                    fs.unlinkSync(fileInputPath)
                                    fs.unlinkSync(fileOutputPath)
                                }, 30000)
                            })
                            .save(fileOutputPath)
                    })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'playstore':
            case 'ps':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.playstore(q)
                        .then(async ({ result }) => {
                            for (let i = 0; i < 5; i++) {
                                const { app_id, icon, title, developer, description, price, free } = result[i]
                                await anto.sendFileFromUrl(from, icon, `${title}.jpg`, ind.playstore(app_id, title, developer, description, price, free))
                            }
                            console.log('Success sending PlayStore result!')
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, `Error!\n\n${err}`, id)
                }
            break
            case 'math':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (typeof mathjs.evaluate(q) !== 'number') {
                    await anto.reply(from, ind.notNum(q), id)
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, `*「 MATH 」*\n\n${q} = ${mathjs.evaluate(q)}`, id)
                }
            break
            case 'shopee':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                const namaBarang = q.substring(0, q.indexOf('|') - 1)
                const jumlahBarang = q.substring(q.lastIndexOf('|') + 2)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                try {
                    misc.shopee(namaBarang, jumlahBarang)
                        .then(async ({ result }) => {
                            for (let i = 0; i < result.items.length; i++) {
                                const { nama, harga, terjual, shop_location, description, link_product, image_cover } = result.items[i]
                                await anto.sendFileFromUrl(from, image_cover, `${nama}.jpg`, ind.shopee(nama, harga, terjual, shop_location, description, link_product))
                            }
                            console.log('Success sending Shopee data!')
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, `Error!\n\n${err}`, id)
                }
            break
            case 'mutual':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) return await anto.reply(from, 'Command ini tidak bisa digunakan di dalam grup!', id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, 'Looking for a partner...', id)
                await anto.sendContact(from, register.getRegisteredRandomId(_registered))
                await anto.sendText(from, `Partner found: 🙉\n*${prefix}next* — find a new partner`)
            break
            case 'next':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) return await anto.reply(from, 'Command ini tidak bisa digunakan di dalam grup!', id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, 'Looking for a partner...', id)
                await anto.sendContact(from, register.getRegisteredRandomId(_registered))
                await anto.sendText(from, `Partner found: 🙉\n*${prefix}next* — find a new partner`)
            break
            case 'tafsir':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length === 0) return anto.reply(from, `Untuk menampilkan ayat Al-Qur'an tertentu beserta tafsir dan terjemahannya\ngunakan ${prefix}tafsir surah ayat\n\nContoh: ${prefix}tafsir Al-Mulk 10`, id)
                await anto.reply(from, ind.wait(), id)
                const responSurah = await axios.get('https://raw.githubusercontent.com/VideFrelan/words/main/tafsir.txt')
                const { data } = responSurah.data
                const idx = data.findIndex((post) => {
                    if ((post.name.transliteration.id.toLowerCase() === args[0].toLowerCase()) || (post.name.transliteration.en.toLowerCase() === args[0].toLowerCase())) return true
                })
                const nomerSurah = data[idx].number
                if (!isNaN(nomerSurah)) {
                    const responseh = await axios.get('https://api.quran.sutanlab.id/surah/'+ nomerSurah + '/'+ args[1])
                    const { data } = responseh.data
                    let pesan = ''
                    pesan += 'Tafsir Q.S. ' + data.surah.name.transliteration.id + ':' + args[1] + '\n\n'
                    pesan += data.text.arab + '\n\n'
                    pesan += '_' + data.translation.id + '_\n\n' + data.tafsir.id.long
                    await anto.reply(from, pesan, id)
                }
            break
            case 'listsurah':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.reply(from, ind.wait(), id)
                misc.listSurah()
                    .then(async ({ result }) => {
                        let list = '-----[ AL-QUR\'AN LIST ]-----\n\n'
                        for (let i = 0; i < result.list.length; i++) {
                            list += `${result.list[i]}\n\n`
                        }
                        await anto.reply(from, list, id)
                        console.log('Success sending Al-Qur\'an list!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'surah':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                misc.getSurah(args[0])
                    .then(async ({ result }) => {
                        await anto.reply(from, `${result.surah}\n\n${result.quran}`, id)
                        console.log('Success sending surah!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'hadis': // irham01
            case 'hadees':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 2) return await anto.reply(from, ind.hadis(), id)
                await anto.reply(from, ind.wait(), id)
                try {
                    if (ar[0] === 'darimi') {
                        const hdar = await axios.get(`https://api.hadith.sutanlab.id/books/darimi/${args[1]}`)
                        await anto.sendText(from, `${hdar.data.data.contents.arab}\n${hdar.data.data.contents.id}\n\n*H.R. Darimi*`, id)
                    } else if (ar[0] === 'ahmad') {
                        const hmad = await axios.get(`https://api.hadith.sutanlab.id/books/ahmad/${args[1]}`)
                        await anto.sendText(from, `${hmad.data.data.contents.arab}\n${hmad.data.data.contents.id}\n\n*H.R. Ahmad*`, id)
                    } else if (ar[0] === 'bukhari') {
                        const hbukh = await axios.get(`https://api.hadith.sutanlab.id/books/bukhari/${args[1]}`)
                        await anto.sendText(from, `${hbukh.data.data.contents.arab}\n${hbukh.data.data.contents.id}\n\n*H.R. Bukhori*`, id)
                    } else if (ar[0] === 'muslim') {
                        const hmus = await axios.get(`https://api.hadith.sutanlab.id/books/muslim/${args[1]}`)
                        await anto.sendText(from, `${hmus.data.data.contents.arab}\n${hmus.data.data.contents.id}\n\n*H.R. Muslim*`, id)
                    } else if (ar[0] === 'malik') {
                        const hmal = await axios.get(`https://api.hadith.sutanlab.id/books/malik/${args[1]}`)
                        await anto.sendText(from, `${hmal.data.data.contents.arab}\n${hmal.data.data.contents.id}\n\n*H.R. Malik*`, id)
                    } else if (ar[0] === 'nasai') {
                        const hnas = await axios.get(`https://api.hadith.sutanlab.id/books/nasai/${args[1]}`)
                        await anto.sendText(from, `${hnas.data.data.contents.arab}\n${hnas.data.data.contents.id}\n\n*H.R. Nasa'i*`, id)
                    } else if (ar[0] === 'tirmidzi') {
                        const htir = await axios.get(`https://api.hadith.sutanlab.id/books/tirmidzi/${args[1]}`)
                        await anto.sendText(from, `${htir.data.data.contents.arab}\n${htir.data.data.contents.id}\n\n*H.R. Tirmidzi*`, id)
                    } else if (ar[0] === 'ibnumajah') {
                        const hibn = await axios.get(`https://api.hadith.sutanlab.id/books/ibnu-majah/${args[1]}`)
                        await anto.sendText(from, `${hibn.data.data.contents.arab}\n${hibn.data.data.contents.id}\n\n*H.R. Ibnu Majah*`, id)
                    } else if (ar[0] === 'abudaud') {
                        const habud = await axios.get(`https://api.hadith.sutanlab.id/books/abu-daud/${args[1]}`)
                        await anto.sendText(from, `${habud.data.data.contents.arab}\n${habud.data.data.contents.id}\n\n*H.R. Abu Daud*`, id)
                    } else {
                        await anto.sendText(from, ind.hadis(), id)
                    }
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'asmaulhusna': // irham01
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                const asmaulHusna = await axios.get (`https://api-melodicxt-2.herokuapp.com/api/asmaallHusna?number=${args[0]}&apiKey=${config.melodic}`)
                const assna = asmaulHusna.data.result
                anto.sendFileFromUrl(from, 'https://i2.wp.com/seruni.id/wp-content/uploads/2016/09/Allah.png?resize=696%2C696&ssl=1', 'gambar.jpg', ind.asmaulHusna(assna), id)
            break
            case 'randomquran': // irham01
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                const ranquran = await axios.get('https://api.zeks.xyz/api/randomquran')
                const auquran = ranquran.data.result.audio
                await anto.reply(from, ind.randomQuran(ranquran), id)
                await anto.sendFileFromUrl(from, auquran, 'rquran.mp3', '', id)
            break
            case 'motivasi':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                misc.motivasi()
                    .then(async (body) => {
                        const motivasiSplit = body.split('\n')
                        const randomMotivasi = motivasiSplit[Math.floor(Math.random() * motivasiSplit.length)]
                        await anto.sendText(from, randomMotivasi)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            
            case 'whois':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.whois(args[0])
                    .then(async ({ result }) => {
                        await anto.reply(from, `*「 WHOIS 」*\n\n➸ *IP address*: ${result.ip_address}\n➸ *City*: ${result.city}\n➸ *Region*: ${result.region}\n➸ *Country*: ${result.country}\n➸ *ZIP code*: ${result.postal_code}\n➸ *Latitude and longitude*: ${result.latitude_longitude}\n➸ *Time zone*: ${result.time_zone}\n➸ *Call code*: ${result.calling_code}\n➸ *Currency*: ${result.currency}\n➸ *Language code*: ${result.languages}\n➸ *ASN*: ${result.asn}\n➸ *Organization*: ${result.org}`, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'email': // By: VideFrelan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                const emailTarget = q.substring(0, q.indexOf('|') - 1)
                const subjectEmail = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                const messageEmail = q.substring(q.lastIndexOf('|') + 2)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.email(emailTarget, subjectEmail, messageEmail)
                    .then(async ({ result }) => {
                        if (result.status === '204') {
                            await anto.reply(from, 'Server busy!', id)
                        } else {
                            await anto.reply(from, `*Success sending email*!\n➸ *Target*: ${emailTarget}\n➸ *Subject*: ${result.subjek}\n➸ *Message*: ${result.pesan}`, id)
                            console.log('Success sending email!')
                        }
                    })
            break
            case 'sms':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                const pesanPengirim = q.substring(0, q.indexOf('|') - 1)
                const nomorPenerima = q.substring(q.lastIndexOf('|') + 2)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.sms(nomorPenerima, pesanPengirim)
                    .then(async ({ status, pesan }) => {
                        if (status !== 'success') return await anto.reply(from, pesan, id)
                        await anto.reply(from, `Success sending SMS to: ${nomorPenerima}\nMessage: ${pesanPengirim}`, id)
                        console.log(`Success sending SMS to ${nomorPenerima}!`)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'toxic':
                if (!isRegistered) return await anto.reply(from , ind.notRegistered(), id)
                await anto.reply(from, toxic(), id)
            break
            case 'alkitab':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.reply(from, ind.wait(), id)
                misc.alkitab(q)
                    .then(async ({ result }) => {
                        let alkitab = '-----[ *AL-KITAB* ]-----'
                        for (let i = 0; i < result.length; i++) {
                            alkitab +=  `\n\n➸ *Ayat*: ${result[i].ayat}\n➸ *Isi*: ${result[i].isi}\n➸ *Link*: ${result[i].link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, alkitab, id)
                        console.log('Success sending Al-Kitab!')
                    })
            break
            case 'reminder': // by Slavyan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const timeRemind = q.substring(0, q.indexOf('|') - 1)
                const messRemind = q.substring(q.lastIndexOf('|') + 2)
                const parsedTime = ms(toMs(timeRemind))
                reminder.addReminder(sender.id, messRemind, timeRemind, _reminder)
                await anto.sendTextWithMentions(from, `*「 REMINDER 」*\n\nReminder diaktifkan! :3\n\n➸ *Pesan*: ${messRemind}\n➸ *Durasi*: ${parsedTime.hours} jam ${parsedTime.minutes} menit ${parsedTime.seconds} detik\n➸ *Untuk*: @${sender.id.replace('@c.us', '')}`, id)
                const intervRemind = setInterval(async () => {
                    if (Date.now() >= reminder.getReminderTime(sender.id, _reminder)) {
                        await anto.sendTextWithMentions(from, `⏰ *「 REMINDER 」* ⏰\n\nAkhirnya tepat waktu~ @${sender.id.replace('@c.us', '')}\n\n➸ *Pesan*: ${reminder.getReminderMsg(sender.id, _reminder)}`)
                        _reminder.splice(reminder.getReminderPosition(sender.id, _reminder), 1)
                        fs.writeFileSync('./database/user/reminder.json', JSON.stringify(_reminder))
                        clearInterval(intervRemind)
                    }
                }, 1000)
            break
            case 'imagetourl':
            case 'imgtourl':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                    await anto.reply(from, linkImg, id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'infohoax':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.infoHoax()
                    .then(async ({ result }) => {
                        let txt = '*「 HOAXES 」*'
                        for (let i = 0; i < result.length; i++) {
                            const { tag, title, link } = result[i]
                            txt += `\n\n➸ *Status*: ${tag}\n➸ *Deskripsi*: ${title}\n➸ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.sendFileFromUrl(from, result[0].image, 'hoax.jpg', txt, id)
                        console.log('Success sending info!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'trending':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.trendingTwt()
                    .then(async ({ result }) => {
                        let txt = '*「 TRENDING TWITTER 」*'
                        for (let i = 0; i < result.length; i++) {
                            const { hastag, rank, tweet, link } = result[i]
                            txt += `\n\n${rank}. *${hastag}*\n➸ *Tweets*: ${tweet}\n➸ *Link*: ${link}`
                        }
                        await anto.reply(from, txt, id)
                        console.log('Success sending trending!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'jobseek':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.jobSeek()
                    .then(async ({ result }) => {
                        let txt = '*「 JOB SEEKER 」*'
                        for (let i = 0; i < result.length; i++) {
                            const { perusahaan, link, profesi, gaji, lokasi, pengalaman, edukasi, desc, syarat } = result[i]
                            txt += `\n\n➸ *Perusahaan*: ${perusahaan}\n➸ *Lokasi*: ${lokasi}\n➸ *Profesi*: ${profesi}\n➸ *Gaji*: ${gaji}\n➸ *Pengalaman*: ${pengalaman}\n➸ *Deskripsi*: ${desc}\n➸ *Syarat*: ${syarat}\n➸ *Edukasi*: ${edukasi}\n➸ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, txt, id)
                        console.log('Success sending jobseek!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'call':
            case 'spamcall':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.call(q)
                    .then(async ({ result }) => {
                        await anto.reply(from, result.logs, id)
                        console.log(`Success calling number: ${q}`)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'spamsms':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 2) return await anto.reply(from, ind.wrongFormat(), id)
                if (isNaN(Number(args[0])) && isNaN(Number(args[1]))) return await anto.reply(from, ind.wrongFormat(), id)
                if (Number(args[1]) > 10) return await anto.reply(from, 'Maximum 10 SMS.', id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.spamsms(args[0], args[1])
                    .then(async ({ status, logs, msg }) => {
                        if (status !== 200) {
                            await anto.reply(from, msg, id)
                        } else {
                            await anto.reply(from, logs, id)
                            console.log('Success sending spam!')
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'translate':
            case 'trans':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
             //   if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (quotedMsg) {
                    const reply_ = quotedMsgObj.chatId
                translate(reply_, {to: q}).then(res => {anto.reply(from, res.text, id)})
                } else {
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat())
                const texto = q.substring(0, q.indexOf('|') - 1)
                const languaget = q.substring(q.lastIndexOf('|') + 2)
                translate(texto, {to: languaget}).then(res => {anto.reply(from, res.text, id)})
                }
            break

            // Bot
            case 'premiummenu':
            case 'vipmenu':
            case 'premmenu':
            case 'mastahmenu':
              if (!isPremium) return await anto.reply(from, ind
              .notPremium)
            await anto.sendText(from, ind.premiumMenu(pushname), id)
            break
            case 'textpromenu':
            case 'makermenu':
            await anto.sendText(from, ind.menuText(), id)
            break
            case 'infobot':
            const totalch = await anto.getAllChatIds()
            const totalgb = await anto.getAllGroups()
            const cashp = await anto.getBatteryLevel()
            const cashp_ = await anto.getIsPlugged()
            const uptimo = process.uptime()
            const uptimer_ = `❏${formater(uptimo)}`
            await anto.sendFileFromUrl(from, ppbot, 'pp.jpg', ind.InfoBot(uptimer_, totalch, totalgb, cashp, cashp_ ? '🔌TERCOLOK' : 'NOT CHARGE'))
            case 'donasi':
             const pphardi = `https://telegra.ph/file/86fc10ad4da473d69ddc2.jpg`
             await anto.sendFileFromUrl(from, pphardi, 'pp.jpg', `${ind.menDonasi(ownerNumber, pushname)}`, id)
            break
            case 'menu':
            case 'help':
                const pret_ = '```'
                const jumlahUser = _registered.length
                const duit_ = checkATMuser(sender.id, uang)
                const levelMenu = level.getLevelingLevel(sender.id, _level)
                const xpMenu = level.getLevelingXp(sender.id, _level)
                const reqXpMenu = 5 * Math.pow(levelMenu, 2) + 50 * 1 + 100
                const name_tag = `@${sender.id.replace('@c.us', '')}`
                const uptime_ = process.uptime()
                const sepp_ = `❏${formater(uptime_)}`
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendTextWithMentions(from, ind.menu(jumlahUser, levelMenu, xpMenu, role, pushname, reqXpMenu, isPremium ? '👑' : '❌', duit_, pret_, name_tag, sepp_))  
                break
                case 'downloadmenu':
                    await anto.sendText(from, ind.menuDownloader())
                    break
                case 'botmenu':
                    await anto.sendText(from, ind.menuBot())
                    break
                case 'othermenu':
                    await anto.sendText(from, ind.menuMisc())
                    break
                case 'stickermenu':
                    await anto.sendText(from, ind.menuSticker())
                    break
                case 'animemenu':
                case 'menuanime':
                    await anto.sendText(from, ind.menuWeeaboo())
                    break
                case 'funmenu':
                    await anto.sendText(from, ind.menuFun())
                    break
                case 'adminmenu':
                case 'admin':
                    await anto.sendText(from, ind.menuModeration())
                    break
                    case 'nsfwmenu':
                    if (isGroupMsg && !isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    await anto.sendText(from, ind.menuNsfw())
                    break
                    case 'ownermenu':
                    case 'antoganteng':
                    if (!isOwner) return await anto.reply(from, ind.ownerOnly())
                    await anto.sendText(from, ind.menuOwner())
                    break
                    case 'levelset':
                    if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                    await anto.sendText(from, ind.menuLeveling())
                    break
            case 'rules':
            case 'rule':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendText(from, ind.rules())
            break
            case 'nsfw':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (ar[0] === 'enable') {
                    if (isNsfw) return await anto.reply(from, ind.nsfwAlready(), id)
                    _nsfw.push(groupId)
                    fs.writeFileSync('./database/group/nsfw.json', JSON.stringify(_nsfw))
                    await anto.reply(from, ind.nsfwOn(), id)
                } else if (ar[0] === 'disable') {
                    _nsfw.splice(groupId, 1)
                    fs.writeFileSync('./database/group/nsfw.json', JSON.stringify(_nsfw))
                    await anto.reply(from, ind.nsfwOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'status':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendText(from, `*RAM*: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB / ${Math.round(os.totalmem / 1024 / 1024)} MB\n*CPU*: ${os.cpus()[0].model}`)
            break
            case 'listblock':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                let block = ind.listBlock(blockNumber)
                for (let i of blockNumber) {
                    block += `@${i.replace('@c.us', '')}\n`
                }
                await anto.sendTextWithMentions(from, block)
            break
            case 'ownerbot':
            case 'owner':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendContact(from, ownerNumber)
                const capten_ = `${gaya}
✨✨✨✨✨✨ PROFILE ✨✨✨✨✨✨✨
🌸NAMA: HARDIANTO✨
🌸KELAS: XI.MIPA✨
🌸UMUR: 17 TAHUN
🌸ANAK KE: 2 DARI 3 Bersaudara
🌸HOBBY: MAEN GAME
🌸ALAMAT: SULSEL, MAKASSAR, PINRANG
________________________
////////////////////////
________________________${gaya}`
                const profil_ = `https://telegra.ph/file/86fc10ad4da473d69ddc2.jpg`
                await anto.sendFileFromUrl(from, profil_, 'not.jpg', `${capten_}`, id)
            break
            case 'runtime': // BY HAFIZH
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                const uptime = process.uptime()
                await anto.reply(from, `── *「 BOT UPTIME 」* ──\n\n ❏${formater(uptime)}`, id)
            break
            case 'ping':
            case 'p':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                const loadedMsg = await anto.getAmountOfLoadedMessages()
                const botadmins = await anto.iAmAdmin()
                const blockedd = await anto.getBlockedIds()
                const chatIds = await anto.getAllChatIds()
                const groups = await anto.getAllGroups()
                const me = await anto.getMe()
                const battery = await anto.getBatteryLevel()
                const isCharging = await anto.getIsPlugged()
               // const timestamp = speed();
        //     const latensi = speed() - timestamp
                await anto.reply(from, `*「 𝗦𝗧𝗔𝗧𝗨𝗦 𝗣𝗖 」*\nPenggunaan RAM: ${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / ${Math.round(require('os').totalmem / 1024 / 1024)}MB\nCPU: ${os.cpus()[0].model}\n\n*「 𝗦𝗧𝗔𝗧𝗨𝗦 𝗠𝗘𝗦𝗦𝗔𝗚𝗘 」* :\n- *${loadedMsg}* Loaded Messages\n- *${chatIds.length - groups.length}* Total Chats\n  ├ *${groups.length}* Group Chats\n  └ *${chatIds.length}* Personal Chats\n- *${groups.length}* Groups Joined\n\n*「 𝗦𝗧𝗔𝗧𝗨𝗦 𝗨𝗦𝗘𝗥 」*\n- *${_registered.length}* Registered User\n  \n\n*「 𝗦𝗧𝗔𝗧𝗨𝗦 𝗗𝗘𝗩𝗜𝗖𝗘 」*\n${(`\n*Battery* : ${battery}% ${isCharging ? 'Lagi Di Cas...' : 'Ga Di Cas!'}\n${Object.keys(me.phone).map(key => `${key} : ${me.phone[key]}`).join('\n')}`.slice(1, -1))}\n\n\n`, id)
                
                await anto.sendText(from, `Pong!\nSpeed: ${processTime(t, moment())} secs`)
            break
            case 'delete':
            case 'del':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!quotedMsg) return await anto.reply(from, ind.wrongFormat(), id)
                if (!quotedMsgObj.fromMe) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.deleteMessage(quotedMsgObj.chatId, quotedMsgObj.id, false)
            break
            case 'report':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.emptyMess(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const lastReport = daily.getLimit(sender.id, _daily)
                if (lastReport !== undefined && cd - (Date.now() - lastReport) > 0) {
                    const time = ms(cd - (Date.now() - lastReport))
                    await anto.reply(from, ind.daily(time), id)
                } else {
                    if (isGroupMsg) {
                        await anto.sendText(ownerNumber, `-----[ REPORT ]-----\n\n*From*: ${pushname}\n*ID*: ${sender.id}\n*Group*: ${(name || formattedTitle)}\n*Message*: ${q}`)
                        await anto.reply(from, ind.received(pushname), id)
                    } else {
                        await anto.sendText(ownerNumber, `-----[ REPORT ]-----\n\n*From*: ${pushname}\n*ID*: ${sender.id}\n*Message*: ${q}`)
                        await anto.reply(from, ind.received(pushname), id)
                    }
                    daily.addLimit(sender.id, _daily)
                }
            break
            case 'tos':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                await anto.sendLinkWithAutoPreview(from, 'https://github.com/SlavyanDesu/BocchiBot', ind.tos(ownerNumber))
            break
            case 'join':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('chat.whatsapp.com')) return await anto.reply(from, ind.wrongFormat(), id)
                const checkInvite = await anto.inviteInfo(url)
                if (isPremium) {
                    await anto.joinGroupViaLink(url)
                    await anto.reply(from, ind.ok(), id)
                    await anto.sendText(checkInvite.id, `Hello!! I was invited by ${pushname}`)
                } else {
                  await anto.reply(from, 'Maaf Donasi Dlu Ke Owner Untuk Memasukkan Bot Ke Group')
                }
                
            break
            case 'premiumcheck':
            case 'cekpremium':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                const cekExp = ms(premium.getPremiumExpired(sender.id, _premium) - Date.now())
                await anto.reply(from, `*「 PREMIUM EXPIRE 」*\n\n➸ *ID*: ${sender.id}\n➸ *Premium left*: ${cekExp.days} day(s) ${cekExp.hours} hour(s) ${cekExp.minutes} minute(s)`, id)
            break
            case 'premiumlist':
            case 'listpremium':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                let listPremi = '「 *PREMIUM USER LIST* 」\n\n'
                const deret = premium.getAllPremiumUser(_premium)
                const arrayPremi = []
                for (let i = 0; i < deret.length; i++) {
                    const checkExp = ms(premium.getPremiumExpired(deret[i], _premium) - Date.now())
                    arrayPremi.push(await anto.getContact(premium.getAllPremiumUser(_premium)[i]))
                    listPremi += `${i + 1}. wa.me/${premium.getAllPremiumUser(_premium)[i].replace('@c.us', '')}\n➸ *Name*: ${arrayPremi[i].pushname}\n➸ *Expired*: ${checkExp.days} day(s) ${checkExp.hours} hour(s) ${checkExp.minutes} minute(s)\n\n`
                }
                await anto.reply(from, listPremi, id)
            break
            case 'getpic':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (mentionedJidList.length !== 0) {
                    const userPic = await anto.getProfilePicFromServer(mentionedJidList[0])
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    if (userPic === undefined) {
                        var pek = errorImg
                    } else {
                        pek = userPic
                    }
                    await anto.sendFileFromUrl(from, pek, 'pic.jpg', '', id)
                } else if (args.length !== 0) {
                    const userPic = await anto.getProfilePicFromServer(args[0] + '@c.us')
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    if (userPic === undefined) {
                        var peks = errorImg
                    } else {
                        peks = userPic
                    }
                    await anto.sendFileFromUrl(from, peks, 'pic.jpg', '', id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'serial':
                if (!isRegistered) return await anto.reply(from, ind.registered(), id)
                if (isGroupMsg) return await anto.reply(from, ind.pcOnly(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                const serials = args[0]
                if (register.checkRegisteredUserFromSerial(serials, _registered)) {
                    const name = register.getRegisteredNameFromSerial(serials, _registered)
                    const age = register.getRegisteredAgeFromSerial(serials, _registered)
                    const time = register.getRegisteredTimeFromSerial(serials, _registered)
                    const id = register.getRegisteredIdFromSerial(serials, _registered)
                    await anto.sendText(from, ind.registeredFound(name, age, time, serials, id))
                } else {
                    await anto.sendText(from, ind.registeredNotFound(serials))
                }
            break
            case 'limit':
                if (isPremium || isOwner) return await anto.reply(from, '⤞ Limit left: ∞ (UNLIMITED)', id)
                await anto.reply(from, `⤞ Limit left: ${limit.getLimit(sender.id, _limit, limitCount)} / 25\n\n*_Limit direset pada pukul 00:00 WIB_*`, id)
            break

            //EDUCATION
            case 'kelpersegi':
                if (!isRegistered) return await anto.reply(from, ind.registered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const persegi = bdr.datar.keliling.persegi(q, false)
                const caraPersegi = bdr.datar.keliling.persegi(q, true)
                await anto.reply(from, `*Hasil*: ${persegi}\n*Rumus*: ${caraPersegi}`, id)
            break
            case 'luaspersegi':
                if (!isRegistered) return await anto.reply(from, ind.registered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const luaspersegi = bdr.datar.luas.persegi(q, false)
                const luaspersegis = bdr.datar.luas.persegi(q, true)
                await anto.reply(from, `*Hasil*: ${luaspersegi}\n*Rumus*: ${luaspersegis}`, id)
            break
            case 'kuadrat':
                if (!isRegistered) return await anto.reply(from, ind.registered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kuadrat = bdr.rdb.kuadrat(q)
                await anto.reply(from, `*Hasil*: ${kuadrat}`, id)
            break
            case 'kubik':
                if (!isRegistered) return await anto.reply(from, ind.registered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kubik = bdr.rdb.kubik(q)
                await anto.reply(from, `*Hasil*: ${kubik}`, id)
            break

            // Weeb zone
            case 'neko':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Getting neko image...')
                await anto.sendFileFromUrl(from, (await neko.sfw.neko()).url, 'neko.jpg', '', null, null, true)
                    .then(() => console.log('Success sending neko image!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break 
            // TEXTPRO
            case 'pornlogo':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const porn1 = q.substring(0, q.indexOf('|') - 1)
                const hub2 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/pornhub?apikey=${config.lol}&text1=${porn1}/text2=${hub2}`, 'phlogo.jpg', '```Follow Ig : Hardianto02_```', id)
                break
             case 'avenger':
                case 'aven':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire = q.substring(0, q.indexOf('|') - 1)
                const kore = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/avenger/${kire}/${kore}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'space':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire1 = q.substring(0, q.indexOf('|') - 1)
                const kore2 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/space/${kire1}/${kore2}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'ninja':
                case 'logoninja':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire3 = q.substring(0, q.indexOf('|') - 1)
                const kore3 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/ninjalogo/${kire3}/${kore3}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'marvel':
                case 'marvelstudio':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire4 = q.substring(0, q.indexOf('|') - 1)
                const kore4 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/marvelstudio/${kire4}/${kore4}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
   
               case 'gltext':
                case 'glitch':
                case 'glitchtext':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const nama_kiri = q.substring(0, q.indexOf('|') - 1)
                const nama_kanan = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/glitch/${nama_kiri}/${nama_kanan}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'lion':
                case 'lionlogo':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire5 = q.substring(0, q.indexOf('|') - 1)
                const kore5 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/lionlogo/${kire5}/${kore5}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'wolf':
                case 'wolflogo':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire6 = q.substring(0, q.indexOf('|') - 1)
                const kore6 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/wolflogo/${kire6}/${kore6}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'steel':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const kire7 = q.substring(0, q.indexOf('|') - 1)
                const kore7 = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/steel3d/${kire7}/${kore7}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                // END Double TEXT
                //SINGLE TEXT pcOnly
                case 'neongreen':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
               // if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/greenneon/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'advanced':
              case 'advance':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
             //   if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/advanceglow/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
               case 'future':
               case 'futureneon':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
               // if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/futureneon/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'sandwrite':
              case 'sandwriting':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
            //    if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/sandwriting/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
             case 'sandsummer':
              case 'pasir':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              //  if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/sandsummer/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'sandengraved':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
               // if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/sandengraved/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'metaldark':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/metaldark/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'neonlight':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/neonlight/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
               case 'text1917':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/text1917/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'minion':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/minion/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'newyear':
                case 'newyearcard':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/newyearcard/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'deluxesilver':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/deluxesilver/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
                case 'bloodfrosted':
                case 'blood':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/bloodfrosted/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'halloween':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/halloween/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'jokerlogo':
              case 'joker':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/jokerlogo/${q}?apikey=${config.lol}`, 'gltext.jpg', '```Follow Ig : Hardianto02_```')
                break
              case 'firemaker':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/fireworksparkle/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'natureleaves':
              case 'leaves':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/natureleaves/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'bokeh':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/bokeh/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'strawberry':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/strawberry/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'box3d':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/box3d/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'roadwarning':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/roadwarning/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'breakwall':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/breakwall/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'icecold':
              case 'snow':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/icecold/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
             case 'cloud':
               if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/cloud/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'luxury':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/luxury/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'summersand':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/summersand/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
               case 'horrorblood':
                 if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/horrorblood/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
              case 'thunder':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/thunder/${q}?apikey=${config.lol}`, 'bam.jpg', '```Follow IG : @Hardianto02_```', id)
                  break
          /*    case '':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const simemed = await axios.get(`http://lolhuman.herokuapp.com/api/simi/${q}?apikey=${config.lol}`)
                const { message, result } = simemed.data
                const textSimi = `${result}`
                await anto.reply(from, textSimi, id)
                break*/
  case 'teksmenu':
      case 'makemenu':
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/textprome/glitch/welcome/${pushname}?apikey=${config.lol}`, 'titid.jpg', ind.menuText(), id)
                break
            // IMAGE Search
            case 'wallpaper':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              const wlper = await axios.get(`http://lolhuman.herokuapp.com/api/wallpaper?apikey=${config.lol}&query=${q}`)
              await anto.sendFileFromUrl(from, wlper.data.result, `${q}.jpg`, `${gaya}HASIL PENCARIAN = ${q}${gaya}`, id)
              break
             case '?' :
                 const axis = await axios.get(`https://lolhuman.herokuapp.com/api/simi/${q}?apikey=${config.lol}`)
                 await anto.reply(from, axis.data.result, id)
                 break
                case 'brainly':
                    if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const brenly = await axios.get(`https://lolhuman.herokuapp.com/api/brainly/${q}?apikey=${config.lol}`)
                let hoho_ = `_*Soal: ${q}*_\n`
            for (let i = 0; i < brenly.data.result.length; i++) {
                hoho_ += `\n\n*_PERTANYAAN_* : ${brenly.data.result[i].title}\n`
                hoho_ += `\n\n_JAWABAN :_ ${brenly.data.result[i].url}\n`
            }
            
            hoho_ += '👑〘 *P A I M O N   B O T* 〙👑'
            await anto.sendText(from, hoho_)
            break
            case 'circlesticker':
		case 'csticker':
				try{
					if (isMedia && type === 'image'){
					const mediaData = await decryptMedia(message, uaOverride)
					const data = await uploadImages(mediaData);
					const dimensions = data.width <= data.height ? data.width : data.height;
					const canvas = createCanvas(dimensions, dimensions);
					const ctx = canvas.getContext('2d');
					ctx.beginPath();
					ctx.arc(canvas.width / 2, canvas.height / 2, canvas.height / 2, 0, Math.PI * 2);
					ctx.ClosePath();
					ctx.clip();
					ctx.drawImage(data, (canvas.width / 2) - (data.width / 2), (canvas.height / 2) - (data.height /2));
					const base64x = `data:image/png;base64,${canvas.toBuffer().toString('base64')}`
					anto.sendImageAsSticker(from, base64x)
					}
				}catch(err){
					console.log(err)
				}
				break

            case 'sfrez':
            case 'dinginkan':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                const flowers_ = await axios.get(`https://api.zeks.xyz/api/cloudy?img=${linkImg}&apikey=apivinz`)
                await anto.sendStickerfromUrl(from, flowers_.data.result)
              } else {
                const pp_real_ = await anto.getProfilePicFromServer(sender.id)
                if (pp_real_ === undefined) {
                  var pp_else_ = errorImg
                } else {
                  pp_else_ = pp_real_
                }
                const datapp_ = await bent('buffer')(pp_else_)
                const linkpp_ = await uploadImages(datapp_, `${sender.id}_ph`)
               const folower_pp = await axios.get(`https: //api.zeks.xyz/api/cloudy?img=${linkpp_}&apikey=apivinz`)
               await anto.sendStickerfromUrl(from, folower_pp.data.result)
              } 
              break
              case 'pinterest':
              case 'pint':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              const wlpor = await axios.get(`http://lolhuman.herokuapp.com/api/pinterest?apikey=${config.lol}&query=${q}`)
              await anto.sendFileFromUrl(from, wlpor.data.result, 'pinterest.jpg', '```HASIL PENCARIAN:'+q+'```', id)
              break
              case 'pixiv':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/pixiv?apikey=${config.lol}&query=${q}`, 'pixiv.jpg', `${gaya}HASIL PENCARIAN: ${q}${gaya}`, id)
              break
              case 'googleimage':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!q) return await anto.reply(from, ind.wrongFormat())
              if (isPremium) {
              const google_ = await axios.get(`http://lolhuman.herokuapp.com/api/gimage2?apikey=${config.lol}&query=${q}`)
              const google1_ = google.data.result
              for (let i = 0; i < google1_.length; i++) {
              await anto.sendFileFromUrl(from, google1_[i], 'google.jpg', '', id)
              }
              } else {
               await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/gimage?apikey=${config.lol}&query=${q}`, 'google.jpg', '```Hasil Pencarian:'+q+'```', id)
              }
              break
              case 'Konachan':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat())
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                try {
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/konachan?apikey=${config.lol}&query=${q}`, 'pi.jpg', '', id)
                } catch {
                  anto.sendFileFromUrl(from, errorImg, 'emror.jpg', `${gaya}Maaf Kak ${pushname} Gambar ${q} Tidak Ditemukan${gaya}`, id)
                }
                break
            case 'wallpapernime':
            case 'wp':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Getting wallpaper image...')
                await anto.sendFileFromUrl(from, (await neko.sfw.wallpaper()).url, 'wallpaper.jpg', '', null, null, true)
                    .then(() => console.log('Success sending wallpaper image!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id )
                    })
            break
            case 'sflow':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                  const flowers_ = await axios.get(`https://api.zeks.xyz/api/springflow?img=${linkImg}&apikey=apivinz`)
                  await anto.sendFileFromUrl(from, flowers_.data.result, 'sw.jpg', '', id)
           //       await anto.sendStickerfromUrl(from, flowers_.data.result)
                } else {
                  const pp_real = await anto.getProfilePicFromServer(sender.id)
                  if (pp_real === undefined) {
                    var pp_else = errorImg
                  } else {
                    pp_else = pp_real
                  }
                  const datapp = await bent('buffer')(pp_else)
                  const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
                 const folowers_pp = await axios.get(`https://api.zeks.xyz/api/springflow?img=${linkpp}&apikey=apivinz`)
                 await anto.sendFileFromUrl(from, folowers_pp.data.result, 'sw.jpg', '', id)
              //   await anto.sendStickerfromUrl(from, folowers_pp.data.result)
                } 
                break
                case 'sfire':
                    case 'bakar':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                  const flowers_1 = await axios.get(`https://api.zeks.xyz/api/sfire?img=${linkImg}&apikey=apivinz`)
                 await anto.sendStickerfromUrl(from, flowers_1.data.result, id)
                } else {
                  const pp_real_ = await anto.getProfilePicFromServer(sender.id)
                  if (pp_real_ === undefined) {
                    var pp_else_ = errorImg
                  } else {
                    pp_else_ = pp_real_
                  }
                  const datapp_ = await bent('buffer')(pp_else_)
                  const linkpp_ = await uploadImages(datapp_, `${sender.id}_ph`)
                 const folower_pp = await axios.get(`https://api.zeks.xyz/api/sfire?img=${linkpp_}&apikey=apivinz`)
           //      await anto.sendFileFromUrl(from, folower_pp.data.result, 'sw.jpg', '', id)
                await anto.sendStickerfromUrl(from, folower_pp.data.result, id)
                } 
                break
                // random
            case 'nsfwloli':
              if (!isNsfw) return await anto.reply(from, ind.notNsfw())
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium())
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/nsfw/loli?apikey=${config.lol}`, 'loli.jpg', '*HARGAI LOLI*\n*CINTAI LOLI*\n*LOLIPAY*', id)
              break
              case 'nsfwloli2':
              if (!isNsfw) return await anto.reply(from, ind.notNsfw())
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium())
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/nsfw/chiisaihentai?apikey=${config.lol}`, 'loli.jpg', '*HARGAI LOLI*\n*CINTAI LOLI*\n*LOLIPAY*', id)
              break
            case 'loli':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/loli?apikey=${config.lol}`, 'loli.jpg', '*LOLI OM*', id)
              break
            case 'shota':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const mgeb = `http://lolhuman.herokuapp.com/api/random/shota?apikey=${config.lol}`
                await anto.sendFileFromUrl(from, mgeb, 'bocul.jpg', 'TANTE!!!', id)
                break
            case 'bts':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/bts?apikey=${config.lol}`, 'betees.jpg', '*OPPA NYA KAK*', id)
                break
            case 'fanart':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/art?apikey=${config.lol}`, 'fanart.jpg', '*FANTART*', id)
                break
            case 'exo':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              const exot = `http://lolhuman.herokuapp.com/api/random/exo?apikey=${config.lol}`
              await anto.sendFileFromUrl(from, exot, 'exo.jpg', '*E X O nya Kaka*', id)
              break
           case 'shinobu':
             if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/shinobu?apikey=${config.lol}`, 'shinlbat.jpg', '*HEHEHE*', id)
                break
           case 'ecchi':
             if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
             if (!nsfw) return await anto.reply(from, ind.notNsfw(), id)
             await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/nsfw/ecchi?apikey=${config.lol}`, 'hntg.jpg', '*SANGE OM*', id)
             break
           case 'husbu':
             if (!isPremium) return await anto.reply(from, ind.notPremium())
             if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/husbu?apikey=${config.lol}`, 'husbu.jpg', '*HUSBU nya kakak*', id)
                break
           case 'elf':
             if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/random/elf?apikey=${config.lol}`, 'elf.jpg', '*E L F Nya Kakak', id)
                break
                // end srpat
            case 'kemono':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Getting kemonomimi image...')
                await anto.sendFileFromUrl(from, (await neko.sfw.kemonomimi()).url, 'kemono.jpg', '', null, null, true)
                    .then(() => console.log('Success sending kemonomimi image!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'kusonime':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.anime(q)
                    .then(async ({ info, link_dl, sinopsis, thumb, title, error, status }) => {
                        if (status === false) {
                            return await anto.reply(from, error, id)
                        } else {
                            let animek = `${title}\n\n${info}\n\nSinopsis: ${sinopsis}\n\nLink download:\n${link_dl}`
                            await anto.sendFileFromUrl(from, thumb, 'animek.jpg', animek, null, null, true)
                                .then(() => console.log('Success sending anime info!'))
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'komiku':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.manga(q)
                    .then(async ({ genre, info, link_dl, sinopsis, thumb }) => {
                        let mangak = `${info}${genre}\nSinopsis: ${sinopsis}\nLink download:\n${link_dl}`
                        await anto.sendFileFromUrl(from, thumb, 'mangak.jpg', mangak, null, null, true)
                            .then(() => console.log('Success sending manga info!'))
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'wait':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
            if (isMedia && type === 'image' || quotedMsg && quotedMsg.type === 'image') {
                if (isMedia) {
                    var mediaData = await decryptMedia(message, uaOverride)
                } else {
                    var mediaData = await decryptMedia(quotedMsg, uaOverride)
                }
                const fetch = require('node-fetch')
                const imgBS4 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                anto.reply(from, 'Searching....', id)
                fetch('https://trace.moe/api/search', {
                    method: 'POST',
                    body: JSON.stringify({ image: imgBS4 }),
                    headers: { "Content-Type": "application/json" }
                })
                .then(respon => respon.json())
                .then(resolt => {
                    if (resolt.docs && resolt.docs.length <= 0) {
                        anto.reply(from, 'Maaf, saya tidak tau ini anime apa', id)
                    }
                    const { is_adult, title, title_chinese, title_romaji, title_english, episode, similarity, filename, at, tokenthumb, anilist_id } = resolt.docs[0]
                    teks = ''
                    if (similarity < 0.92) {
                        teks = '*Saya memiliki keyakinan rendah dalam hal ini* :\n\n'
                    }
                    teks += `➸ *Title Japanese* : ${title}\n➸ *Title chinese* : ${title_chinese}\n➸ *Title Romaji* : ${title_romaji}\n➸ *Title English* : ${title_english}\n`
                    teks += `➸ *Ecchi* : ${is_adult}\n`
                    teks += `➸ *Eps* : ${episode.toString()}\n`
                    teks += `➸ *Kesamaan* : ${(similarity * 100).toFixed(1)}%\n`
                    var video = `https://media.trace.moe/video/${anilist_id}/${encodeURIComponent(filename)}?t=${at}&token=${tokenthumb}`;
                    anto.sendFileFromUrl(from, video, 'nimek.mp4', teks, id).catch(() => {
                        anto.reply(from, teks, id)
                        limitAdd(serial)
                    })
                })
                .catch(() => {
                    anto.reply(from, 'Error !', id)
                })
            } else {
                anto.sendFileFromUrl(from, errorImg, 'Tutor.jpg', 'Neh contoh mhank!', id)
            }
            break
           /* case 'wait':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                    weeaboo.wait(imageBase64)
                        .then(async (result) => {
                            if (result.docs && result.docs.length <= 0) {
                                return await anto.reply(from, 'Anime not found! :(', id)
                            } else {
                                const { title, title_romaji, title_english, episode, similarity, filename, at, tokenthumb, anilist_id } = result.docs[0]
                                let teks = ''
                                if (similarity < 0.92) {
                                    teks = 'Low similarity. 🤔\n\n'
                                } else {
                                    teks += `*Title*: ${title}\n*Romaji*: ${title_romaji}\n*English*: ${title_english}\n*Episode*: ${episode}\n*Similarity*: ${(similarity * 100).toFixed(1)}%`
                                    const video = `https://media.trace.moe/video/${anilist_id}/${encodeURIComponent(filename)}?t=${at}&token=${tokenthumb}`
                                    await anto.sendFileFromUrl(from, video, `${title_romaji}.mp4`, teks, id)
                                        .then(() => console.log('Success sending anime source!'))
                                }
                            }
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break*/
            case 'source':
            case 'sauce':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    try {
                        const imageLink = await uploadImages(mediaData, `sauce.${sender.id}`)
                        console.log('Searching for source...')
                        const results = await saus(imageLink)
                        for (let i = 0; i < results.length; i++) {
                            let teks = ''
                            if (results[i].similarity < 80.00) {
                                teks = 'Low similarity. 🤔\n\n'
                            } else {
                                teks += `*Link*: ${results[i].url}\n*Site*: ${results[i].site}\n*Author name*: ${results[i].authorName}\n*Author link*: ${results[i].authorUrl}\n*Similarity*: ${results[i].similarity}%`
                                await anto.sendLinkWithAutoPreview(from, results[i].url, teks)
                                    .then(() => console.log('Source found!'))
                            }
                        }
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'waifu':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.waifu(false)
                    .then(async ({ url }) => {
                        await anto.sendFileFromUrl(from, url, 'waifu.png', '', id)
                            .then(() => console.log('Success sending waifu!'))
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'anitoki':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.anitoki()
                    .then(async ({ result }) => {
                        let anitoki = '-----[ *ANITOKI LATEST* ]-----'
                        for (let i = 0; i < result.length; i++) {
                            anitoki += `\n\n➸ *Title*: ${result[i].title}\n➸ *URL*: ${result[i].link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, anitoki, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'neonime':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.neonime()
                    .then(async ({ status, result }) => {
                        if (status !== 200) return await anto.reply(from, 'Not found.', id)
                        let neoInfo = '-----[ *NEONIME LATEST* ]-----'
                        for (let i = 0; i < result.length; i++) {
                            const { date, title, link, desc } = result[i]
                            neoInfo += `\n\n➸ *Title*: ${title}\n➸ *Date*: ${date}\n➸ *Synopsis*: ${desc}\n➸ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, neoInfo, id)
                        console.log('Success sending Neonime latest update!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'anoboy':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                weeaboo.anoboy()
                    .then(async ({ result }) => {
                        let anoboyInfo = '-----[ *ANOBOY ON-GOING* ]-----'
                        for (let i = 0; i < result.length; i++) {
                            anoboyInfo += `\n\n➸ *Title*: ${result[i].title}\n➸ *URL*: ${result[i].url}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, anoboyInfo, id)
                        console.log('Success sending on-going anime!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'nimesticker': // by CHIKAA CHANTEKKXXZZ
            case 'animesticker': 
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                weeaboo.snime()
                    .then(async (body) => {
                        const wifegerak = body.split('\n')
                        const wifegerakx = wifegerak[Math.floor(Math.random() * wifegerak.length)]
                        await anto.sendStickerfromUrl(from, wifegerakx)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'quotenime':
            case 'quotesnime':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                console.log('Sending random quote...')
                const quoteznime = await axios.get('https://mhankbarbar.tech/api/quotesnime/random')
                await anto.sendText(from, `➸ *Quotes* : ${quoteznime.data.data.quote}\n➸ *Character* : ${quoteznime.data.data.chara} from Anime ${quoteznime.data.data.anime}`, id)
                    .then(() => console.log('Success sending quotes..'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break

            // Fun
            case 'bapak': // By Kris
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                axios.get(`https://api.terhambar.com/bpk?kata=${q}`)
                    .then(async (res) => await anto.reply(from, res.data.text, id))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'puisi': // By Kris
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                axios.get('https://masgi.herokuapp.com/api/puisi2')
                    .then(async (res) => await anto.reply(from, res.data.data, id))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'cerpen': // By Kris
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                axios.get('https://masgi.herokuapp.com/api/cerpen')
                    .then(async (res) => await anto.reply(from, res.data.data, id))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'creepyfact': // By Kris
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                fetch('https://raw.githubusercontent.com/TheSploit/CreepyFact/main/creepy.txt')
                    .then((res) => res.text())
                    .then(async (body) => {
                        let creepyx = body.split('\n')
                        let creepyz = creepyx[Math.floor(Math.random() * creepyx.length)]
                        await anto.reply(from, creepyz, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'pencil':
                  if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                  if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                  await anto.reply(from, '```OTW NGEDIT```', id)
                  if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                    await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/editor/pencil?apikey=${config.lol}&url=${linkImg}`, 'pebcil.jpg', '```Follow Ig Hardianto02_```', id)
                  } else {
                    const pp_real_ = await anto.getProfilePicFromServer(sender.id)
                    if (pp_real_ === undefined) {
                      var pp_else_ = errorImg
                    } else {
                      pp_else_ = pp_real_
                    }
                    const datapp_ = await bent('buffer')(pp_else_)
                    const linkpp_ = await uploadImages(datapp_, `${sender.id}_ph`)
                    await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/editor/pencil?apikey=${config.lol}&url=${linkpp_}`, 'sw.jpg', '', id)
                  }
                  break
            case 'play':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q) return await anto.reply(from, 'Lagu Apa Ngab', id)
                await anto.reply(from, 'Sambil Nunggu Music Mending follow IG: instagram.com/Hardianto02__', id)
                if (isGroupMsg) {
                  const lamgu = await axios.get(`http://lolhuman.herokuapp.com/api/ytplay?apikey=${config.lol}&query=${q}`)
                  const { id, title, views, like, dislike, comment, thumbnail } = lamgu.data.result.info
                  const { audio, video } = lamgu.data.result
                  //const uditod = audio.link
                  const randem = audio[Math.floor(Math.random() * audio.length)]
                  const cptn = `////// [ *PLAY* ] /////\n_💞Title: ${title}_\n_💝Like : ${like}_\n_💞hujatan : ${dislike}_\n___________________\n*_Tunggu sebentar Lagi download_*`
                  await anto.sendFileFromUrl(from, thumbnail, 'pret.jpg', `${cptn}`)
                  const dwn_lamgu = await fetch(randem.link);
                  const buffer = await dwn_lamgu.buffer();
                  await fs.writeFile(`./temp/audio/play.mp3`, buffer)
                  await anto.sendFile(from, `./temp/audio/play.mp3`, `play.mp3`, ``, id)
                  await fs.unlinkSync(`./temp/audio/${q}.mp3`)
                } else {
                  await anto.reply(from, `Maaf Kak Error`, id)
                }
                break
                case 'playv':
             if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
             if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
             if (!q) return await anto.reply(from, 'Lagu Apa Ngab', id)
             await anto.reply(from, '_Sambil nunggu Follow IG: HARDIANTO02__', id)
             if (isGroupMsg) {
               const lamgu = await axios.get(`http://lolhuman.herokuapp.com/api/ytplay?apikey=${config.lol}&query=${q}`)
               const { id, title, views, like, dislike, comment, thumbnail } = lamgu.data.result.info
               const { audio, video } = lamgu.data.result
               const randem = video[Math.floor(Math.random() * video.length)]
               const cptn = `----------YT-PLAY-----------\n_💞Title: ${title}_\n_💕views : ${views}_\n_💝Like : ${like}_\n_❣hujatan : ${dislike}_\n_💝Bacot : ${comment}_\n___________________\n*_Tunggu sebentar Lagi download_*`
               await anto.sendFileFromUrl(from, thumbnail, 'pret.jpg', `${cptn}`)
               const dwn_lamgu = await fetch(randem.link);
               const buffer = await dwn_lamgu.buffer();
               await fs.writeFile(`./temp/audio/video.mp4`, buffer)
               await anto.sendFile(from, `./temp/audio/video.mp4`, `${q}.mp4`, `${q}`, id)
               await fs.unlinkSync(`./temp/audio/${q}.mp4`)
             
             }
             break
            case 'quotes':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                misc.quotes()
                .then(async ({ result }) => {
                    await anto.reply(from, `➸ *Quotes*: ${result.quotes}\n➸ *Author*: ${result.author}`, id)
                })
            break
            case 'asupan': // shansekai
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                fun.asupan()
                    .then(async (body) => {
                        const asupan = body.split('\n')
                        const asupanx = asupan[Math.floor(Math.random() * asupan.length)]
                        await anto.sendFileFromUrl(from, `http://sansekai.my.id/ptl_repost/${asupanx}`, 'asupan.mp4', 'Follow IG: https://www.instagram.com/ptl_repost untuk mendapatkan asupan lebih banyak.', id)
                        console.log('Success sending video!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'citacita': // Piyobot
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                fun.cita()
                    .then(async (body) => {
                        const cita = body.split('\n')
                        const randomCita = cita[Math.floor(Math.random() * cita.length)]
                        await anto.sendFileFromUrl(from, randomCita, 'cita.mp3', '', id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'dadu': // by CHIKAA CHANTEKKXXZZ
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                fun.dadu()
                    .then(async (body) => {
                        const dadugerak = body.split('\n')
                        const dadugerakx = dadugerak[Math.floor(Math.random() * dadugerak.length)]
                        await anto.sendStickerfromUrl(from, dadugerakx)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'dogesticker': // by CHIKAA CHANTEKKXXZZ
            case 'doge':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                fun.doge()
                    .then(async (body) => {
                        const dogeg = body.split('\n')
                        const dogegx = dogeg[Math.floor(Math.random() * dogeg.length)]
                        await anto.sendStickerfromUrl(from, dogegx)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'profile':
            case 'me':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (quotedMsg) {
                    const getQuoted = quotedMsgObj.sender.id
                    const profilePic = await anto.getProfilePicFromServer(getQuoted)
                    const username = quotedMsgObj.sender.name
                    const statuses = await anto.getStatus(getQuoted)
                    const benet = _ban.includes(getQuoted) ? 'Yes' : 'No'
                    const adm = groupAdmins.includes(getQuoted) ? 'Yes' : 'No'
                    const premi = premium.checkPremiumUser(getQuoted, _premium) ? 'Yes' : 'No'
                    const levelMe = level.getLevelingLevel(getQuoted, _level)
                    const xpMe = level.getLevelingXp(getQuoted, _level)
                    const req = 5 * Math.pow(levelMe, 2) + 50 * 1 + 100
                    const { status } = statuses
                    if (profilePic === undefined) {
                        var pfp = errorImg
                    } else {
                        pfp = profilePic
                    }
                    await anto.sendFileFromUrl(from, pfp, `${username}.jpg`, ind.profile(username, status, premi, benet, adm, levelMe, req, xpMe), id)
                } else {
                    const profilePic = await anto.getProfilePicFromServer(sender.id)
                    const username = pushname
                    const statuses = await anto.getStatus(sender.id)
                    const benet = isBanned ? 'Yes' : 'No'
                    const adm = isGroupAdmins ? 'Yes' : 'No'
                    const premi = isPremium ? 'Yes' : 'No'
                    const levelMe = level.getLevelingLevel(sender.id, _level)
                    const xpMe = level.getLevelingXp(sender.id, _level)
                    const req = 5 * Math.pow(levelMe, 2) + 50 * 1 + 100
                    const { status } = statuses
                    if (profilePic === undefined) {
                        var pfps = errorImg
                    } else {
                        pfps = profilePic
                    }
                    await anto.sendFileFromUrl(from, pfps, `${username}.jpg`, ind.profile(username, status, premi, benet, adm, levelMe, req, xpMe), id)
                }
            break
            case 'hartatahta':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Creating harta tahta text...')
                await anto.sendFileFromUrl(from, `https://api.vhtear.com/hartatahta?text=${q}&apikey=${config.vhtear}`, `${q}.jpg`, '', id)
                    .then(() => console.log('Success creating image!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'partner':
            case 'pasangan':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const nama = q.substring(0, q.indexOf('|') - 1)
                const pasangan = q.substring(q.lastIndexOf('|') + 2)
                await anto.reply(from, ind.wait(), id)
                fun.pasangan(nama, pasangan)
                    .then(async ({ result }) => {
                        const cpeten = `_>Kelebihan:${result.positif}_\n_>Kekurangan:${result.negatif}_\n*_>DESC:${result.deskripsi}_*`
                        await anto.sendFileFromUrl(from, result.image, 'jodoh.jpg', `${cpeten}`, id)
                            .then(() => console.log('Success sending fortune!'))
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'harijadi':
            case 'jadian':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
          //      if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const pepek = await anto.getProfilePicFromServer(sender.id)
                if (pepek === undefined) {
                  var perpe = errorImg
                 } else {
                    perpe = pepek
                  }
                const tanggal_d = q.substring(0, q.indexOf('|') - 1)
                const bulan_d = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                const tahun_d = q.substring(q.lastIndexOf('|') + 2)
                await anto.reply(from, ind.wait(), id)
                fun.harijadi(tanggal_d, bulan_d, tahun_d)
                    .then(async ({ result }) => {
                        const capte_ = `_*>Karakter:${result.karakteristik}*_\n_>DESC: ${result.deskripsi}_`
                        await anto.sendFileFromUrl(from, perpe, 'tod.jpg', capte_, id)
                            .then(() => console.log('Success sending fortune!'))
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            case 'zodiac':
            case 'zodiak':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                fun.zodiak(args[0])
                    .then(async ({ result }) => {
                        if (result.status === 204) {
                            return await anto.reply(from, result.ramalan, id)
                        } else {
                            let ramalan = `Zodiak: ${result.zodiak}\n\nRamalan: ${result.ramalan}\n\nAngka laksek: ${result.nomorKeberuntungan}\n\n${result.motivasi}\n\n${result.inspirasi}`
                            await anto.reply(from, ramalan, id)
                                .then(() => console.log('Success sending zodiac fortune!'))
                        }
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'write':
            case 'nulis':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Creating writing...')
                await anto.sendFileFromUrl(from, `https://api.vhtear.com/write?text=${q}&apikey=${config.vhtear}`, 'nulis.jpg', '', id)
                    .then(() => console.log('Success sending write image!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'ffbanner': // By: VideFrelan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                console.log('Creating FF banner...')
                const teks1ffanjg = q.substring(0, q.indexOf('|') - 1)
                const teks2ffanjg = q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `https://api.vhtear.com/bannerff?title=${teks1ffanjg}&text=${teks2ffanjg}&apikey=${config.vhtear}`, id)
                console.log('Success!')
            break
            case 'caklontong': //By: VideFrelan
                if (!isGroupMsg) return anto.reply(from, ind.groupOnly(), id)
                if (!isRegistered) return  anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const sleep = (ms) => {
                    return new Promise(resolve => setTimeout(resolve, ms));
                }
                fun.caklontong()
                    .then(async ( { result }) => {
                        await anto.reply(from, `➸ *Soal*: ${result.soal}`, id)
                        await anto.sendText(from, '30 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '20 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '10 Detik Tersisa...')
                        await sleep(10000)
                        await anto.reply(from, `➸ *Jawaban*: ${result.jawaban}\n${result.desk}`, id)
                        console.log('Success sending the answers!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!')
                    })
            break
            case 'tebakgambar':
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                fun.tbkgmbr()
                    .then(async ({ result }) => {
                        await anto.sendFileFromUrl(from, result.soal_gbr, 'TebakGambar.jpg', '', id)
                        await anto.sendText(from, '50 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '40 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '30 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '20 Detik Tersisa...')
                        await sleep(10000)
                        await anto.sendText(from, '10 Detik Tersisa...')
                        await sleep(10000)
                        await anto.reply(from, `➸ *Jawaban*: ${result.jawaban}`, id)
                        console.log('Success sending tebakgambar result!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!')
                    })
            break    
            case 'sket':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                const flowers_ = await axios.get(`https://api.zeks.xyz/api/sketchf?img=${linkImg}&apikey=apivinz`)
                await anto.sendFileFromUrl(from, flowers_.data.result, 'sw.jpg', '', id)
              } else {
                const pp_real = await anto.getProfilePicFromServer(sender.id)
                if (pp_real === undefined) {
                  var pp_else = errorImg
                } else {
                  pp_else = pp_real
                }
                const datapp = await bent('buffer')(pp_else)
                const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
               const folowers_pp = await axios.get(`https://api.zeks.xyz/api/sketchf?img=${linkpp}&apikey=apivinz`)
               await anto.sendFileFromUrl(from, folowers_pp.data.result, 'titi.jpg', '', id)
              } 
              break
              case 'howtoprem':
                case 'jadipremium':
                case 'howtopremium':
                    const cpten = `__[< *HOW GET PREMIUM* >]__\n
_Yooo ${pushname}_
Kamu Bisa mendapatkan Premium 1Bulan Dengan Berdonasi/Sewa Di:
_[DANA]:087811078485_ Minim 10k
_[GO-PAY]:087811078485_ Minim 10k
_[PULSA]:085326835679_ Minim 20k
Lalu Kirim Bukti Tf ke : wa.me/6287811078485
Bang Kok Kudu Donasi?
creator bot: _Iya Karna Server Untuk Nyalain Bot Tu dibayar tiap Bulan_
Gimana Kalo Ngak Ada Donasi?
creator bot: _Kalo Ngk Ada Donasi Saya Akan Pensi Pasti nya Semua Yang di pake jalanin Bot Pake duit_
OkOk Bang 
_sekian Drama Nya_
Nah Untuk yang masih ragu apa keuntungan premium
-Dapat Akses Fitur Premium
-Dapat Masukin Bot ke Group dengan  !join <link_group>
-Bisa Req Fitur (pribadi/umum)
-Dapat Xp 5000
Dan Dll
Nah Kalo Mau Mencoba premium silahkan Ketik
_*${prefix}trialprem*_
_______________Sekian_______________`
              await anto.sendFileFromUrl(from, `https://telegra.ph/file/ab7525cb68253c9dbf302.jpg`, 'prem.jpg', `${cpten}`, id)
              break
              case 'trialprem':
                  const tronp = `Yooo ${pushname}
Kamu Bisa Mendapatkan Trial Premium 1× Per Kesempatan Dengan Cara?
Follow Ig : _Hardianto02__
jika sudah screenshot+Kirim Ke _wa.me/6287811078485_
Dan join Group Official Paimon ketik  ${prefix}paimonofficial
Note: 1× per orang tidak bisa 2×`
            await anto.sendFileFromUrl(from, `https://telegra.ph/file/54d6d0c87ce6328831a9c.jpg`, 'tit.jpg', `${tronp}`, id)
              break
              case 'paimonofficial':
                  await anto.sendFileFromUrl(from, `https://telegra.ph/file/22e5e6be3b061335ce718.jpg`, 'titd.jpg', '```LINK GROUP:```\nOfficial 1:\nhttps://chat.whatsapp.com/J1hLy6XJtFR6d7PO1GIDOZ\nOfficial 2:\nhttps://chat.whatsapp.com/GmpqQKnlfMl2fJlFjBH76q', id)
            break
            case 'darkmeme':
                if(isGroupMsg){
            const drak = await axios.get('http://zekais-api.herokuapp.com/dankmemes')
            await anto.sendVideoAsGif(from, drak.data.result)
            }
            break
            case 'tod':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
           await anto.reply(from, 'Sebelum bermain berjanjilah akan melaksanakan apapun perintah yang diberikan.' , id)
           await anto.sendText(from, `Silakan ketik *${prefix}truth* atau *${prefix}dare*`)
            break
            case 'weton':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const preet = await anto.getProfilePicFromServer(sender.id)
                if (preet === undefined) {
                    var pepe_r = errorImg
                } else {
                    var pepe_r = preet
                }
                
                const tgl = q.substring(0, q.indexOf('|') - 1) 
                const bln = q.substring(q.indexOf('|') + 2, q.lastIndexOf('|') - 1)
                const thn = q.substring(q.lastIndexOf('|') + 2)
                await anto.reply(from, ind.wait(), id)
                fun.weton(tgl, bln, thn)
                    .then(async ({ result }) => {
                        const cpt_ = `______[ *DATA DITEMUKAN* ]______\n*_>WETON: ${result.weton}_*\n*_>CHART:${result.karakter}_*\n*_>WORK:${result.pekerjaan}_*\n*_REJEKI:${result.rejeki}_*\n*_>JODOH:${result.jodoh}_*\n______________`
                        await anto.sendFileFromUrl(from, pepe_r, 'tof.jpg', `${cpt_}`, id)
                        console.log('Success sending weton info!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'truth':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                fun.truth()
                    .then(async (body) => {
                        const tod = body.split('\n')
                        const randomTod = tod[Math.floor(Math.random() * tod.length)]
                        await anto.reply(from, randomTod, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'hilih':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                fun.hilihteks(q)
                    .then(async ( { result }) => {
                        await anto.reply(from, result.kata, id)
                        console.log('Success sending hilih text!')
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'dare':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                fun.dare()
                    .then(async (body) => {
                        const dare = body.split('\n')
                        const randomDare = dare[Math.floor(Math.random() * dare.length)]
                        await anto.reply(from, randomDare, id)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'triggered':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    console.log(color('[WAPI]', 'green'), 'Downloading and decrypting media...')
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const temp = './temp'
                    const name = new Date() * 1
                    const fileInputPath = path.join(temp, `${name}.gif`)
                    const fileOutputPath = path.join(temp, 'video', `${name}.mp4`)
                    canvas.Canvas.trigger(mediaData)
                        .then((buffer) => {
                            canvas.write(buffer, fileInputPath)
                            ffmpeg(fileInputPath)
                                .outputOptions([
                                    '-movflags faststart',
                                    '-pix_fmt yuv420p',
                                    '-vf scale=trunc(iw/2)*2:trunc(ih/2)*2'
                                ])
                                .inputFormat('gif')
                                .on('start', (commandLine) => console.log(color('[FFmpeg]', 'green'), commandLine))
                                .on('progress', (progress) => console.log(color('[FFmpeg]', 'green'), progress))
                                .on('end', async () => {
                                    console.log(color('[FFmpeg]', 'green'), 'Processing finished!')
                                    await anto.sendMp4AsSticker(from, fileOutputPath, { pack: 'PaimonBot', author: '@Hardianto02_', fps: 30, startTime: '00:00:00.0', endTime : '00:00:05.0', loop: 0, crop: false })
                                    console.log(color('[WAPI]', 'green'), 'Success sending GIF!')
                                    setTimeout(() => {
                                        fs.unlinkSync(fileInputPath)
                                        fs.unlinkSync(fileOutputPath)
                                    }, 30000)
                                })
                                .save(fileOutputPath)
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'missing':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
            if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                  const coba = `https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=${linkImg}`
                  const fwck = await anto.download(coba)
                await anto.sendFile(from, fwck, 'hoh.jpg', '', id)
                } else {
                  for (let i = 0; i < mentionedJidList.length; i++) {
                  const pp_real = await anto.getProfilePicFromServer(mentionedJidList[i])
                //  const name = pushname(mentionedJidList[i])
                  if (pp_real === undefined) {
                    var pp_else = errorImg
                  } else {
                    pp_else = pp_real
                  }
                  const datapp = await bent('buffer')(pp_else)
                  const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
                  await anto.sendFileFromUrl(from, `https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=${linkpp}`, 'tod.jpg', `Si ${pushname} mencari seorang yang ada di foto\nBarang siapa yang menemukan dia nimbrung di gb lain suruh ke sini bilang katanya si ${pushname} mencari nya`, id)
                }}
                break
                case 'verifikasi':
            case 'regis':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
          //  if (!q) return await anto.reply(ftom, ind.wrongFormat())
           if (q){
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                await  anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/toloserti?apikey=./X7xSec404&name=${q}`, 'dra.jpg', '```Gambar nya kaka```', id)
                } else {
                  for (let i = 0; i < mentionedJidList.length; i++) {
                  await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/toloserti?apikey=${config.lol}&name=${pushname}`, 'tod.jpg', '```Gambar Nya kaka```', id)
                }
                } 
                break
                case 'gambarin':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
            if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
        //          const pree = await axios.get(`https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=`)
             //     .get
                await  anto.sendFileFromUrl(from, `https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=${linkImg}`, 'dra.jpg', '```Gambar nya kaka```', id)
                } else {
                  for (let i = 0; i < mentionedJidList.length; i++) {
                  const pp_real = await anto.getProfilePicFromServer(mentionedJidList[i])
                  if (pp_real === undefined) {
                    var pp_else = errorImg
                  } else {
                    pp_else = pp_real
                  }}
                  const datapp = await bent('buffer')(pp_else)
                  const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
                  await anto.sendFileFromUrl(from, `https://videfikri.com/api/textmaker/pencildrawing/?urlgbr=${linkpp}`, 'tod.jpg', '```Gambar Nya kaka```', id)
                }
                break
                case 'carijodoh':
            case 'searchjodoh':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const groupMev_ = await anto.getGroupMembers(groupId)
                const random_jod = groupMev_[Math.floor(Math.random() * groupMev_.length)]
                await anto.sendTextWithMentions(from, `_*💕JODOH MATCHING💕*_\nJODOH SI @${sender.id.replace('@c.us', '')}\nadalah.......\n💕💕💕💕💕💕💕💕💕💕\nSelamat anda mendapatkan jodoh: @${random_jod.id.replace('@c.us', '')}\n___________\n*Semoga Makin sayang yehh*`, id)
                 break
                case 'telestick':
                case 'telegramstick':
                 if (!isPremium) return await anto.reply(from, ind.notPremium())
                if (!isUrl(url) && !url.includes('t.me')) return await anto.reply(from, ind.wrongFormat(), id)
                const tel_url = await axios.get(`http://lolhuman.herokuapp.com/api/telestick?apikey=${config.lol}&url=${url}`)
                const tel_stick = tel_url.data.result
                const ngebtel = tel_stick.sticker
                for (let i = 0; i < ngebtel.length; i++) {
                  await anto.sendStickerfromUrl(from, ngebtel[i], null, { pack: 'PAIMON~BOT', author: '@Hardianto02_', keepScale: false })
                }
                break
                case 'attp': 
                 const textattp = body.slice(6)
                 const resultattp = await axios.get('https://api.xteam.xyz/attp?text=' + textattp)
                let stik = resultattp.data.result
                anto.sendRawWebpAsSticker(from, stik, true)
                break
                case 'terangkan':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
            if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                  const terang = await axios.get(`https://mieayam-kering.herokuapp.com/api/textmaker2/beach?q=${linkImg}&apikey=freeKeY`)
                await  anto.sendFileFromUrl(from, terang.data.result.url, 'dra.jpg', '```Gambar nya kaka```', id)
                } else {
                  for (let i = 0; i < mentionedJidList.length; i++) {
                  const pp_real = await anto.getProfilePicFromServer(mentionedJidList[i])
               //   const name = pushname(mentionedJidList[i])
                  if (pp_real === undefined) {
                    var pp_else = errorImg
                  } else {
                    pp_else = pp_real
                  }}
                  const datapp = await bent('buffer')(pp_else)
                  const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
                  const dark = await axios.get(`https://mieayam-kering.herokuapp.com/api/textmaker2/beach?q=${linkpp}&apikey=freeKeY`)
                  await anto.sendFileFromUrl(from, dark.data.result.url, 'tod.jpg', '```Gambar Nya kaka```', id)
                }
                break
            case 'trash':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                try {
                    await anto.reply(from, ind.wait(), id)
                    for (let i = 0; i < mentionedJidList.length; i++) {
                        const ypics = await anto.getProfilePicFromServer(mentionedJidList[i])
                        if (ypics === undefined) {
                            var ypfps = errorImg
                        } else {
                            ypfps = ypics
                        }
                    }
                    canvas.Canvas.trash(ypfps)
                        .then(async (buffer) => {
                            canvas.write(buffer, `./temp/${sender.id}_trash.png`)
                            await anto.sendFile(from, `./temp/${sender.id}_trash.png`, `${sender.id}_trash.png`, '', id)
                            fs.unlinkSync(`./temp/${sender.id}_trash.png`)
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'hitler':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                try {
                    await anto.reply(from, ind.wait(), id)
                    for (let i = 0; i < mentionedJidList.length; i++) {
                        const ypics = await anto.getProfilePicFromServer(mentionedJidList[i])
                        if (ypics === undefined) {
                            var ypf = errorImg
                        } else {
                            ypf = ypics
                        }
                    }
                    canvas.Canvas.hitler(ypf)
                        .then(async (buffer) => {
                            canvas.write(buffer, `./temp/${sender.id}_hitler.png`)
                            await anto.sendFile(from, `./temp/${sender.id}_hitler.png`, `${sender.id}_hitler.png`, '', id)
                            fs.unlinkSync(`./temp/${sender.id}_hitler.png`)
                        })
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'wasted':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && type === 'image' || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    const encryptMediaWt = isQuotedImage ? quotedMsg : message
                    const dataPotoWt = await decryptMedia(encryptMediaWt, uaOverride)
                    const fotoWtNya = await uploadImages(dataPotoWt, `fotoProfilWt.${sender.id}`)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, `https://some-random-api.ml/canvas/wasted?avatar=${fotoWtNya}`, 'Wasted.jpg', 'Ini..., sticker nya lagi di kirim', id).then(() => anto.sendStickerfromUrl(from, `https://some-random-api.ml/canvas/wasted?avatar=${fotoWtNya}`))
                    console.log('Success sending Wasted image!')
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'kill':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                await anto.sendTextWithMentions(from, `_*OTW MEMBUNUH @${mentionedJidList[0].replace('@c.us', '')}*_`)
               await anto.sendStickerfromUrl(from, `http://lolhuman.herokuapp.com/api/random/kill?apikey=${config.lol}`, null, { pack: 'PAIMONBOT', author: 'KILL YOU', crop: false })
               await anto.sendTextWithMentions(from, `*_BERHASIL MEMBUNUH @${mentionedJidList[0].replace('@c.us', '')}`, id)
            case 'kiss':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                try {
                    if (isMedia && isImage || isQuotedImage) {
                        if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                        limit.addLimit(sender.id, _limit, isPremium, isOwner)
                        await anto.reply(from, ind.wait(), id)
                        const encryptMedia = isQuotedImage ? quotedMsg : message
                        const ppRaw = await anto.getProfilePicFromServer(sender.id)
                        const ppSecond = await decryptMedia(encryptMedia, uaOverride)
                        if (ppRaw === undefined) {
                            var ppFirst = errorImg
                        } else {
                            ppFirst = ppRaw
                        }
                        canvas.Canvas.kiss(ppFirst, ppSecond)
                            .then(async (buffer) => {
                                canvas.write(buffer, `${sender.id}_kiss.png`)
                                await anto.sendFile(from, `${sender.id}_kiss.png`, `${sender.id}_kiss.png`, '', id)
                                fs.unlinkSync(`${sender.id}_kiss.png`)
                            })
                    } else {
                        await anto.reply(from, ind.wrongFormat(), id)
                    }
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'phcomment':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const usernamePh = q.substring(0, q.indexOf('|') - 1)
                const commentPh = q.substring(q.lastIndexOf('|') + 2)
                const ppPhRaw = await anto.getProfilePicFromServer(sender.id)
                if (ppPhRaw === undefined) {
                    var ppPh = errorImg
                } else {
                    ppPh = ppPhRaw
                }
                const dataPpPh = await bent('buffer')(ppPh)
                const linkPpPh = await uploadImages(dataPpPh, `${sender.id}_ph`)
                await anto.reply(from, ind.wait(), id)
                const preprocessPh = await axios.get(`https://nekobot.xyz/api/imagegen?type=phcomment&image=${linkPpPh}&text=${commentPh}&username=${usernamePh}`)
                await anto.sendFileFromUrl(from, preprocessPh.data.message, 'ph.jpg', '', id)
                console.log('Success creating image!')
            break
            case 'calendar':
            case 'calender':
            case 'kalender':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                const xios = await axios.get(`https://api.zeks.xyz/api/calendar?img=${linkImg}&apikey=apivinz`)
               await anto.sendFileFromUrl(from, xios.data.result, 'calendar.jpg', '```Follow IG: @Hardianto02_```', id)
              } else {
                  const ppPhRaw = await anto.getProfilePicFromServer(sender.id)
                  if (ppPhRaw === undefined) {
                    var ppPh = errorImg
                } else {
                    ppPh = ppPhRaw
                }
                const dataPpPh = await bent('buffer')(ppPh)
                const linkPpPh = await uploadImages(dataPpPh, `${sender.id}_ph`)
                
                  const xios2 = await axios.get(`https://api.zeks.xyz/api/calendar?img=${linkPpPh}&apikey=${config.apivinz}`)
    
                  await anto.sendFileFromUrl(from, xios2.data.result, 'clender.jpg', '', id)
              }
              break
              case 'character':
            case 'chartsearch':
              if (!q) return await anto.reply(from, '*masukan nama karakter yang ingin di cari dengan benar*', id) 
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner) 
               try{
                await anto.reply(from, ind.wait(), id)
                const chara_key = await axios.get(`http://lolhuman.herokuapp.com/api/character/${q}?apikey=62c4d2562d61eae9308898ea`)
                const { name, description, favourites, media, image } = chara_key.data.result
                let text_1 = `-----[ *${q}* ]-----\n*[NAMA✨] : ${name.full}*\n*[KANJI] : ${name.native}*\n*[ID] : ${chara_key.data.result.id}*\n*[FAVORITE]: ${favourites}*\n\n`
                        for (let i = 0; i < media.nodes.length; i++) {
                const { id, idMal, title, type } = media.nodes[i]
                    text_1 += `_________________\n\n_📚Judul:${title.romaji}_\n\n_Type:${type}_\n\n_📚Kanji:${title.native}_\n\n_Chart Id:${idMal}[MAL]_\n\n_Id:${id}_\n_______________________\n\n`
                        }
                   text_1 += `*[DESC] :* ${description}\n____________[Character]__________`
 
                   await anto.sendFileFromUrl(from, image.large, `${q}.jpg`, `${text_1}`, id)
                    } catch {
                        anto.reply(from, ind.wrongFormat(), id)
                    }
                   break
              case 'tahta':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                await anto.reply(from, ind.wait(), id)
                await anto.sendFileFromUrl(from, `https://api.zeks.xyz/api/hartatahta?text=${q}&apikey=apivinz`, `${pushname}.jpg`, `_Harta_\n_Tahta_\n_${q}_`, id)
                break
                case 'snobg':
                case 'stickernobg':
                    if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                await anto.sendStickerfromUrl(from, `https://api.zeks.xyz/api/removebg?apikey=apivinz&url=${linkImg}`)
            
              } else {
                const pp_real_ = await anto.getProfilePicFromServer(sender.id)
                if (pp_real_ === undefined) {
                  var pp_else_ = errorImg
                } else {
                  pp_else_ = pp_real_
                }
                const datapp_ = await bent('buffer')(pp_else_)
                const linkpp_ = await uploadImages(datapp_, `${sender.id}_ph`)
               await anto.sendStickerfromUrl(from, `https: //api.zeks.xyz/api/sfire?img=${linkpp_}=apivinz`)
              } 
              break
                case 'neontext':
            
            // Sticker
            case 'stikernobg':
            case 'stickernobg': //by: VideFrelan
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && type === 'image' || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const q = await uploadImages(mediaData, `stickernobg.${sender.id}`)
                    await anto.sendStickerfromUrl(from, ``)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'stickerwm': // By Slavyan
            case 'stcwm':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const packname = q.substring(0, q.indexOf('|') - 1)
                    const author = q.substring(q.lastIndexOf('|') + 2)
                    exif.create(packname, author, `stc_${sender.id}`)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    webp.buffer2webpbuffer(mediaData, 'jpg', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize(512, 512)
                                .toFile(`./temp/stage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/stc_${sender.id}.exif ./temp/stage_${sender.id}.webp -o ./temp/${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await anto.sendRawWebpAsSticker(from, base64)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/stage_${sender.id}.webp`)
                                        fs.unlinkSync(`stc_${sender.id}`)
                                    }
                                })
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                    } else {
                        await anto.reply(from, ind.wrongFormat(), id)
                    }
            break
            case 'meme':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                const meme_k = await axios.get(`https://api.zeks.xyz/api/memeindo?apikey=apivinz`)
                await anto.sendFileFromUrl(from, meme_k.data.result, 'meme.jpg', '', id)
                break
            case 'creatememe':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (isMedia && isImage || isQuotedImage) {
                  if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                  limit.addLimit(sender.id, _limit, isPremium, isOwner)
                  await anto.reply(from, ind.wait(), id)
                  const encryptMedia = isQuotedImage ? quotedMsg : message
                  const mediaData = await decryptMedia(encryptMedia, uaOverride)
                  const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                const teks_1 = q.substring(0, q.indexOf('|') - 1)
                const teks_2= q.substring(q.lastIndexOf('|') + 2)
                await anto.sendFileFromUrl(from, `http://lolhuman.herokuapp.com/api/memegen/${teks_1}/${teks_2}?apikey=${config.lol}&img=${linkImg}`, `${sender.id}.jpg`, '*Sukses Create Meme*', id)
                } else {
                 anto.sendFileFromUrl(from, errorImg, 'errr.jpg', 'Gagal Buat Meme Bruuhh', id)
                }
                break
                case 'fakethumb':
                  if (!isGroupMsg){
                const thumb_ = `https://telegra.ph/file/6507472509a1f16696833.jpg`
                const base64 = `data:image/webp;base64,${thumb_.toString('base64')}`
                const pphardi = `https://telegra.ph/file/86fc10ad4da473d69ddc2.jpg`
                await anto.sendMessageWithThumb(base64, pphardi, 'not', 'nandemomai', '', groupId)
                  } else {
                    anto.sendFileFromUrl(from, errorImg, 'titi.jpg', '', id)
                  }
                  break
            case 'stcmeme':
            case 'stickermeme':
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
            if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
            if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
            if (isMedia && isImage || isQuotedImage) {
              if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
              limit.addLimit(sender.id, _limit, isPremium, isOwner)
              await anto.reply(from, ind.wait(), id)
              const encryptMedia = isQuotedImage ? quotedMsg : message
              const mediaData = await decryptMedia(encryptMedia, uaOverride)
              const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
              const teks_1 = q.substring(0, q.indexOf('|') - 1)
              const teks_2 = q.substring(q.lastIndexOf('|') + 2)
              const link_v = `http://lolhuman.herokuapp.com/api/memegen?apikey=${config.lol}&texttop=${teks_1}&textbottom=${teks_2}&img=${linkImg}`
            //  const jwnco_ = await anto.download(link_v)
              await anto.sendRawWebpAsSticker(from, link_v, { pack: 'PAIMON BOT', author: '@Hardianto02_', crop: false })
            } else {
              anto.sendFileFromUrl(from, errorImg, 'errr.jpg', 'Gagal Buat Meme Bruuhh', id)
            }
            break
            case 'stickermeme_':
            case 'stcmeme_':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const top = q.substring(0, q.indexOf('|') - 1)
                    const bottom = q.substring(q.lastIndexOf('|') + 2)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const getUrl = await uploadImages(mediaData, `meme.${sender.id}`)
                    const create = `https://api.memegen.link/images/custom/${top}/${bottom}.png?background=${getUrl}`
                    const meme = await bent('buffer')(create)
                    webp.buffer2webpbuffer(meme, 'png', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize(512, 512)
                                .toFile(`./temp/stage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/data.exif ./temp/stage_${sender.id}.webp -o ./temp/${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await anto.sendRawWebpAsSticker(from, base64)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/stage_${sender.id}.webp`)
                                    }
                                })
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'takestick': // By: VideFrelan
            case 'take':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium())
                if (quotedMsg && quotedMsg.type == 'sticker') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const mediaDataTake = await decryptMedia(quotedMsg, uaOverride)
                    const packname = q.substring(0, q.indexOf('|') - 1)
                    const author = q.substring(q.lastIndexOf('|') + 2)
                    exif.create(packname, author, `takestick_${sender.id}`)
                    webp.buffer2webpbuffer(mediaDataTake, 'jpg', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize(512, 512)
                                .toFile(`./temp/takestickstage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/takestick_${sender.id}.exif ./temp/takestickstage_${sender.id}.webp -o ./temp/takestick_${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/takestick_${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/takestick_${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await anto.sendRawWebpAsSticker(from, base64)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/takestick_${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/takestickstage_${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/takestick_${sender.id}.exif`)
                                    }
                                })
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'sticker':
            case 'stiker':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isMedia && isImage || isQuotedImage) {
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    webp.buffer2webpbuffer(mediaData, 'jpg', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize(512, 512)
                                .toFile(`./temp/stage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/data.exif ./temp/stage_${sender.id}.webp -o ./temp/${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await anto.sendRawWebpAsSticker(from, base64)
                                        await anto.reply(from, ind.ok(), id)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/stage_${sender.id}.webp`)
                                    }
                                })
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'stickerp':
            case 'stikerp':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                if (isMedia && isImage || isQuotedImage) {
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    webp.buffer2webpbuffer(mediaData, 'jpg', '-q 100')
                        .then((res) => {
                            sharp(res)
                                .resize({
                                    width: 512,
                                    height: 512,
                                    fit: 'contain',
                                    background: {
                                        r: 255,
                                        g: 255,
                                        b: 255,
                                        alpha: 0
                                    }
                                })
                                .toFile(`./temp/stage_${sender.id}.webp`, async (err) => {
                                    if (err) return console.error(err)
                                    await exec(`webpmux -set exif ./temp/data.exif ./temp/stage_${sender.id}.webp -o ./temp/${sender.id}.webp`, { log: true })
                                    if (fs.existsSync(`./temp/${sender.id}.webp`)) {
                                        const data = fs.readFileSync(`./temp/${sender.id}.webp`)
                                        const base64 = `data:image/webp;base64,${data.toString('base64')}`
                                        await anto.sendRawWebpAsSticker(from, base64)
                                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                        fs.unlinkSync(`./temp/${sender.id}.webp`)
                                        fs.unlinkSync(`./temp/stage_${sender.id}.webp`)
                                    }
                                })
                        })
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
           case 'fbprof':
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                const flowers_ = await get.get(`https://videfikri.com/api/textmaker/facebookprof/?urlgbr=${linkImg}&text=${q}`).json()
               const titid = flowers_.result.img
                anto.sendFileFromUrl(from, titid, 'sw.jpg', '*Done*', id)
              } else {
                const pp_real = await anto.getProfilePicFromServer(sender.id)
                if (pp_real === undefined) {
                  var pp_else = errorImg
                } else {
                  pp_else = pp_real
                }
                const datapp = await bent('buffer')(pp_else)
                const linkpp = await uploadImages(datapp, `${sender.id}_ph`)
               const folowers_pp = await get.get(`https://videfikri.com/api/textmaker/facebookprof/?urlgbr=${linkpp}&text=${q}`).json()
               await anto.sendFileFromUrl(from, folowers_pp.result.img, 'titi.jpg', '*Done Ngab*', id)
              } 
              break
            
        /*      case 'fbprof':
              if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
              if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
              if (isMedia && isImage || isQuotedImage) {
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                const encryptMedia = isQuotedImage ? quotedMsg : message
                const mediaData = await decryptMedia(encryptMedia, uaOverride)
                const linkImg = await uploadImages(mediaData, `${sender.id}_img`)
                misc.fbprof(linkImg, q)
                    .then(async ({ result }) => {
                        await anto.sendFileFromUrl(from, result.img, 'toto.jpg', '', id)
                        console.log(`Create ${q}`)
                      }) 
                      .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                      })}
                      break*/

            case 'slot':
      if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
      if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
        limit.addLimit(sender.id, _limit, isPremium, isOwner)
        await anto.reply(from, ind.wait(), id)
      const sotoy = [
		'🍊 : 🍒 : 🍐',
		'🍒 : 🔔 : 🍊',
		'🍇 : 🍒 : 🍐',
		'🍊 : 🍋 : 🔔',//by Fadhlur Owner of NotBot
		'🔔 : 🍒 : 🍐',
		'🔔 : 🍒 : 🍊',
        '🍊 : 🍋 : 🔔',		
		'🍐 : 🍒 : 🍋',
		'🍐 : 🍐 : 🍐',
		'🍊 : 🍒 : 🍒',
		'🔔 : 🔔 : 🍇',
		'🍌 : 🍒 : 🔔',
		'🍐 : 🔔 : 🔔',
		'🍊 : 🍋 : 🍒',
		'🍋 : 🍋 : 🍌',
		'🔔 : 🔔 : 🍇',
		'🔔 : 🍐 : 🍇',
		'🔔 : 🔔 : 🔔',
		'🍒 : 🍒 : 🍒',
		'🍌 : 🍌 : 🍌'
		]
		
          const somtoy = sotoy[Math.floor(Math.random() * (sotoy.length))]	
          if (somtoy === '🍌 : 🍌 : 🍌', '🔔 : 🔔 : 🔔'){
              var Jawaban = '❌❌KALAH❌❌'
          } else {
            var Jawaban = '👑MENANG👑'
          }
          
             anto.sendText(from, `[  🎰 | SLOTS ]\n-----------------\n🍋 : 🍌 : 🍍\n${somtoy}<=====\n🍋 : 🍌 : 🍍\n[  🎰 | SLOTS ]\n_______*${Jawaban}*______\nKeterangan : Jika anda Mendapatkan 3Buah anda Menang\n\nContoh : 🍌 : 🍌 : 🍌<=====`, id)
            break
            case 'stickergif':  //vf
            case 'stikergif':
          //      if (!isPremium) return await anto.reply(from, ind.notPremium())
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(pushname), id)
                if (isMedia && type === 'video' || mimetype === 'image/gif') {
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const mediaData = await decryptMedia(message, uaOverride)
                        const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                        await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime : `00:00:06.0`, loop: 0, crop: true }, { author: 'PAIMON BOT', pack: '@Hardianto02_', keepScale: true })
                            .then(async () => {
                                console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
                    }
                } else if (isQuotedGif || isQuotedVideo) {
                    await anto.reply(from, ind.ok(), id)
                    try {
                        const mediaData = await decryptMedia(quotedMsg, uaOverride)
                        const videoBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                        await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime : `00:00:06.0`, loop: 0, crop: true }, { author: 'PAIMON BOT', pack: '@Hardianto02_' })
                            .then(async () => {
                                console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
                    }
                } else {
                    await anto.reply(from, `Untuk mengconvert GIF/Video menjadi stikergif silahkan upload video/gif dengan caption ${prefix}stikergif`, id)
                }
            break
            case 'sgifnocrop':
            case 'stikergifp':
            case 'stickergifp':
           case 'sgifp':
            if (!isPremium) return await anto.reply(from, ind.notPremium())
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(pushname), id)
            if (isMedia && type === 'video' || mimetype === 'image/gif') {
              await anto.reply(from, ind.wait(), id)
              try {
                const mediaData = await decryptMedia(message, uaOverride)
                const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime: `00:00:06.0`, loop: 0, crop: false }, { author: 'PAIMON BOT', pack: '@Hardianto02_' })
                  .then(async () => {
                    console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
            
                  })
              } catch (err) {
                console.error(err)
                await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
              }
            } else if (isQuotedGif || isQuotedVideo) {
              await anto.reply(from, ind.ok(), id)
              try {
                const mediaData = await decryptMedia(quotedMsg, uaOverride)
                const videoBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                
                await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime: `00:00:06.0`, loop: 0, crop: false }, { author: 'PAIMON BOT', pack: '@Hardianto02_' })
                  .then(async () => {
                    console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
            
                  })
              } catch (err) {
                console.error(err)
                await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
              }
            } else {
              await anto.reply(from, `Untuk mengconvert GIF/Video menjadi stikergif silahkan upload video/gif dengan caption ${prefix}stikergif`, id)
            }
            break
            
            case 'sgifwm':
                if (!isPremium) return await reply(from, ind.notPremium())
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(pushname), id)
                if (isMedia && type === 'video' || mimetype === 'image/gif') {
                    if (!query.includes('|')) return await anto.reply(from, `Untuk membuat stickergif watermark\ngunakan ${prefix}sgifwm author | packname`, id)
                    const namaPacksgif = q.substring(0, q.indexOf('|') - 1)
                    const authorPacksgif = q.substring(q.lastIndexOf('|') + 2)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const mediaData = await decryptMedia(message, uaOverride)
                        const videoBase64 = `data:${mimetype};base64,${mediaData.toString('base64')}`
                        await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime : `00:00:06.0`, loop: 0 }, { author: `${authorPacksgif}`, pack: `${namaPacksgif}`, keepScale: true })
                            .then(async () => {
                                console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
                    }
                } else if (isQuotedGif || isQuotedVideo) {
                    const namaPacksgif = q.substring(0, q.indexOf('|') - 1)
                    const authorPacksgif = q.substring(q.lastIndexOf('|') + 2)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const mediaData = await decryptMedia(quotedMsg, uaOverride)
                        const videoBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                        await anto.sendMp4AsSticker(from, videoBase64, { fps: 10, startTime: `00:00:00.0`, endTime : `00:00:06.0`, loop: 0 }, { author: `${authorPacksgif}`, pack: `${namaPacksgif}`, crop: false })
                            .then(async () => {
                                console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                                
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, `Ukuran video terlalu besar\nMaksimal size adalah 1MB!`, id)
                    }
                } else {
                    await anto.reply(from, `Untuk membuat stickergif dengan watermark\ngunakan ${prefix}sgifwm author | packname`, id)
                }
            break
            case 'stickernocrop':
            case 'stnc':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(pushname), id)
                if (isMedia && isImage || isQuotedImage) {
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                    await anto.sendImageAsSticker(from, imageBase64, { keepScale: true, author: '@Hardianto02_', pack: 'PAIMON BOT' })
                    console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                    } else {
                    await anto.reply(from, `Untuk membuat sticker no crop\nsilahkan *upload* atau reply foto dengan caption ${prefix}stnc`, id)
                }
            break
            case 'ttg':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.reply(from, ind.wait(), id)
                await anto.sendStickerfromUrl(from, `https://api.vhtear.com/textxgif?text=${q}&apikey=${config.vhtear}`)
                    .then(() => console.log('Success creating GIF!'))
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    })
            break
            case 'stickertoimg':
            case 'stikertoimg':
            case 'toimg':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isQuotedSticker) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const mediaData = await decryptMedia(quotedMsg, uaOverride)
                        const imageBase64 = `data:${quotedMsg.mimetype};base64,${mediaData.toString('base64')}`
                        await anto.sendFile(from, imageBase64, 'sticker.jpg', '', id)
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'emojisticker':
            case 'emojistiker':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const emoji = emojiUnicode(q)
                await anto.reply(from, ind.wait(), id)
                console.log('Creating emoji code for =>', emoji)
                await anto.sendStickerfromUrl(from, `https://videfikri.com/api/emojitopng/?emojicode=${emoji}`)
                    .then(async () => {
                        await anto.reply(from, ind.ok(), id)
                        console.log(`Sticker processed for ${processTime(t, moment())} seconds`)
                    })
                    .catch(async (err) => {
                        console.error(err)
                        await anto.reply(from, 'Emoji not supported!', id)
                    })
            break

            // NSFW
            case 'multilewds':
            case 'multilewd':
            case 'mlewds':
            case 'mlewd':
                // Premium feature, contact the owner.
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                } else {
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                }
            break
            case 'multifetish':
            case 'mfetish':
                // Premium feature, contact the owner.
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                } else {
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                }
            break
            case 'lewds':
            case 'lewd':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    nsfw.randomLewd()
                        .then(async ({ url }) => {
                            await anto.sendFileFromUrl(from, url, 'lewd.jpg', '', null, null, true)
                                .then(() => console.log('Success sending lewd!'))
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    nsfw.randomLewd()
                        .then(async ({ url }) => {
                            await anto.sendFileFromUrl(from, url, 'lewd.jpg', '', null, null, true)
                                .then(() => console.log('Success sending lewd!'))
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                }
            break
            case 'fetish':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (ar.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        if (ar[0] === 'armpits') {
                            nsfw.armpits()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'armpits.jpg', '', id)
                                        .then(() => console.log('Success sending armpits pic!'))
                                })
                        } else if (ar[0] === 'feets') {
                            nsfw.feets()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'feets.jpg', '', id)
                                        .then(() => console.log('Success sending feets pic!'))
                                })
                        } else if (ar[0] === 'thighs') {
                            nsfw.thighs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'thighs.jpg', '', id)
                                        .then(() => console.log('Success sending thighs pic!'))
                                })
                        } else if (ar[0] === 'ass') {
                            nsfw.ass()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'ass.jpg', '', id)
                                        .then(() => console.log('Success sending ass pic!'))
                                })
                        } else if (ar[0] === 'boobs') {
                            nsfw.boobs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'boobs.jpg', '', id)
                                        .then(() => console.log('Success sending boobs pic!'))
                                })
                        } else if (ar[0] === 'belly') {
                            nsfw.belly()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'belly.jpg', '', id)
                                        .then(() => console.log('Success sending belly pic!'))
                                })
                        } else if (ar[0] === 'sideboobs') {
                            nsfw.sideboobs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'sideboobs.jpg', '', id)
                                        .then(() => console.log('Success sending sideboobs pic!'))
                                })
                        } else if (ar[0] === 'ahegao') {
                            nsfw.ahegao()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'ahegao.jpg', '', id)
                                        .then(() => console.log('Success sending ahegao pic!'))
                                })
                        } else {
                            await anto.reply(from, 'Tag not found.', id)
                        }
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, err, id)
                    }
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        if (ar[0] === 'armpits') {
                            nsfw.armpits()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'armpits.jpg', '', id)
                                        .then(() => console.log('Success sending armpits pic!'))
                                })
                        } else if (ar[0] === 'feets') {
                            nsfw.feets()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'feets.jpg', '', id)
                                        .then(() => console.log('Success sending feets pic!'))
                                })
                        } else if (ar[0] === 'thighs') {
                            nsfw.thighs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'thighs.jpg', '', id)
                                        .then(() => console.log('Success sending thighs pic!'))
                                })
                        } else if (ar[0] === 'ass') {
                            nsfw.ass()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'ass.jpg', '', id)
                                        .then(() => console.log('Success sending ass pic!'))
                                })
                        } else if (ar[0] === 'boobs') {
                            nsfw.boobs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'boobs.jpg', '', id)
                                        .then(() => console.log('Success sending boobs pic!'))
                                })
                        } else if (ar[0] === 'belly') {
                            nsfw.belly()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'belly.jpg', '', id)
                                        .then(() => console.log('Success sending belly pic!'))
                                })
                        } else if (ar[0] === 'sideboobs') {
                            nsfw.sideboobs()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'sideboobs.jpg', '', id)
                                        .then(() => console.log('Success sending sideboobs pic!'))
                                })
                        } else if (ar[0] === 'ahegao') {
                            nsfw.ahegao()
                                .then(async ({ url }) => {
                                    await anto.sendFileFromUrl(from, url, 'ahegao.jpg', '', id)
                                        .then(() => console.log('Success sending ahegao pic!'))
                                })
                        } else {
                            await anto.reply(from, 'Tag not found.', id)
                        }
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                }
            break
            case 'nhentai_':
            case 'nh':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (isNaN(Number(args[0]))) return await anto.reply(from, ind.wrongFormat(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    console.log(`Searching nHentai for ${args[0]}...`)
                    const validate = await nhentai.exists(args[0])
                    if (validate === true) {
                        try {
                            const pic = await api.getBook(args[0])
                                .then((book) => {
                                     return api.getImageURL(book.cover)
                                })
                            const dojin = await nhentai.getDoujin(args[0])
                            const { title, details, link } = dojin
                            const { tags, artists, languages, categories } = details
                            let teks = `*Title*: ${title}\n\n*Tags*: ${tags.join(', ')}\n\n*Artists*: ${artists}\n\n*Languages*: ${languages.join(', ')}\n\n*Categories*: ${categories}\n\n*Link*: ${link}`
                            await anto.sendFileFromUrl(from, pic, 'nhentai.jpg', teks, id)
                            console.log('Success sending nHentai info!')
                        } catch (err) {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        }
                    } else {
                        await anto.reply(from, ind.nhFalse(), id)
                    }
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    console.log(`Searching nHentai for ${args[0]}...`)
                    const validate = await nhentai.exists(args[0])
                    if (validate === true) {
                        try {
                            const pic = await api.getBook(args[0])
                                .then((book) => {
                                     return api.getImageURL(book.cover)
                                })
                            const dojin = await nhentai.getDoujin(args[0])
                            const { title, details, link } = dojin
                            const { tags, artists, languages, categories } = details
                            let teks = `*Title*: ${title}\n\n*Tags*: ${tags.join(', ')}\n\n*Artists*: ${artists}\n\n*Languages*: ${languages.join(', ')}\n\n*Categories*: ${categories}\n\n*Link*: ${link}`
                            await anto.sendFileFromUrl(from, pic, 'nhentai.jpg', teks, id)
                            console.log('Success sending nHentai info!')
                        } catch (err) {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        }
                    } else {
                        await anto.reply(from, ind.nhFalse(), id)
                    }
                }
            break
            case 'nhdl':
                // Premium feature, contact the owner.
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                } else {
                    if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
                    await anto.reply(from, ind.botNotPremium(), id)
                }
            break
            case 'nhsearch':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    console.log(`Searching nHentai for ${q}...`)
                    nana.search(q)
                        .then(async (g) => {
                            let txt = `-----[ *NHENTAI* ]-----\n\n➸ *Result for*: ${q}`
                            for (let i = 0; i < g.results.length; i++) {
                                const { id, title, language } = g.results[i]
                                txt += `\n\n➸ *Title*: ${title}\n➸ *Language*: ${language.charAt(0).toUpperCase() + language.slice(1)}\n➸ *Link*: nhentai.net/g/${id}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                            }
                            await anto.sendFileFromUrl(from, g.results[0].thumbnail.s, `${g.results[0].title}`, txt, id)
                                .then(() => console.log('Success sending nHentai results!'))
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    console.log(`Searching nHentai for ${q}...`)
                    nana.search(q)
                        .then(async (g) => {
                            let txt = `-----[ *NHENTAI* ]-----\n\n➸ *Result for*: ${q}`
                            for (let i = 0; i < g.results.length; i++) {
                                const { id, title, language } = g.results[i]
                                txt += `\n\n➸ *Title*: ${title}\n➸ *Language*: ${language.charAt(0).toUpperCase() + language.slice(1)}\n➸ *Link*: nhentai.net/g/${id}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                            }
                            await anto.sendFileFromUrl(from, g.results[0].thumbnail.s, `${g.results[0].title}`, txt, id)
                                .then(() => console.log('Success sending nHentai results!'))
                        })
                        .catch(async(err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                }
            break
            case 'nekopoi':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const res = await nekobocc.latest()
                        let text = '-----[ *NEKOPOI LATEST* ]-----'
                        for (let i = 0; i < res.result.length; i++) {
                            const { title, link } = res.result[i]
                            text += `\n\n➵ *Title*: ${title}\n➵ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, text, id)
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const res = await nekobocc.latest()
                        let text = '-----[ *NEKOPOI LATEST* ]-----'
                        for (let i = 0; i < res.result.length; i++) {
                            const { title, link } = res.result[i]
                            text += `\n\n➵ *Title*: ${title}\n➵ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, text, id)
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                }
            break
            case 'nekosearch':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const res = await nekobocc.search(q)
                        let text = '-----[ *NEKOPOI RESULT* ]-----'
                        for (let i = 0; i < res.result.length; i++) {
                            const { title, link } = res.result[i]
                            text += `\n\n➵ *Title*: ${title}\n➵ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, text, id)
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        const res = await nekobocc.search(q)
                        let text = '-----[ *NEKOPOI RESULT* ]-----'
                        for (let i = 0; i < res.result.length; i++) {
                            const { title, link } = res.result[i]
                            text += `\n\n➵ *Title*: ${title}\n➵ *Link*: ${link}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                        }
                        await anto.reply(from, text, id)
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                }
            break
            case 'waifu18':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    weeaboo.waifu(true)
                        .then(async ({ url }) => {
                            await anto.sendFileFromUrl(from, url, 'waifu.png', '', id)
                                .then(() => console.log('Success sending waifu!'))
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    weeaboo.waifu(true)
                        .then(async ({ url }) => {
                            await anto.sendFileFromUrl(from, url, 'waifu.png', '', id)
                                .then(() => console.log('Success sending waifu!'))
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                }
            break
            case 'phdl':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isUrl(url) && !url.includes('pornhub.com')) return await anto.reply(from, ind.wrongFormat(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        nsfw.phDl(url)
                            .then(async ({ title, download_urls, thumbnail_url }) => {
                                const count = Object.keys(download_urls).length
                                if (count !== 2) {
                                    const shortsLow = await misc.shortener(download_urls['240P'])
                                    const shortsMid = await misc.shortener(download_urls['480P'])
                                    const shortsHigh = await misc.shortener(download_urls['720P'])
                                    await anto.sendFileFromUrl(from, thumbnail_url, `${title}`, `Title: ${title}\n\nLinks:\n${shortsLow} (240P)\n${shortsMid} (480P)\n${shortsHigh} (720P)`, id)
                                        .then(() => console.log('Success sending pornhub metadata!'))
                                } else {
                                    const shortsLow = await misc.shortener(download_urls['240P'])
                                    await anto.sendFileFromUrl(from, thumbnail_url, `${title}`, `Title: ${title}\n\nLinks:\n${shortsLow} (240P)`, id)
                                        .then(() => console.log('Success sending pornhub metadata!'))
                                }
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    try {
                        nsfw.phDl(url)
                            .then(async ({ title, download_urls, thumbnail_url }) => {
                                const count = Object.keys(download_urls).length
                                if (count !== 2) {
                                    const shortsLow = await misc.shortener(download_urls['240P'])
                                    const shortsMid = await misc.shortener(download_urls['480P'])
                                    const shortsHigh = await misc.shortener(download_urls['720P'])
                                    await anto.sendFileFromUrl(from, thumbnail_url, `${title}`, `Title: ${title}\n\nLinks:\n${shortsLow} (240P)\n${shortsMid} (480P)\n${shortsHigh} (720P)`, id)
                                        .then(() => console.log('Success sending pornhub metadata!'))
                                } else {
                                    const shortsLow = await misc.shortener(download_urls['240P'])
                                    await anto.sendFileFromUrl(from, thumbnail_url, `${title}`, `Title: ${title}\n\nLinks:\n${shortsLow} (240P)`, id)
                                        .then(() => console.log('Success sending pornhub metadata!'))
                                }
                            })
                    } catch (err) {
                        console.error(err)
                        await anto.reply(from, 'Error!', id)
                    }
                }
            break
            case 'yuri':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.eroYuri()).url, 'yuri.jpg', '', id)
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.eroYuri()).url, 'yuri.jpg', '', id)
                }
            break
            case 'lewdavatar':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.avatar()).url, 'avatar.jpg', '', id)
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.avatar()).url, 'avatar.jpg', '', id)
                }
            break
            case 'femdom':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.femdom()).url, 'femdom.jpg', '', id)
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    await anto.sendFileFromUrl(from, (await neko.nsfw.femdom()).url, 'femdom.jpg', '', id)
                }
            break
            case 'cersex':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (isGroupMsg) {
                    if (!isNsfw) return await anto.reply(from, ind.notNsfw(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    nsfw.cersex()
                        .then(async ({ result }) => {
                            await anto.sendFileFromUrl(from, result.image, 'cersex.jpg', `── *「 ${result.judul} 」* ──\n\n${result.cerita}`, id)
                            console.log('Success sending cersex!')
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                } else {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    nsfw.cersex()
                        .then(async ({ result }) => {
                            await anto.sendFileFromUrl(from, result.image, 'cersex.jpg', `── *「 ${result.judul} 」* ──\n\n${result.cerita}`, id)
                            console.log('Success sending cersex!')
                        })
                        .catch(async (err) => {
                            console.error(err)
                            await anto.reply(from, 'Error!', id)
                        })
                }
            break

            // Moderation command
            case 'revoke':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return anto.reply(from, ind.botNotAdmin(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.revokeGroupInviteLink(groupId);
                anto.sendTextWithMentions(from, `Group link revoked by @${sender.id.replace('@c.us', '')}`)
            break
            case 'linkgroup':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const gcLink = await anto.getGroupInviteLink(groupId)
                const linkGc = `Group: *${formattedTitle}*\n\nLink: ${gcLink}`
                anto.reply(from, linkGc, id)
            break
            case 'ownergroup':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const ownerGc = chat.groupMetadata.owner
                await anto.sendTextWithMentions(from, `Owner Group : @${ownerGc}`)
            break
            case 'mutegc':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return anto.reply(from, ind.botNotAdmin(), id)
                if (ar[0] === 'enable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.setGroupToAdminsOnly(groupId, true)
                    await anto.sendText(from, ind.gcMute())
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.setGroupToAdminsOnly(groupId, false)
                    await anto.sendText(from, ind.gcUnmute())
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'add':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (args.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                try {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.addParticipant(from, `${args[0]}@c.us`)
                    await anto.sendText(from, '🎉 Welcome! 🎉')
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'kick':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (mentionedJidList.length === 0) return await anto.reply(from, ind.wrongFormat(), id)
                if (mentionedJidList[0] === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.sendTextWithMentions(from, `Good bye~\n${mentionedJidList.map(x => `@${x.replace('@c.us', '')}`).join('\n')}`)
                for (let i of mentionedJidList) {
                    if (groupAdmins.includes(i)) return await anto.sendText(from, ind.wrongFormat())
                    await anto.removeParticipant(groupId, i)
                }
            break
            case 'promote':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (mentionedJidList.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (mentionedJidList[0] === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                if (groupAdmins.includes(mentionedJidList[0])) return await anto.reply(from, ind.adminAlready(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.promoteParticipant(groupId, mentionedJidList[0])
                await anto.reply(from, ind.ok(), id)
            break
            case 'demote':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (mentionedJidList.length !== 1) return await anto.reply(from, ind.wrongFormat(), id)
                if (mentionedJidList[0] === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                if (!groupAdmins.includes(mentionedJidList[0])) return await anto.reply(from, ind.notAdmin(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                await anto.demoteParticipant(groupId, mentionedJidList[0])
                await anto.reply(from, ind.ok(), id)
            break
            case 'leave':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                await anto.sendText(from, 'Sayounara~ 👋')
                await anto.leaveGroup(groupId)
            break
            case 'admins':
            case 'admin':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const groupAdm = await anto.getGroupAdmins(groupId)
                const lastAdmin = daily.getLimit(sender.id, _daily)
                if (lastAdmin !== undefined && cd - (Date.now() - lastAdmin) > 0) {
                    const time = ms(cd - (Date.now() - lastAdmin))
                    await anto.reply(from, ind.daily(time), id)
                } else if (isOwner) {
                    let txt = '╔══✪〘 *ADMINS* 〙✪══\n'
                    for (let i = 0; i < groupAdm.length; i++) {
                        txt += '╠➥'
                        txt += ` @${groupAdm[i].replace(/@c.us/g, '')}\n`
                    }
                    txt += '╚═〘 *P A I M O N  B O T* 〙'
                    await anto.sendTextWithMentions(from, txt)
                } else {
                    let txt = '╔══✪〘 *ADMINS* 〙✪══\n'
                    for (let i = 0; i < groupAdm.length; i++) {
                        txt += '╠➥'
                        txt += ` @${groupAdm[i].replace(/@c.us/g, '')}\n`
                    }
                    txt += '╚═〘 *P A I M O N  B O T* 〙'
                    await anto.sendTextWithMentions(from, txt)
                    daily.addLimit(sender.id, _daily)
                }
            break
            case 'tagall':
            case 'pengumuman':
            case 'info':
            if (!isPremium) return await anto.reply(from, ind.notPremium(), id)
             if (!q) return await anto.reply(from, ind.wrongFormat(), id)
            if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
            if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
            if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
            if (!isBotGroupAdmins) return anto.reply(from, ind.botNotAdmin(), id)
            const groupMem_ = await anto.getGroupMembers(groupId)
            let hoho = `${q}\n`
            for (let i = 0; i < groupMem_.length; i++) {
                hoho += '*✨'
                hoho += ` @${groupMem_[i].id.replace(/@c.us/g, '')}*\n`
            }
            hoho += '👑〘 *P A I M O N   B O T* 〙👑'
    // await sleep(2000)
            await anto.sendTextWithMentions(from, hoho)
            break
            case 'everyone':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                limit.addLimit(sender.id, _limit, isPremium, isOwner)
                const groupMem = await anto.getGroupMembers(groupId)
                const lastEveryone = daily.getLimit(sender.id, _daily)
                if (lastEveryone !== undefined && cd - (Date.now() - lastEveryone) > 0) {
                    const time = ms(cd - (Date.now() - lastEveryone))
                    await anto.reply(from, ind.daily(time), id)
                } else if (isOwner) {
                    let txt = '╔══✪〘 *EVERYONE* 〙✪══\n'
                        for (let i = 0; i < groupMem.length; i++) {
                            txt += '╠➥'
                            txt += ` @${groupMem[i].id.replace(/@c.us/g, '')}\n`
                        }
                    txt += '╚═〘 *P A I M O N  B O T* 〙'
                    await anto.sendTextWithMentions(from, txt)
                } else {
                    let txt = '╔══✪〘 Mention All 〙✪══\n'
                        for (let i = 0; i < groupMem.length; i++) {
                            txt += '╠➥'
                            txt += ` @${groupMem[i].id.replace(/@c.us/g, '')}\n`
                        }
                    txt += '╚═〘 *P A I M O N  B O T* 〙'
                    await anto.sendTextWithMentions(from, txt)
                    daily.addLimit(sender.id, _daily)
                }
            break
            case 'groupicon':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return anto.reply(from, ind.botNotAdmin(), id)
                if (isMedia && isImage || isQuotedImage) {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    await anto.reply(from, ind.wait(), id)
                    const encryptMedia = isQuotedImage ? quotedMsg : message
                    const _mimetype = isQuotedImage ? quotedMsg.mimetype : mimetype
                    const mediaData = await decryptMedia(encryptMedia, uaOverride)
                    const imageBase64 = `data:${_mimetype};base64,${mediaData.toString('base64')}`
                    await anto.setGroupIcon(groupId, imageBase64)
                    await anto.sendText(from, ind.ok())
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'antilink':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (ar[0] === 'enable') {
                    if (isDetectorOn) return await anto.reply(from, ind.detectorOnAlready(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _antilink.push(groupId)
                    fs.writeFileSync('./database/group/antilink.json', JSON.stringify(_antilink))
                    await anto.reply(from, ind.detectorOn(name, formattedTitle), id)
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _antilink.splice(groupId, 1)
                    fs.writeFileSync('./database/group/antilink.json', JSON.stringify(_antilink))
                    await anto.reply(from, ind.detectorOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'leveling':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (ar[0] === 'enable') {
                    if (isLevelingOn) return await anto.reply(from, ind.levelingOnAlready(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _leveling.push(groupId)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                    await anto.reply(from, ind.levelingOn(), id)
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _leveling.splice(groupId, 1)
                    fs.writeFileSync('./database/group/leveling.json', JSON.stringify(_leveling))
                    await anto.reply(from, ind.levelingOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'welcome':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (ar[0] === 'enable') {
                    if (isWelcomeOn) return await anto.reply(from, ind.welcomeOnAlready(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _welcome.push(groupId)
                    fs.writeFileSync('./database/group/welcome.json', JSON.stringify(_welcome))
                    await anto.reply(from, ind.welcomeOn(), id)
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _welcome.splice(groupId, 1)
                    fs.writeFileSync('./database/group/welcome.json', JSON.stringify(_welcome))
                    await anto.reply(from, ind.welcomeOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'autosticker':
            case 'autostiker':
            case 'autostik':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (ar[0] === 'enable') {
                    if (isAutoStickerOn) return await anto.reply(from, ind.autoStikOnAlready(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _autosticker.push(groupId)
                    fs.writeFileSync('./database/group/autosticker.json', JSON.stringify(_autosticker))
                    await anto.reply(from, ind.autoStikOn(), id)
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _autosticker.splice(groupId, 1)
                    fs.writeFileSync('./database/group/autosticker.json', JSON.stringify(_autosticker))
                    await anto.reply(from, ind.autoStikOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'antinsfw':
                if (!isRegistered) return await anto.reply(from, ind.notRegistered(), id)
                if (!isGroupMsg) return await anto.reply(from, ind.groupOnly(), id)
                if (!isGroupAdmins) return await anto.reply(from, ind.adminOnly(), id)
                if (!isBotGroupAdmins) return await anto.reply(from, ind.botNotAdmin(), id)
                if (ar[0] === 'enable') {
                    if (isDetectorOn) return await anto.reply(from, ind.antiNsfwOnAlready(), id)
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _antinsfw.push(groupId)
                    fs.writeFileSync('./database/group/antinsfw.json', JSON.stringify(_antinsfw))
                    await anto.reply(from, ind.antiNsfwOn(name, formattedTitle), id)
                } else if (ar[0] === 'disable') {
                    if (limit.isLimit(sender.id, _limit, limitCount, isPremium, isOwner)) return await anto.reply(from, ind.limit(), id)
                    limit.addLimit(sender.id, _limit, isPremium, isOwner)
                    _antinsfw.splice(groupId, 1)
                    fs.writeFileSync('./database/group/antinsfw.json', JSON.stringify(_antinsfw))
                    await anto.reply(from, ind.antiNsfwOff(), id)
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break

            // Owner command
            case 'bc':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q) return await anto.reply(from, ind.emptyMess(), id)
                const chats = await anto.getAllChatIds()
                for (let bcs of chats) {
                    let cvk = await anto.getChatById(bcs)
                    if (!cvk.isReadOnly) await anto.sendText(bcs, `${q}\n\n- Slavyan (Kal)\n_Broadcasted message_`)
                }
                await anto.reply(from, ind.doneOwner(), id)
            break
            case 'clearall':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                const allChats = await anto.getAllChats()
                for (let delChats of allChats) {
                    await anto.deleteChat(delChats.id)
                }
                await anto.reply(from, ind.doneOwner(), id)
            break
            case 'leaveall':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q) return await anto.reply(from, ind.emptyMess(), id)
                const allGroup = await anto.getAllGroups()
                for (let gclist of allGroup) {
                    await anto.sendText(gclist.contact.id, q)
                    await anto.leaveGroup(gclist.contact.id)
                }
                await anto.reply(from, ind.doneOwner())
            break
            case 'getses':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                const ses = await anto.getSnapshot()
                await anto.sendFile(from, ses, 'session.png', ind.doneOwner())
            break
            case 'ban':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (ar[0] === 'add') {
                    if (mentionedJidList.length !== 0) {
                        for (let benet of mentionedJidList) {
                            if (benet === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                            _ban.push(benet)
                            fs.writeFileSync('./database/bot/banned.json', JSON.stringify(_ban))
                        }
                        await anto.reply(from, ind.doneOwner(), id)
                    } else {
                        _ban.push(args[1] + '@c.us')
                        fs.writeFileSync('./database/bot/banned.json', JSON.stringify(_ban))
                        await anto.reply(from, ind.doneOwner(), id)
                    }
                } else if (ar[0] === 'del') {
                    if (mentionedJidList.length !== 0) {
                        if (mentionedJidList[0] === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                        _ban.splice(mentionedJidList[0], 1)
                        fs.writeFileSync('./database/bot/banned.json', JSON.stringify(_ban))
                        await anto.reply(from, ind.doneOwner(), id)
                    } else{
                        _ban.splice(args[1] + '@c.us', 1)
                        fs.writeFileSync('./database/bot/banned.json', JSON.stringify(_ban))
                        await anto.reply(from, ind.doneOwner(), id)
                    }
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'eval':
            case 'ev':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q) return await anto.reply(from, ind.wrongFormat(), id)
                try {
                    let evaled = await eval(q)
                    if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
                    await anto.sendText(from, evaled)
                } catch (err) {
                    console.error(err)
                    await anto.reply(from, 'Error!', id)
                }
            break
            case 'shutdown':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                await anto.sendText(from, 'Otsukaresama deshita~ 👋')
                    .then(async () => await anto.kill())
                    .catch(() => new Error('Target closed.'))
            break
            case 'premium':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (ar[0] === 'add') {
                    if (mentionedJidList.length !== 0) {
                        for (let benet of mentionedJidList) {
                            if (benet === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                            premium.addPremiumUser(benet, args[2], _premium)
                            await anto.reply(from, `*「 PREMIUM ADDED 」*\n\n➸ *ID*: ${benet}\n➸ *Expired*: ${ms(toMs(args[2])).days} day(s) ${ms(toMs(args[2])).hours} hour(s) ${ms(toMs(args[2])).minutes} minute(s)`, id)
                        }
                    } else {
                        premium.addPremiumUser(args[1] + '@c.us', args[2], _premium)
                        await anto.reply(from, `*「 PREMIUM ADDED 」*\n\n➸ *ID*: ${args[1]}@c.us\n➸ *Expired*: ${ms(toMs(args[2])).days} day(s) ${ms(toMs(args[2])).hours} hour(s) ${ms(toMs(args[2])).minutes} minute(s)`, id)
                    }
                } else if (ar[0] === 'del') {
                    if (mentionedJidList.length !== 0) {
                        if (mentionedJidList[0] === botNumber) return await anto.reply(from, ind.wrongFormat(), id)
                        _premium.splice(premium.getPremiumPosition(mentionedJidList[0], _premium), 1)
                        fs.writeFileSync('./database/bot/premium.json', JSON.stringify(_premium))
                        await anto.reply(from, ind.doneOwner(), id)
                    } else {
                        _premium.splice(premium.getPremiumPosition(args[1] + '@c.us', _premium), 1)
                        fs.writeFileSync('./database/bot/premium.json', JSON.stringify(_premium))
                        await anto.reply(from, ind.doneOwner(), id)
                    }
                } else {
                    await anto.reply(from, ind.wrongFormat(), id)
                }
            break
            case 'setstatus':
            case 'setstats':
            case 'setstat':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q) return await anto.reply(from, ind.emptyMess(), id)
                await anto.setMyStatus(q)
                await anto.reply(from, ind.doneOwner(), id)
            break
            case 'exif':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q.includes('|')) return await anto.reply(from, ind.wrongFormat(), id)
                const namaPack = q.substring(0, q.indexOf('|') - 1)
                const authorPack = q.substring(q.lastIndexOf('|') + 2)
                exif.create(namaPack, authorPack)
                await anto.reply(from, ind.doneOwner(), id)
            break
            case 'mute':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (isMute) {
                    _mute.splice(sender.id, 1)
                    fs.writeFileSync('./database/bot/mute.json', JSON.stringify(_mute))
                    await anto.reply(from, 'Success unmute!', id)
                } else {
                    _mute.push(sender.id)
                    fs.writeFileSync('./database/bot/mute.json', JSON.stringify(_mute))
                    await anto.reply(from, 'Success mute!', id)
                }
            break
            case 'setname':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (!q || q.length > 25) return await anto.reply(from, ind.wrongFormat(), id)
                await anto.setMyName(q)
                await anto.reply(from, `Done!\n\nUsername changed to: ${q}`, id)
            break
            case 'give':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                if (args.length !== 2) return await anto.reply(from, ind.wrongFormat(), id)
                if (mentionedJidList.length !== 0) {
                    for (let give of mentionedJidList) {
                        level.addLevelingXp(give, Number(args[1]), _level)
                        await anto.reply(from, `Sukses menambah XP kepada: ${give}\nJumlah ditambahkan: ${args[1]}`, id)
                    }
                } else {
                    level.addLevelingXp(args[0] + '@c.us', Number(args[1]), _level)
                    await anto.reply(from, `Sukses menambah XP kepada: ${args[0]}\nJumlah ditambahkan: ${args[1]}`, id)
                }
            break
            case 'listgroup':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                    anto.getAllGroups().then((res) => {
                    let gc = '*Group list*:\n'
                    for (let i = 0; i < res.length; i++) {
                        gc += `\n\n*No*: ${i+1}\n*Nama*: ${res[i].name}\n*Unread messages*: ${res[i].unreadCount} messages\n\n=_=_=_=_=_=_=_=_=_=_=_=_=`
                    }
                    anto.reply(from, gc, id)
                })
            break
            case 'reset':
                if (!isOwner) return await anto.reply(from, ind.ownerOnly(), id)
                const reset = []
                _limit = reset
                console.log('Resetting user\'s limit...')
                fs.writeFileSync('./database/user/limit.json', JSON.stringify(_limit))
                await anto.reply(from, ind.doneOwner(), id)
                console.log('Success!')
            break
            
            
            default:
                if (isCmd) {
                    await anto.reply(from, ind.cmdNotFound(command), id)
                }
            break
        }
    } catch (err) {
        console.error(color('[ERROR]', 'red'), err)
    }
}
/********** END OF MESSAGE HANDLER **********/
