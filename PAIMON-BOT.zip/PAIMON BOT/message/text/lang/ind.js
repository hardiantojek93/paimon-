/* eslint-disable quotes */
const fs = require('fs-extra')
const { prefix } = JSON.parse(fs.readFileSync('config.json'))

exports.wait = () => {
    return `*[ WAIT ] MOHON UNTUK SEBENTAR*\n_Jangan Lupa Follow IG: instagram.com/hardianto02__`
}

exports.ok = () => {
    return `_*Makasih Sudah menggunakan Bot Paimon~*_\n_Dan jangan lupa follow https://instagram.com/hardianto02__`
}

exports.wrongFormat = () => {
    return `*Maaf Format Yang Anda Masukan Salah mohon Untuk CP: wa.me/6287811078485.*`
}

exports.emptyMess = () => {
    return `Harap masukkan pesan yang ingin disampaikan!`
}

exports.cmdNotFound = (cmd) => {
    return `Command *${prefix}${cmd}* tidak ditemukan!`
}

exports.blocked = (ownerNumber) => {
    return `Bot tidak menerima panggilan. Karena kamu telah melanggar rules, maka kamu telah diblok!\n\nHarap hubungi owner: wa.me/${ownerNumber.replace('@c.us', '')}`
}

exports.ownerOnly = () => {
    return `Maaf Perintah Tersebut Hanya Untuk Owner Saya!`
}

exports.doneOwner = () => {
    return `*Udah Kak Hardianto Senpai~*`
}

exports.groupOnly = () => {
    return `*Mohon untuk menggunakan Perintah ini Di Dalam Group!*\nMasukin Bot ke Group?\n*Gampang Cukup Chat wa.me/6287811078485"`
}

exports.adminOnly = () => {
    return `*Maaf Perintah Ini Hanya Untuk Admin Group!*`
}

exports.notNsfw = () => {
    return `*Maaf Nampak Nya Perintah NSFW belum Di Izin Kan Dalam Group ini klik !nsfw enable untuk mengaktifkan NSFW(Admin Group)*`
}

exports.nsfwOn = () => {
    return `*✨Berhasil mengaktifkan NSFW Sekarang Fitur NSFW Sudah Bisa Di gunakan!`
}

exports.nsfwOff = () => {
    return `*Berhasil Menonaktifkan NSFW Sekarang Fitur NSFW Tidak Bisa Di Gunakan Lagi Dalam Group ini*!`
}

exports.nsfwAlready = () => {
    return `*Perintah Sudah Di aktifkan Sbelum nya*`
}

exports.addedGroup = (chat) => {
    return `Terima kasih telah mengundangku, para member *${chat.contact.name}*!\n\nSilakan register dengan cara ketik:\n*${prefix}register* nama | umur`
}

exports.nhFalse = () => {
    return `Kode tidak valid!`
}

exports.listBlock = (blockNumber) => {
    return `------[ HALL OF SHAME ]------\n\nTotal diblokir: *${blockNumber.length}* user\n`
}

exports.notPremium = () => {
    return `*Maaf! Ini Khusus Elite\n Jika ingin menjadi elite !howtoprem.*`
}

exports.notAdmin = () => {
    return `Anda siapa? Anda bukan Admin!`
}

exports.adminAlready = () => {
    return `Tidak dapat mem-promote user yang merupakan admin!`
}

exports.botNotPremium = () => {
    return `Bot ini tidak mendukung command premium. Silakan hubungi pemilik bot ini.`
}

exports.botNotAdmin = () => {
    return `Jadikan bot sebagai admin terlebih dahulu!`
}

exports.ytFound = (res) => {
    return `*Video ditemukan!*\n\n➸ *Judul*: ${res.title}\n➸ *Deskripsi*:\n${res.desc}\n➸ *Durasi*: ${res.duration} menit\n\nMedia sedang dikirim, mohon tunggu...`
}

exports.notRegistered = () => {
    return `Kamu belum terdaftar di database!\n\nSilakan register dengan format:\n*${prefix}register* nama | umur\n\nNote:\nHarap save nomor ku agar bisa mendapatkan serial!!`
}

exports.registered = (name, age, userId, time, serial) => {
    return `*「 REGISTRATION 」*\n\nAkun kamu telah terdaftar dengan data:\n\n➸ *Nama*: ${name}\n➸ *Umur*: ${age}\n➸ *ID*: ${userId}\n➸ *Waktu pendaftaran*: ${time}\n➸ *Serial*: ${serial}\n\nCatatan:\nJangan pernah menyebarkan data *serial* ke pada siapapun!\n\nKetik *${prefix}rules* terlebih dahulu ya~`
}

exports.registeredAlready = () => {
    return `Kamu sudah mendaftar sebelumnya.`
}

exports.received = (pushname) => {
    return `Halo ${pushname}!\nTerima kasih telah melapor, laporanmu akan kami segera terima.`
}

exports.daily = (time) => {
    return `Maaf, tetapi kamu telah mencapai limit menggunakan command ini.\nSilakan tunggu *${time.hours}* jam *${time.minutes}* menit *${time.seconds}* detik lagi.`
}

exports.videoLimit = () => {
    return `Ukuran video terlalu besar!`
}

exports.joox = (result) => {
    return `*Lagu ditemukan!*\n\n➸ *Penyanyi*: ${result[0].penyanyi}\n➸ *Judul*: ${result[0].judul}\n➸ *Album*: ${result[0].album}\n➸ *Ext*: ${result[0].ext}\n➸ *Size*: ${result[0].filesize}\n➸ *Durasi*: ${result[0].duration}\n\nMedia sedang dikirim, mohon tunggu...`
}

exports.gsm = (result) => {
    return `➸ *Model HP*: ${result.title}\n➸ *Spesifikasi*: ${result.spec}`
}

exports.receipt = (result) => {
    return `${result.title}\n\n${result.desc}\n\n*Bahan*: ${result.bahan}\n\n*Cara membuat*:\n${result.cara}`
}

exports.ytResult = (link, title, channel, duration, views) => {
    return `➸ *Judul*: ${title}\n➸ *Channel*: ${channel}\n➸ *Durasi*: ${duration}\n➸ *Views*: ${views}\n➸ *Link*: ${link}`
}

exports.profile = (username, status, premi, benet, adm, level, requiredXp, xp) => {
    return `-----[ *USER INFO* ]-----\n\n➸ *Username*: ${username}\n➸ *Status*: ${status}\n➸ *Premium*: ${premi}\n➸ *Banned*: ${benet}\n➸ *Admin*: ${adm}\n\n=_=_=_=_=_=_=_=_=_=_=_=_=\n\nYour progress:\n➸ *Level*: ${level}\n➸ *XP*: ${xp} / ${requiredXp}`
}

exports.detectorOn = (name, formattedTitle) => {
    return `*「 ANTI GROUP LINK 」*\n\nPerhatian untuk penghuni grup ${(name || formattedTitle)}\nGrup ini memiliki anti-group link detector, apabila ada salah satu member mengirim group link di sini maka dia akan ter-kick secara otomatis.\n\nSekian terima kasih.\n- Admin ${(name || formattedTitle)}`
}

exports.detectorOff = () => {
    return `Fitur anti-group link berhasil *dinonaktifkan*!`
}

exports.detectorOnAlready = () => {
    return `Fitur anti-group link telah diaktifkan sebelumnya.`
}

exports.antiNsfwOn = (name, formattedTitle) => {
    return `*「 ANTI NSFW LINK 」*\n\nPerhatian untuk penghuni grup ${(name || formattedTitle)}\nGrup ini memiliki anti-NSFW link detector, apabila ada salah satu member mengirim link NSFW/porn di sini maka dia akan ter-kick secara otomatis.\n\nSekian terima kasih.\n- Admin ${(name || formattedTitle)}`
}

exports.antiNsfwOff = () => {
    return `Fitur anti-NSFW link berhasil *dinonaktifkan*!`
}

exports.antiNsfwOnAlready = () => {
    return `Fitur anti-NSFW link telah diaktifkan sebelumnya.`
}

exports.linkDetected = () => {
    return `*「 ANTI GROUP LINK 」*\n\nKamu mengirim link group chat!\nMaaf tapi kami harus mengeluarkan mu...\nSelamat tinggal~`
}

exports.levelingOn = () => {
    return `Fitur leveling berhasil *diaktifkan*!`
}

exports.levelingOff = () => {
    return `Fitur leveling berhasil *dinonaktifkan*!`
}

exports.levelingOnAlready = () => {
    return `Fitur leveling telah diaktifkan sebelumnya.`
}

exports.levelingNotOn = () => {
    return `Fitur leveling belum diaktifkan!`
}

exports.levelNull = () => {
    return `Kamu belum memiliki level!`
}

exports.welcome = (event) => {
    return `Selamat datang @${event.who.replace('@c.us', '')}!\n\nSemoga betah terus di grup kami ya~`
}

exports.welcomeOn = () => {
    return `Fitur welcome berhasil *diaktifkan*!`
}

exports.welcomeOff = () => {
    return `Fitur welcome berhasil *dinonaktifkan*!`
}

exports.welcomeOnAlready = () => {
    return `Fitur welcome telah diaktifkan sebelumnya.`
}

exports.minimalDb = () => {
    return `Perlu setidaknya *10* user yang memiliki level di database!`
}

exports.autoStikOn = () => {
    return `Fitur auto-stiker berhasil *diaktifkan*!`
}

exports.autoStikOff = () => {
    return `Fitur auto-stiker berhasil *dinonaktifkan*!`
}

exports.autoStikOnAlready = () => {
    return `Fitur auto-stiker telah diaktifkan sebelumnya.`
}

exports.afkOn = (pushname, reason) => {
    return `Fitur AFK berhasil *diaktifkan*!\n\n➸ *Username*: ${pushname}\n➸ *Alasan*: ${reason}`
}

exports.afkOnAlready = () => {
    return `Fitur AFK telah diaktifkan sebelumnya.`
}

exports.afkMentioned = (getReason, getTime) => {
    return `*「 AFK MODE 」*\n\nSssttt! Orangnya lagi AFK, jangan diganggu!\n➸ *Alasan*: ${getReason}\n➸ *Sejak*: ${getTime}`
}

exports.afkDone = (pushname) => {
    return `*${pushname}* telah kembali dari AFK! Selamat datang kembali~`
}

exports.gcMute = () => {
    return `*「 MUTED 」*\n\nHanya admin yang dapat mengirim pesan ke grup ini.`
}

exports.gcUnmute = () => {
    return `*「 UNMUTED 」*\n\nSekarang semua anggota dapat mengirim chat di grup ini.`
}

exports.notNum = (q) => {
    return `"${q}", bukan angka!`
}

exports.playstore = (app_id, title, developer, description, price, free) => {
    return `➸ *Nama*: ${title}\n➸ *ID*: ${app_id}\n➸ *Developer*: ${developer}\n➸ *Gratis*: ${free}\n➸ *Harga*: ${price}\n➸ *Deskripsi*: ${description}`
}

exports.shopee = (nama, harga, terjual, shop_location, description, link_product) => {
    return `➸ *Nama*: ${nama}\n➸ *Harga*: ${harga}\n➸ *Terjual*: ${terjual}\n➸ *Lokasi*: ${shop_location}\n➸ *Link produk*: ${link_product}\n➸ *Deskripsi*: ${description}`
}

exports.pc = (pushname) => {
    return `*「 REGISTRATION 」*\n\nAkun kamu berhasil terdaftar! Silakan cek pesan ku di private chat mu ya ${pushname}~ :3\n\nNote:\nJika kamu tidak menerima pesan, artinya kamu belum save nomor bot.`
}

exports.registeredFound = (name, age, time, serial, userId) => {
    return `*「 REGISTERED 」*\n\nAkun ditemukan!\n\n➸ *Nama*: ${name}\n➸ *Umur*: ${age}\n➸ *ID*: ${userId}\n➸ *Waktu pendaftaran*: ${time}\n➸ *Serial*: ${serial}`
}

exports.registeredNotFound = (serial) => {
    return `Akun dengan serial: *${serial}* tidak ditemukan!`
}

exports.ytPlay = (result) => {
    return `*「 PLAY 」*\n\n➸ *Judul*: ${result.title}\n➸ *Link*: ${result.url}\n\nMedia sedang dikirim, mohon tunggu...`
}
exports.pcOnly = () => {
    return `Command ini hanya bisa digunakan di dalam private chat saja!`
}
exports.premiumMenu = (pushname) => {
  return `
╔══❉ *Premium Zone* ❉═══
║ *_Yok Kak ${pushname}_*
║ *_Great Good Days_*
║ _Semoga Sehat Selalu ✨_
╟ _Thanks Using Bot_
╚══❉ *PAIMONBOT* ❉═══

╔══❉ *MUSIC* ❉═══
╟⊱ *${prefix}play <Judul Music>*
╟⊱ *${prefix}tiktok <Link_Tik>*
╟⊱ *${prefix}ytmp3 <link_Yt>*
╟⊱ *${prefix}ytmp4  <link_Yt>*
╟⊱ *${prefix}igdl <Link_Ig>*
╟⊱ *${prefix}playv <Judul_Video>*
╚══❉ *PAIMONBOT* ❉═══

╔══❉ *Search* ❉═══
╟⊱ *${prefix}pinterest <Query>*
╟⊱ *${prefix}googleimage <Query>*
╟⊱ *${prefix}pixiv <Query>*
╟⊱ *${prefix}wallpaper <Query>*
╟⊱ *${prefix}konachan <Query>*
╚══❉ *PAIMONBOT* ❉════

╔══❉ *Wibu&Kpop* ❉═══
╟⊱ *${prefix}nsfwloli <Random>*
╟⊱ *${prefix}nsfwloli2 <Random>*
╟⊱ *${prefix}nhentai <Kode_Nuklir>*
╟⊱ *${prefix}wallpapernime <Random>*
╟⊱ *${prefix}husbu <Random>*
╟⊱ *${prefix}ecchi <Random>*
╟⊱ *${prefix}fanart <Random>*
╟⊱ *${prefix}elf <Random>*
╟⊱ *${prefix}shinobu <Random>*
╟⊱ *${prefix}bts <Random>*
╟⊱ *${prefix}exo <Random>*
╚══❉ *PAIMONBOT* ❉════ 

╔══❉ *CREATOR ZONE* ❉═══
╟⊱ *${prefix}takestick pack | author*
╟⊱ *${prefix}stickerwm pack | author*
╟⊱ *${prefix}sgifwm pack | author*
╟⊱ *${prefix} telestick <Url>*
╟⊱ *${prefix}attp <Text>*
╟⊱ *${prefix}mememaker <Tag photo >> capt: atas | bawah>*
╟⊱ *${prefix}calendar <Tag photo/photo with capt>*
╟⊱ *${prefix}sfire <Tag photo/photo with capt>*
╟⊱ *${prefix}sfrez <Tag photo/photo with capt>*
╟⊱ *${prefix}snobg <Tag Photo/photo with capt>*
╟⊱ *${prefix}sflow <Tag Photo/Photo with capt>*
╟⊱ *${prefix}carbon <Code>*
╚══❉ *PAIMONBOT* ❉════

╔══❉ *Unlocked CMD* ❉═══
╟⊱ *${prefix}join <Link Group>*
╟⊱ *${prefix}info <Teks Announcement>*
╟⊱ *${prefix}textpromenu <Unlocked all>*
╚══❉ *PAIMONBOT* ❉════


You Can Get Premium From Hardianto: wa.me/6287811078485?text=*I+Can+Buy+Premium+paimon*+
_________________________________________________`
}
exports.linkNsfw = () => {
    return `*「 ANTI NSFW LINK 」*\n\nKamu telah mengirim link NSFW!\nMaaf, tapi aku harus mengeluarkan mu...`
}

exports.ageOld = () => {
    return `Kamu terlalu tua untuk menggunakan fitur ini! Mohon kembali ke masa muda anda agar bisa menggunakannya.`
}

exports.menuText = () => {
    return `
╔══❉ *𝐓𝐞𝐱𝐭 𝐌𝐚𝐤𝐞𝐫 (PRO?)* ❉═══
╟⊱ *${prefix}neongreen* _teks_
╟⊱ *${prefix}future* _teks_
╟⊱ *${prefix}sandwrite* _teks_
╟⊱ *${prefix}sandsummer* _teks_
╟⊱ *${prefix}sandengraved* _teks_
╟⊱ *${prefix}metaldark* _teks_
╟⊱ *${prefix}neonlight* _teks_
╟⊱ *${prefix}text1917* _teks_
╟⊱ *${prefix}minion* _teks_
╟⊱ *${prefix}newyear* _teks_
╟⊱ *${prefix}deluxesilver* _teks_
╟⊱ *${prefix}bloodfrosted* _teks_
╟⊱ *${prefix}halloween* _teks_
╟⊱ *${prefix}jokerlogo* _teks_
╟⊱ *${prefix}firemaker* _teks_
╟⊱ *${prefix}natureleaves* _teks_
╟⊱ *${prefix}bokeh* _teks_
╟⊱ *${prefix}strawberry* _teks_
╟⊱ *${prefix}box3d* _teks_
╟⊱ *${prefix}roadwarning* _teks_
╟⊱ *${prefix}breakwall* _teks_
╟⊱ *${prefix}icecold* _teks_
╟⊱ *${prefix}cloud* _teks_ 
╟⊱ *${prefix}luxury*_teks_
╟⊱ *${prefix}tahta* _teks_
╟⊱ *${prefix}summersand* _teks_
╟⊱ *${prefix}horrorblood* _teks_
╟⊱ *${prefix}thunder* _teks_
╚══❉ *PAIMONBOT* ❉════

╔══❉ *DOUBLE TEXT* ❉═══
╟⊱ *${prefix}phlogo* _teks1 | Teks2_
╟⊱ *${prefix}gltext* _teks1 | Tek2_
╟⊱ *${prefix}lionlogo* _teks1 | Tek2_
╟⊱ *${prefix}avenger* _teks1 | Tek2_
╟⊱ *${prefix}space* _teks1 | Tek2_
╟⊱ *${prefix}ninja* _teks1 | Tek2_
╟⊱ *${prefix}marvel* _teks1 | Tek2_
╟⊱ *${prefix}wolf* _teks1 | Tek2_
╟⊱ *${prefix}steel3d* _teks1 | Tek2_
║
╚══❉ *PAIMONBOT* ❉════
    `
}
exports.fakeLink = () => {
    return `Ups, link ini terlihat mencurigakan. Demi keamanan grup, aku harus mengeluarkan mu...\n`
}

exports.randomQuran = (ranquran) => {
    return `
    بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيم
*Nama surah*: ${ranquran.data.result.nama} / ${ranquran.data.result.asma}
*Arti*: ${ranquran.data.result.arti}
*Surat ke*: ${ranquran.data.result.nomor}
*Keterangan*: ${ranquran.data.result.keterangan}
*Link audio*: ${ranquran.data.result.audio}
    `
}

exports.hadis = () => {
    return `
_*Assalamu'alaikum wr. wb.*_

*Daftar hadis*:
1. Hadis Bukhari ada 6638 hadis
    _usage_: ${prefix}hadis bukhari 1
2. Hadis Muslim ada 4930 hadis
    _usage_: ${prefix}hadis muslim 25
3. Hadis Tirmidzi ada 3625 hadis
    _usage_: ${prefix}hadis tirmidzi 10
4. Hadis nasai ada 5364 hadis
    _usage_: ${prefix}hadis nasai 6
5. Hadis Ahmad ada 4305 hadis
    _usage_: ${prefix}hadis ahmad 5
6. Hadis Abu Daud ada 4419 hadis
    _usage_: ${prefix}hadis abudaud 45
7. Hadis Malik ada 1587 hadis
    _usage_: ${prefix}hadis malik 45
8. Hadis Ibnu Majah ada 4285 hadis
    _usage_: ${prefix}hadis ibnumajah 8
9. Hadis Darimi ada 2949 hadis
    _usage_: ${prefix}hadis darimi 3

*Semoga bermanfaat*
_*Wassalam*_
    `
}

exports.limit = () => {
    return `
*── 「 LIMIT 」 ──*

*LIMIT MU HABIS COOK*
_BELI PREMIUM DI wa.me/6287811078485?text=*Buy+Premium*+_
_Atau Tunggu Limit Tereset Di:_
❏ *_Tunggu hingga jam 00:00 WIB_*
    `
}

exports.asmaulHusna = (assna) => {
    return `
───❉ 𝐀𝐬𝐦𝐚𝐮𝐥 𝐇𝐮𝐬𝐧𝐚 ❉──

*${assna.name}*
❏ *Asmaul husna ke*: ${assna.number}
❏ *Pelafalan*: ${assna.transliteration}
❏ *Inggris*: ${assna.en.meaning}
    `
}

exports.recPremium = () => {
    return `*Premium Belum didapatkan hub wa.me/6287811078485*`
}
exports.menu = (jumlahUser, level, xp, role, pushname, requiredXp, premium, duit_, pret_, name_tag, sepp_) => {
    return `
*Follow IG: instagram.com/hardianto02_*✨
_*Dan Bantu Bot Untuk Beli Server Supaya Bisa nemenin kita makin lama Hanya di ${prefix}donasi*_
${pret_}
╭─────❉[ INTRO ]❉────
│ Yooo Kak ${name_tag}✨
│ Ikutin Rules Bot ya kak
│ Dan Jangan lupa Donate
╰───────────────────
BOT TELAH BERJALAN:
UPTIME: ${sepp_}

╭───────────────────
│ 💠Nama: ${pushname}
│ 🏆Level: ${level}
│ 🎖XP: ${xp} / ${requiredXp}
│ ⚔Role: ${role}
│ 💳Premium: ${premium}
│ 💸Duit: Rp ${duit_}
│ 🔑Perfix: [  ${prefix}  ]
│  📲Daftar: ${jumlahUser}
╰────────────────────
╭──❉[ MENU PAIMON ]❉──
│ ${prefix}downloadmenu📥
│ ${prefix}botmenu🤖
│ ${prefix}othermenu📚
│ ${prefix}stickermenu🖨
│ ${prefix}animemenu🀄
│ ${prefix}funmenu🎊
│ ${prefix}adminmenu📌
│ ${prefix}nsfwmenu🔐
│ ${prefix}ownermenu🛡
│ ${prefix}levelset🎖
│ ${prefix}premiummenu💳
│ ${prefix}tekxtpromenu🖼
│ ${prefix}creatormenu☎
│────────────────────
│ ${prefix}paimonofficial
│ ${prefix}jadipremium/${prefix}howtoprem
│─────────────────────
│-_-_-_-_PAIMON-BOT~_-_-_-
╰───────────────────${pret_}
INFO CREATOR:
WA: wa.me/6287811078485
IG: hardianto02_
FB: hardianto02_
PROFILE:
Name: Hardianto
Age : 17th
Gender: Boy
Anak ke : 2
Focus: Java Script
`
}
exports.menDonasi = (ownerNumber, pushname) => {
  return `
*HALO KAK ${pushname}✨*
_*PENGEN TRAKTIR OWNER KU YAH*_
_*AYOK BANTU KAK @${ownerNumber.replace('@c.us', '')}✨ UNTUK BELI SUSU KOTAK DENGAN CARA!!!!*_
_Donate kee!!_
╔══❉ *PAYMENT* ❉═══ 
╟⊱ *PULSA: 081241195562(Minim 20k for prem)*
╟⊱ *GO-PAY: 087811078485(Minim 10 for Prem)*
╟⊱ *DANA : MAINTENANCE*
╚══❉ *PAIMONBOT* ❉════
//// DONASI = OTOMATIS PREMIUM ////
*_WARNING: LEBIH JUGA GPP_*
*NOTE: DONASIMU BAHAGIA KAMI*`
}
exports.menuDownloader = () => {
    return `
╭──❉[ *MENU DOWNLOAD* ]❉──
│
│ ✨*${prefix}ytmp3 <link_Yt>*
│ ✨*${prefix}ytmp4* <Link_Yt>
│ ✨*${prefix}joox <Query>*
│ ✨*${prefix}tiktok <Link_Tiktok>*
│ ✨*${prefix}twitter <Link_Twit>*
│ ✨*${prefix}tiktokmp3 <Link tiktok>*
│ ✨*${prefix}soundcloud <Link_Soundcloud>*
│ ✨*${prefix}play <Query>*
│ ✨${prefix}playv <Query>*
│
╰──────────────────────`
}

exports.menuBot = () => {
    return `

╭──────❉[ *INFO BOT* ]❉──────
│ ✨*${prefix}rules <Read Rules>*
│ ✨*${prefix}menu <View More Menu*
│ ✨*${prefix}status <Check Status>*
│ ✨*${prefix}listblock <Check Number Block*
│ ✨*${prefix}ping <See & Speed Bof*
│ ✨*${prefix}delete <Reply Chat Bot only>*
│ ✨*${prefix}report <Report A bug>*
│ ✨*${prefix}tos <Nothing>*
│ ✨*${prefix}join <Link_Group>*
│ ✨*${prefix}ownerbot <Check Owner bot>*
│ ✨*${prefix}getpic <@tagUser>*
│ ✨*${prefix}premiumcheck <Check Duration Prem>*
│ ✨*${prefix}premiumlist <See User Prem>*
│ ✨*${prefix}donasi <Support Me>*
│
╰──────────────────────
    `
}

exports.InfoBot = (uptimer_, totalch, totalgb, cashp, cashp_) => {
  return `
╔══❉ *INFO BOT* ❉═══
╟ _*NAME BOT : PAIMON-CHAN*_
╟ _*NAME CREA: HARDIANTO*_
╟ *_NO OWNER : wa.me/6287811078485_*
╟ *_RUNTIME  : ${uptimer_}_*⏱
╟ *_TOTAL GB : ${totalgb.length}_*💻
╟ *_TOTAL CH : ${totalch.length}_*💻
╟ *_CHARGE✨ : ${cashp}🔋 / ${cashp_}_*
╟
╚══❉ *PAIMONBOT* ❉════`
}
exports.menuMisc = () => {
    return ` 
╭──❉[ *MENU OTHER* ]❉──
│
│1. *${prefix}say*
│2. *${prefix}lirik*
│3. *${prefix}shortlink*
│4. *${prefix}wikipedia*
│5. *${prefix}kbbi*
│6. *${prefix}igstalk*
│7. *${prefix}gsmarena*
│8. *${prefix}receipt*
│9. *${prefix}ytsearch*
│10. *${prefix}tts*
│11. *${prefix}afk*
|12. *${prefix}reminder*
│13. *${prefix}findsticker*
│14. *${prefix}math*
│15. *${prefix}listsurah*
│16. *${prefix}surah*
│17. *${prefix}js*
│18. *${prefix}mutual*
│19. *${prefix}whois*
│20. *${prefix}play*
│21. *${prefix}sms*
│22. *${prefix}toxic*
│23. *${prefix}tafsir*
│24. *${prefix}motivasi*
│25. *${prefix}linesticker*
│26. *${prefix}alkitab*
│27. *${prefix}cekongkir*
│28. *${prefix}movie*
│28. *${prefix}reminder*
│29. *${prefix}imagetourl*
│30. *${prefix}infohoax*
│31. *${prefix}trending*
│32. *${prefix}jobseek*
│33. *${prefix}spamcall*
│34. *${prefix}spamsms*
│35. *${prefix}email*
│36. *${prefix}quotes*
│37. *${prefix}genshininfo*
│38. *${prefix}translate*
|39. *${prefix}darkmeme*
│
╰──────────────────────
    `
}

exports.menuSticker = () => {
    return `
╭──❉[ *MENU STICKER* ]❉──
│1. *${prefix}sticker*
│2. *${prefix}stickergif*
│3. *${prefix}ttg*
│4. *${prefix}stickertoimg*
│5. *${prefix}emojisticker*
│6. *${prefix}stickerwm*
│7. *${prefix}stickermeme*
│8. *${prefix}takestick*
│9. *${prefix}sfire*
│10. *${prefix}sflow*
│11. *${prefix}snobg*
|12. *${prefix}sfrez*
╰──────────────────────
    `
}

exports.menuWeeaboo = () => {
    return `
╭──❉[ *MENU ANIME* ]❉──
│1. *${prefix}neko*
│2. *${prefix}wallpaper*
│3. *${prefix}kemono*
│4. *${prefix}kusonime*
│5. *${prefix}komiku*
│6. *${prefix}wait*
│7. *${prefix}source*
│8. *${prefix}waifu*
│10. *${prefix}neonime*
│11. *${prefix}loli*
│12. *${prefix}waifu2
│13. *${prefix}neonime*
│14. *${prefix}pinterest*
│15. *${prefix}nekonime*
│16. *${prefix}shota*
│17. *${prefix}shota2*
│18. *${prefix}shug*
│19. *${prefix}skiss*
│20. *${prefix}scry*
│21. *${prefix}quotesnime
│21. *${prefix}character*
│21. *${prefix}wallpaper1*
|
╰──────────────────────
    `
}

exports.menuFun = () => {
    return `
╭──❉[ *𝐌𝐄𝐍𝐔 𝐅𝐔𝐍* ]❉── 
│ ✨*${prefix}𝐦𝐞𝐦𝐞 <RANDOM>*
│ ✨*${prefix}𝐡𝐚𝐫𝐭𝐚 <TEXT>*
│ ✨*${prefix}𝐩𝐚𝐫𝐭𝐧𝐞𝐫 <Search Patner>*
│ ✨*${prefix}𝐳𝐨𝐝𝐢𝐚𝐜 <Find Zodiak>*
│ ✨*${prefix}𝐰𝐫𝐢𝐭𝐞  <Text>*
│ ✨*${prefix}𝐬 <Chat With Simi>*
│ ✨*${prefix}𝐭𝐨𝐝 <Start Chalenge>*
│ ✨*${prefix}𝐰𝐞𝐭𝐨𝐧 <Nothing>*
│ ✨*${prefix}𝐤𝐢𝐬𝐬 <@tagmem>*
│ ✨*${prefix}𝐚𝐬𝐮𝐩𝐚𝐧 <Get Timeline>*
│ ✨*${prefix}𝐜𝐢𝐭𝐚𝐜𝐢𝐭𝐚 <Find Cita-cita>*
│ ✨*${prefix}𝐩𝐡𝐜𝐨𝐦𝐦𝐞𝐧𝐭 <Tag Photo > text>*
│ ✨*${prefix}𝐰𝐚𝐬𝐭𝐞𝐝 <TagPhoto&TagMem>*
│ ✨*${prefix}𝐜𝐚𝐤𝐥𝐨𝐧𝐭𝐨𝐧𝐠 <Get Question>*
│ ✨*${prefix}𝐡𝐢𝐥𝐢𝐡 <Text>*
│ ✨*${prefix}𝐭𝐞𝐛𝐚𝐤𝐠𝐚𝐦𝐛𝐚𝐫 <Get Question>*
│ ✨*${prefix}𝐡𝐚𝐫𝐢𝐣𝐚𝐝𝐢 <Day&month&year>*
│ ✨*${prefix}𝐩𝐚𝐬𝐚𝐧𝐠𝐚𝐧 <Name Girl | Name Boy>*
│ ✨*${prefix}𝐪𝐮𝐨𝐭𝐞𝐜𝐫𝐞𝐚𝐭𝐞 <Text | author>*
│ ✨*${prefix}𝐡𝐮𝐦𝐨𝐫 <Random>*
│ ✨*${prefix}𝐬𝐤𝐞𝐭 <Photo>*
╰────────────────────
    `
}

exports.menuModeration = () => {
    return `
╭──❉[ *MENU ADMIN* ]❉──
|1. *${prefix}add*
|2. *${prefix}kick*
|3. *${prefix}promote*
|4. *${prefix}demote*
|5. *${prefix}leave*
|6. *${prefix}everyone*
|7. *${prefix}nsfw*
|8. *${prefix}groupicon*
|9. *${prefix}antilink*
|10. *${prefix}welcome*
|11. *${prefix}autosticker*
|12. *${prefix}antinsfw*
|13. *${prefix}mutegc*
|
╰──────────────────────
    `
}

exports.menuNsfw = () => {
    return `
╭──❉[ *MENU  NSFW* ]❉──
|
|1. *${prefix}lewds*
|2. *${prefix}multilewds*
|3. *${prefix}nhentai*
|4. *${prefix}nhdl*
|5. *${prefix}nekopoi*
|6. *${prefix}multifetish*
|7. *${prefix}waifu18*
|8. *${prefix}fetish*
|9. *${prefix}phdl*
|10. *${prefix}yuri*
|11. *${prefix}lewdavatar*
|12. *${prefix}femdom*
|13. *${prefix}nhsearch*
|14. *${prefix}nekosearch*
|15. *${prefix}cersex*
╰──────────────────────
    `
}

exports.menuOwner = () => {
    return `
╭──❉[ *MENU  OWNER* ]❉──
|
|1. *${prefix}bc*
|2. *${prefix}clearall*
|3. *${prefix}getses*
|4. *${prefix}ban*
|5. *${prefix}leaveall*
|6. *${prefix}eval*
|7. *${prefix}shutdown*
|8. *${prefix}premium*
|9. *${prefix}setstatus*
|10. *${prefix}serial*
|11. *${prefix}exif*
|12. *${prefix}mute*
|
╰──────────────────────
    `
}

exports.menuLeveling = () => {
    return `
╭──❉[ *MENU  LEVELING* ]❉──
|
| ✨*${prefix}level <Check Your level>*
| ✨*${prefix}leaderboard <See Ranker>*
| ✨*${prefix}setbackground <Tag Photo>*
│
╰──────────────────────
    `
}

exports.rules = () => {
    return `
╔══❉ *Rules!!!* ❉═══
╟⊱ 1. Jangan spam bot.
╟   Sanksi: *WARN / SOFT BLOCK*
╟
╟⊱ 2. Jangan telepon bot.
╟   Sanksi: *SOFT BLOCK*
╟
╟⊱ 3. Jangan mengeksploitasi bot.
╟   Sanksi: *PERMANENT BLOCK*
╟
╟⊱ 4.Jangan Hina/Sindir Bot
╟   Sanksi: *BAN PERMANEN*
╟
╟⊱ 5.Gunakan Bot Seperlunya
╟  Sanksi:-
╟ 
╚══❉ *PAIMONBOT* ❉════
And More
  Jika sudah dipahami rules - nya, silakan ketik * $ { prefix } menu * untuk memulai!
recode by:
  wa.me/6287811078485(H.A.R.D.I.A.N.T.O)
  Following Rules And Bye
  *ARIGATHANKS✨*
`
}

// Dimohon untuk owner/hoster jangan mengedit ini, terima kasih.
exports.tos = (ownerNumber) => {
    return `
-----[ TERMS OF SERVICE ]-----

Bot ini merupakan open-source bot dengan nama asli BocchiBot yang tersedia di GitHub secara gratis.
Owner/hoster dari bot ini terlepas dari tanggung jawab dan pengawasan developer (Slavyan).
Owner/hoster boleh menjiplak, menambahkan, menghapus, mengganti source code dengan catatan *tidak memperjualbelikannya* dalam bentuk apapun.
Apabila terjadi sebuah error, orang yang pertama yang harus kalian hubungi ialah owner/hoster.

Jika kalian ingin berkontribusi dalam projek ini, silakan kunjungi:
https://github.com/SlavyanDesu/BocchiBot

Contact person:
wa.me/${ownerNumber.replace('@c.us', '')} (Owner/hoster)
wa.me/6281294958473 (Developer) (lord )

Kalian juga bisa mendukung saya agar bot ini tetap up to date dengan:
087811078485 (GOPAY, DANA, XL)

Terima kasih!

Hardianto
    `
}